# Open Dog Academy (ODA)

This repository is a modular dog-training knowledge base designed for **MkDocs + GitHub Pages**.

## Website (MkDocs)
- Source docs live in `docs/`
- Config lives in `mkdocs.yml`

## Key rules
- Skills are atomic: **one file per `SKILL_ID`** in `docs/skills/`
- Standards are the **single source of truth** in `docs/standards/`
- No PDFs as primary storage (see `docs/format-policy.md`)

## Local preview
```bash
pip install mkdocs
mkdocs serve
```

Then open the local URL MkDocs prints.

## Start
- See `docs/start-here.md`

## Branding (placeholder)

- Current placeholder logo: `docs/assets/branding/logo.png`
- Favicon: `docs/assets/branding/favicon.png`

Replace these files later with the final brand assets (keep filenames the same to avoid breaking links).
