# ODA Format Policy
Updated: **2026-01-10**

Goal: keep the repo **diffable**, **web-publishable**, and **cheap** to maintain.

## Core rules
1) **No PDFs** as primary storage.
   - Use Markdown for all authored content.
   - External sources live as **URLs + metadata** and optional extract notes.

2) **Docs live in `docs/`** (MkDocs site source).
3) **One file per `SKILL_ID`** (skills are atomic and reusable).
4) **Hard file-size caps** are enforced by `scripts/check_sizes.py`.


## Atoms + assemblies (modularity default)
**Mantra:** *Atoms are truth. Assemblies are playlists.*

- **Atoms** live in `docs/_atoms/` and should be small, reusable, and mostly-static.
- **Assemblies** (skills, manuals, class guides) should include atoms instead of copying them.

### Include syntax (MkDocs)
This repo uses `pymdownx.snippets`.

```md
--8<-- "_atoms/templates/logging-template-001.md"
```

## Document zones (where things go)
- `docs/standards/` — non-negotiables, policies, measurement
- `docs/skills/` — one file per `SKILL_ID`
- `docs/classes/` — curricula (skill sequences)
- `docs/instructor-guides/` — minute-by-minute teaching scripts
- `docs/manuals/` — general reference (dog-agnostic)
- `docs/ops/` — operational notes (publishing, contributors, profile-storage rules)
- `docs/lab/` — experiment
- `docs/_atoms/` — reusable building blocks (single source of truth)
s and prototypes (quarantined until promotion)

**Out of scope for this repo:** one-dog/one-household implementations. Store those in a separate **Profiles** location (private by default). See [Profiles + Household Specs](ops/profile-storage.md).


## Allowed formats (by purpose)

### Authored knowledge (source of truth)
- Markdown: `.md`
- YAML: `.yml` / `.yaml` (registries/config)
- CSV: `.csv` (simple tables)

### Data exports (small only)
- `.json` / `.jsonl` / `.csv`

### Web assets
- Diagrams: `.svg`
- Screenshots: `.png`
- Photos: `.webp` (preferred) or `.jpg`

### Media (avoid in repo)
- Audio: `.opus` / `.ogg` (short clips only)
- Video: avoid; host externally and link

## File size caps (hard)
These caps are chosen to stay safely under GitHub’s limits (50 MiB warning / 100 MiB hard block) and keep the site fast. GitHub Pages published site must be ≤ 1 GB.

| Type | Examples | Soft cap | Hard cap |
|---|---|---:|---:|
| Markdown/YAML | `.md`, `.yml` | 200 KB | **1 MB** |
| CSV/JSON/JSONL | logs/exports | 1 MB | **5 MB** |
| SVG | diagrams | 200 KB | **1 MB** |
| WebP/JPG | photos | 350 KB | **1 MB** |
| PNG | screenshots | 500 KB | **2 MB** |
| Audio | `.opus` | 2 MB | **5 MB** |
| Video | `.mp4` | 20 MB | **50 MB** |
| Archives | `.zip` | 10 MB | **25 MB** |


## Anti-truncation rule (AI handoff friendly)
Some tools (including chat UIs) will **truncate long text**. To keep docs pasteable and reusable:

- **Doc length caps** are enforced by `scripts/validate_doc_limits.py`.
- Limits live in **`doc-limits.yml`** (per-folder/category caps).

Per-file exceptions are allowed via `overrides:` (use sparingly).

### Fix pattern when a doc hits the cap
1) Create a folder next to the file (same name), e.g. `manual-xyz/`
2) Split content into parts at `##` (H2) boundaries:
   - `manual-xyz/part-01.md`
   - `manual-xyz/part-02.md`
3) Convert the original file into an **index** with short overview + links to the parts.
4) If the content is mostly raw source material, move it to:
   - `docs/reference/extracts/` (summaries/notes), or
   - `docs/reference/exports_YYYY-MM-DD/` (large exports you don't want to edit often)

## Where to put external sources
- `docs/reference/sources.yml` (URL + metadata)
- `docs/reference/extracts/` (your summaries keyed by `source_id`)

## Enforcement
Run:
- `python3 scripts/check_sizes.py`  (hard caps)
- `python3 scripts/validate_yaml.py` (YAML sanity)
- `python3 scripts/validate_doc_limits.py` (anti-truncation caps)
- `python3 scripts/validate_skill_links.py` (skill ID integrity)


## Doc length limits (anti-truncation)
Long pages get “turncated” (truncated) in copy/paste workflows and are painful to review.

- Limits are defined in `doc-limits.yml` and enforced by CI.
- When a doc approaches the cap, split into modules and extract repeated blocks into atoms.

See: [Doc length limits](ops/doc-length-limits.md).



## Interface truncation (chat output)

Even when documents are within repo limits, chat interfaces can truncate long outputs.

- Runbook: `docs/ops/interface-truncation.md`
- Chat-safe export tool: `scripts/chunk_for_chat.py`

Default policy: prefer **atoms + assemblies** and deliver large artifacts as **files or numbered parts** with end markers.
