ID: protocol-syllabus-8session-001
Type: protocol
Status: draft
Path: docs/_atoms/protocols/syllabus-8session-001.md

## 8-session syllabus pattern
A default pacing model for a single-dog private class where each session is 5–15 minutes of focused training plus management.

### Session 1 — Baseline + reinforcement map
- Confirm reinforcers, markers, start ritual, release, and end ritual.
- Capture baseline: latency, errors, stress signals.

### Session 2 — Core skill build
- Build the primary behavior at low distraction.
- Keep criteria easy; prioritize clean repetitions.

### Session 3 — Add one dimension
- Add **one** difficulty dimension: distance *or* duration *or* distraction.
- Log what changed.

### Session 4 — Generalize context
- New room, new surface, new prop, or new handler position.
- Keep difficulty low; reward heavily.

### Session 5 — Combine two dimensions
- Combine two easy dimensions (e.g., small distance + mild distraction).
- Add a reset protocol for errors.

### Session 6 — Proofing ladder step
- Move up one rung on the proofing ladder.
- Introduce a "stop rule" for frustration/arousal.

### Session 7 — Mini-test + repair
- Run a short battery, then immediately do 2–3 easy wins.
- Identify the weakest dimension and plan fixes.

### Session 8 — Graduation battery + maintenance plan
- Run the defined graduation battery.
- Write a 2–3x/week maintenance plan (short, sustainable).
