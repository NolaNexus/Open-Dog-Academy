ID: `protocol-session-structure-001`
Type: protocol
Status: draft
Path: `docs/_atoms/protocols/session-structure-001.md`

---

## Session structure (default 5–15 min)

Use this structure for most skills and exposures. Keep it short, repeatable, and easy to log.

### Setup (30–60 sec)
- Pick **one** goal for the session (one rep type).
- Prepare rewards (ideally 3 tiers: low / medium / high).
- Set the environment so success is likely (distance, barriers, leash length).

### Working reps (3–10 min)
- Run **3–10 reps**.
- Between reps: 2–5 seconds of “reset” (sniff, breathe, reposition).
- Stop early if form or emotional state degrades.

### Break / decompression (30–120 sec)
Choose one:
- sniffing (“find it” scatter)
- stationary chew/lick (if appropriate)
- calm walking away from the trigger

### One “easy win” rep (optional)
Finish with a rep you are ~90% sure will succeed.

### End + log (30–60 sec)
- End before the dog is tired.
- Log: what you did, where, success rate, and what to change next time.

**Success criteria:** you can run this structure daily without enthusiasm or recovery time getting worse.
