ID: `protocol-errorless-learning-001`
Type: protocol
Status: draft
Path: `docs/_atoms/protocols/errorless-learning-001.md`

---

## Errorless learning pattern

**Purpose:** Keep success high so behavior strengthens without frustration.

**Core idea:** Make the *right* choice easy, and the *wrong* choice hard.

### Default rules
- Start at a difficulty where you can get **8–10 wins out of 10**.
- Use **help** (prompts, closer distance, lower distractions, barriers, long line) instead of repeating cues.
- Raise **one variable at a time** (distance *or* duration *or* distraction).
- When errors happen, treat them as information: adjust setup, don’t “correct.”

### If the dog makes an error
1. **Reset**: calmly guide back to start (leash/long line as needed).
2. **Lower difficulty** (closer, quieter, shorter, fewer competing reinforcers).
3. Do **2–3 easy reps** to rebuild momentum.
4. Re-attempt the harder step only if success is likely.

### Success criteria
- Session average is ≥ **80% correct** and the dog stays willing (food-taking, re-orienting, relaxed body).

### Common pitfalls → fix
- “Just try again” loops → add help immediately; keep cue count at 1.
- Moving too fast → track which variable you changed; step back if latency rises.
