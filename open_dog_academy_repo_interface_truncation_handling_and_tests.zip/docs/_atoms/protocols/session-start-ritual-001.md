ID: `protocol-session-start-ritual-001`
Type: protocol
Status: draft
Path: `docs/_atoms/protocols/session-start-ritual-001.md`

---

## Session start ritual (60–120s)

**Purpose:** Predictability lowers arousal, improves focus, and makes sessions easier to stop/continue cleanly.

**Default sequence**
1. **Check basics:** leash clipped, treats ready, environment safe.
2. **1 easy rep:** something your dog nails (hand touch, sit, eye contact).
3. **Marker + pay:** crisp timing.
4. **Micro-break:** 2–5 seconds of sniffing or quiet wandering.
5. **Start the “real” plan:** your first planned rep should still be easy.

**Success criteria**
- Dog can take food calmly and re-orient back to you within ~2 seconds.

**Common failure modes → fix**
- Dog is frantic at start → start farther from the trigger, lower value rewards, add longer micro-breaks.
- Dog locks onto the treat pouch → use a hand target first; deliver food from the opposite hand.
