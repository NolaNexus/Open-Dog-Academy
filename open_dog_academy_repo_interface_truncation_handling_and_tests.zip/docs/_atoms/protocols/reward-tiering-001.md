ID: `protocol-reward-tiering-001`
Type: protocol
Status: draft
Path: `docs/_atoms/protocols/reward-tiering-001.md`

---

## Reward tiering

**Purpose:** Pay proportionally so the dog learns what “really matters” without needing constant jackpots.

### Define tiers (example)
- **Tier 1 (baseline):** single kibble / low-value treat.
- **Tier 2 (nice):** 2–3 treats, slightly higher value.
- **Tier 3 (big):** rapid “treat party,” tug, or high-value food.
- **Tier 4 (life reward):** release back to sniff/play (Premack), go greet, hop in car, etc.

### When to use which
- **New skill / new context:** mostly Tier 2–3.
- **Maintenance:** mostly Tier 1–2 with occasional Tier 3.
- **High distraction success:** Tier 3–4.
- **Breakthroughs (first time):** Tier 3 (not every time).

### Rules
- Reward size should match **difficulty**, not your mood.
- If you need Tier 3 every rep to get behavior, the step is too hard.

### Common pitfalls → fix
- Over-jackpotting every rep → dog becomes “slot machine picky.” Save Tier 3–4 for meaningful wins.
- Food dependency fears → fade food by swapping in Tier 4 life rewards, not by going cold turkey.
