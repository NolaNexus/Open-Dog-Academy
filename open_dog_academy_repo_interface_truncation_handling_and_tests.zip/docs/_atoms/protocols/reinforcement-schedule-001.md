ID: `protocol-reinforcement-schedule-001`
Type: protocol
Status: draft
Path: `docs/_atoms/protocols/reinforcement-schedule-001.md`

---

## Reinforcement schedule (how often you pay)

**Goal:** Pay often enough to keep behavior strong, then thin the schedule without breaking confidence.

### Defaults
- **New behavior / new place:** reinforce almost every correct rep.
- **Building duration:** pay more frequently at first, then randomize.
- **Maintenance:** reinforce most reps with small rewards; sprinkle in bigger rewards.

### Thinning without breaking the behavior
- Use **variable reinforcement** (pay 2, skip 1, pay 1, skip 2…).
- When you skip, use **praise + movement** so the rep still ends cleanly.
- Don’t thin two variables at once (e.g., don’t reduce pay *and* raise distractions together).

### When to increase reinforcement again
- Latency gets slower
- Errors increase
- Dog can’t disengage from distractions
- Dog stops taking food (stress/arousal)

**Rule of thumb:** If success drops below ~80%, you’re too lean for the current difficulty.
