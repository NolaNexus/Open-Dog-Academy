ID: `protocol-release-cue-001`
Type: protocol
Status: draft
Path: `docs/_atoms/protocols/release-cue-001.md`

---

## Release cue

**Definition:** A cue that means *the repetition is over* and the dog may disengage.

**Why it matters**
- Prevents sticky “stays” and reduces conflict.
- Makes criteria clearer: *work → paid → released*.

**Teaching steps**
1. Ask for a very easy behavior (sit/stand).
2. Mark + pay.
3. Immediately say your release cue (e.g., “free”) and toss 1 treat away *or* walk with the dog 2–3 steps.
4. Repeat until the cue predicts movement/permission.

**Rules**
- Release cue is not a punishment. It should feel good.
- Always release after any “hold” behavior (stay, heel hold, place).

**Common pitfalls → fix**
- Dog breaks before release → shorten duration; pay more frequently; avoid baiting with long pauses.
- Release cue gets ignored → pair it with movement (treat toss/walk-off) for a week.
