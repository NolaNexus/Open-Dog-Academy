ID: `checklist-generalization-001`
Type: checklist
Status: stable
Path: `docs/_atoms/checklists/generalization-checklist-001.md`

---

## Generalization checklist (make it work everywhere)

When a skill is solid in one context, generalize by changing **one** thing at a time.

### Context variables
- **Rooms:** kitchen → hallway → living room
- **Yards:** front → back → driveway
- **Surfaces:** grass → gravel → sidewalk
- **Handler posture:** standing → walking → sitting
- **Gear:** harness → collar → long line
- **Time of day:** quiet → busy
- **People:** alone → family present → mild strangers at distance

### Rule
- Keep the behavior easy when you change context.
- If it falls apart, your “skill” was context-bound—step back and rebuild.
