ID: `checklist-decompression-menu-001`
Type: checklist
Status: draft
Path: `docs/_atoms/checklists/decompression-menu-001.md`

---

## Decompression menu (pick 1–3 after hard reps)

**Goal:** Lower arousal so the dog can think again.

### Quick options (30–180s)
- Scatter feed in grass / snuffle
- “Find it” tosses in a small area
- Slow leash walk with permission to sniff
- Hand target + slow treat delivery
- Chew / lick break (if safe and practical)
- Mat settle for 30–60s (reinforce calm)

### Rules
- Decompression is **not** “stop training forever.” It’s a reset.
- Choose decompression that fits the environment (no scatter feeding where it’s unsafe).
