ID: template-class-guide-spine-001
Type: template
Status: draft
Path: docs/_atoms/templates/class-guide-spine-001.md

## Class guide spine
Use this structure for any class guide page. Keep the page itself short; move reusable blocks into atoms.

### 1) Purpose
- One sentence describing what this guide builds.

### 2) Prerequisites
- 3–6 bullets.

### 3) Outcomes
- Measurable bullets (what success looks like).

### 4) Skill inventory
- Skill IDs referenced or required.

### 5) Progression levels
- L0–L4 (or similar), each with criteria.

### 6) Default session plan
- Use an 8-session (or 4/6/10) plan; keep it as a skeleton and link to atoms for shared routines.

### 7) Graduation battery
- A short audit with pass/fail thresholds.

### 8) Setup mapping
- Optional: gear/layout notes (non-essential, no household-specific specs).
