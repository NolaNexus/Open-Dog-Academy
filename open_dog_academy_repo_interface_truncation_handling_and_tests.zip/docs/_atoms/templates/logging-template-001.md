ID: `template-logging-001`
Type: template
Status: stable
Path: `docs/_atoms/templates/logging-template-001.md`

---

## Logging template (copy/paste)

- **Date / time:**
- **Location / context:**
- **Goal (one sentence):**
- **Setup:** gear, distance, environment notes
- **Reps:** __ total
- **Success rate:** __/__
- **Latency:** avg __s (range __–__)
- **What got harder:** (distance/duration/distraction/location)
- **Notes:** (body language, surprises, wins)
- **Next session plan (one change):**
