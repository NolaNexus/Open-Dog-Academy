ID: template-graduation-battery-001
Type: template
Status: draft
Path: docs/_atoms/templates/graduation-battery-template-001.md

## Graduation battery template
Use as a consistent mini-audit across skills/classes.

### Setup
- Duration: 8–15 minutes
- Reinforcers: low → medium value (save jackpots for the end)
- Errors: log what happened (don’t "fix" mid-battery unless safety requires it)

### Battery blocks
1) **Warm start** (easy rep)
2) **Core test** (the primary behavior under the target distraction level)
3) **Generalization** (new location / new handler movement / new prop)
4) **Recovery** (can the dog return to working state after an error?)
5) **Cool down** (settle / place / decompression)

### Pass criteria
- Define success rate, latency thresholds, and allowed prompts.
- Include a "stop rule" (end if frustration/arousal climbs past safe working range).
