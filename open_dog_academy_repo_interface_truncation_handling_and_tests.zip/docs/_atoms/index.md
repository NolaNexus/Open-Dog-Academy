# Atoms (Single Source of Truth)

Atoms are **small, reusable, mostly-static** markdown blocks.  
Assemblies (skills, manuals, class guides) should **include** atoms rather than re-copying them.

**Mantra:** *Atoms are truth. Assemblies are playlists.*

---

## How to include an atom in an assembly

This repo uses **pymdownx.snippets** (MkDocs Markdown extension).

Include syntax:

```md
--8<-- "_atoms/templates/logging-template-001.md"
```

Notes:
- Paths are relative to `docs/` (the MkDocs `docs_dir`).
- Keep atoms small. If an atom grows, split it into 2–3 atoms.

---

## Starter atoms (high reuse)

- Protocols
  - [Session Structure](protocols/session-structure-001.md)
  - [Reinforcement Schedule](protocols/reinforcement-schedule-001.md)

- Rubrics
  - [Proofing Ladder](rubrics/proofing-ladder-001.md)
  - [Pass Criteria Template](rubrics/pass-criteria-template-001.md)

- Safety
  - [Safety Gating](safety/safety-gating-001.md)

- Troubleshooting
  - [Troubleshooting Loop](troubleshooting/troubleshooting-loop-001.md)

- Concepts
  - [Arousal Management](concepts/arousal-management-001.md)
  - [Handler Mechanics](concepts/handler-mechanics-001.md)

- Templates
  - [Logging Template](templates/logging-template-001.md)

- Checklists
  - [Generalization Checklist](checklists/generalization-checklist-001.md)


## More building blocks

- [Session start ritual](protocols/session-start-ritual-001.md)
- [Release cue](protocols/release-cue-001.md)
- [Errorless learning pattern](protocols/errorless-learning-001.md)
- [Reward tiering](protocols/reward-tiering-001.md)
- [Marker timing](concepts/marker-timing-001.md)
- [Latency rubric](rubrics/latency-rubric-001.md)
- [Distance rubric](rubrics/distance-rubric-001.md)
- [Duration rubric](rubrics/duration-rubric-001.md)
- [Distraction rubric](rubrics/distraction-rubric-001.md)
- [Decompression menu](checklists/decompression-menu-001.md)
- [8-session syllabus pattern](protocols/syllabus-8session-001.md)
- [Class guide spine template](templates/class-guide-spine-001.md)
- [Graduation battery template](templates/graduation-battery-template-001.md)
