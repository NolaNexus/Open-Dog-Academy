ID: `troubleshooting-loop-001`
Type: troubleshooting
Status: stable
Path: `docs/_atoms/troubleshooting/troubleshooting-loop-001.md`

---

## Troubleshooting loop (when a rep fails)

1. **Pause** (1–2 seconds): don’t rapid-fire cues.
2. **Reset**: calmly return to start position / reduce movement.
3. **Diagnose** (pick one):
   - too hard (distance/duration/distraction)
   - unclear cue/marker timing
   - reward not motivating enough
   - competing reinforcer is too strong
4. **Adjust one variable** (make it easier).
5. **Run 2 easy reps** to rebuild momentum.
6. **Try again** or end on a win.

**Rule:** Two failures in a row = make the next rep easier.
