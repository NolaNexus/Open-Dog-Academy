ID: `safety-gating-001`
Type: safety
Status: stable
Path: `docs/_atoms/safety/safety-gating-001.md`

---

## Safety gating (stop conditions)

**Purpose:** Decide when to train vs when to manage and leave.

### Train only if
- Dog can take food normally
- Dog can disengage from the environment within ~3–5 seconds
- You can maintain distance/control without wrestling

### Leave / create distance if
- Dog is scanning, stiff, fixated, or vocal escalating
- Food refusal (outside medical issues)
- Rehearsing unwanted behaviors (lunging, chasing, rehearsed fear)

### Hard stop (end session now)
- Safety hazard appears (wildlife, unsafe people/dogs, traffic)
- Dog hits panic/freeze/shutdown
- You feel physically unsafe or unable to control the setup

**Rule:** Safety > training. Management is a valid success.
