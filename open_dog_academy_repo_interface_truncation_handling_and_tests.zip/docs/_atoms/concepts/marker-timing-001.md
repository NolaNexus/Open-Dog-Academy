ID: `concept-marker-timing-001`
Type: concept
Status: draft
Path: `docs/_atoms/concepts/marker-timing-001.md`

---

## Marker timing

**Definition:** A marker (click/word) tells the dog exactly which instant earned reinforcement.

### The rule
- Mark the **moment of success**, not the end of the behavior.

### Three timing anchors
- **Commit mark:** dog *turns toward you* (great for recall).
- **Position mark:** dog is *in the target spot* (front/heel/place).
- **Duration mark:** dog maintains for the interval you’re building.

### Quick diagnostic
- If the dog offers “almost right” versions repeatedly, your mark is late or inconsistent.

### Fix pattern
1. Reduce difficulty.
2. Video one short session.
3. Mark earlier than feels natural, then pay fast.

### Common pitfalls
- Marking while reaching for food → separate the hands: mark first, then reach.
- Talking through reps → keep cues/feedback short; extra chatter blurs contingencies.
