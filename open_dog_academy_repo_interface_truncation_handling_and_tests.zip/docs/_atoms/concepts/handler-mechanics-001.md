ID: `concept-handler-mechanics-001`
Type: concept
Status: draft
Path: `docs/_atoms/concepts/handler-mechanics-001.md`

---

## Handler mechanics (make it easy for the dog)

### Defaults
- Stand tall, shoulders relaxed, feet stable.
- Give cues once, then become still.
- Mark first, then reach for the reward.
- Deliver rewards where you want the dog to be next.

### Common handler mistakes
- Leaning over the dog (adds pressure)
- Cue repetition (“come come come”) instead of helping
- Feeding from the pocket too slowly (late reinforcement)
- Moving toward the dog when you want the dog to come to you

### Fix pattern
- Reduce difficulty and practice your mechanics without the dog (dry runs).
- Video 30 seconds, then adjust one thing at a time.
