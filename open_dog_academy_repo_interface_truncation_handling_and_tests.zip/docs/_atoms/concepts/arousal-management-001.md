ID: `concept-arousal-management-001`
Type: concept
Status: draft
Path: `docs/_atoms/concepts/arousal-management-001.md`

---

## Arousal management (keep the brain online)

**Arousal** is the dog’s energy/activation level. Too low = checked out. Too high = impulsive.

### Signs you’re too high
- frantic sniffing / darting
- whining, barking, grabbing leash
- can’t take food or swallows hard
- latency increases (dog “hears you” but doesn’t act)

### Simple levers
- **Distance:** step farther from triggers.
- **Rate of reinforcement:** pay more often.
- **Decompression:** sniff/forage break (see decompression menu).
- **Session length:** shorter sessions, more breaks.

### Success criteria
- Dog can take food and re-orient back to you after a rep within ~2 seconds.
