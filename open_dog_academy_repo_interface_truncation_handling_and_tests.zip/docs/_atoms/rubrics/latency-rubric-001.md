ID: `rubric-latency-001`
Type: rubric
Status: draft
Path: `docs/_atoms/rubrics/latency-rubric-001.md`

---

## Latency rubric (how fast the dog starts)

**Latency** = time from cue to the dog’s first clear movement in the right direction.

### Levels (suggested)
- **L0 (instant):** < 1s
- **L1 (snappy):** 1–2s
- **L2 (slow):** 2–4s
- **L3 (stalled):** > 4s or needs help

### How to use
- Record latency for 5–10 reps.
- If average drifts from L0–L1 into L2+, **lower difficulty** (distraction/distance/duration).

### Notes
- Latency is often your earliest warning that you moved too fast.
