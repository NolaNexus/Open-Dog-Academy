ID: `rubric-proofing-ladder-001`
Type: rubric
Status: draft
Path: `docs/_atoms/rubrics/proofing-ladder-001.md`

---

## Proofing ladder (raise one thing at a time)

Proofing means keeping the behavior intact as the world gets harder.

### Ladder dimensions
- **Distance:** farther away from handler/target
- **Duration:** longer holds, longer calm time
- **Distraction:** more interesting stuff happening
- **Location:** new places, surfaces, layouts
- **Handler posture:** sitting/standing/moving/turning away
- **Equipment:** different leash/harness/collar setups

### Progression rule
- Change **one** variable at a time.
- If success drops below ~70%, step back one rung.

### Data to log
- the rung you trained (what got harder?)
- success rate
- latency (how fast the dog started)
