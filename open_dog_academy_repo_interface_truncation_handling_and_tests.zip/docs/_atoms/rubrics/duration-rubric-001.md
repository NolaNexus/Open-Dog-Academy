ID: `rubric-duration-001`
Type: rubric
Status: draft
Path: `docs/_atoms/rubrics/duration-rubric-001.md`

---

## Duration rubric (how long the dog can hold it)

### Levels (suggested)
- **T0:** 1–2 seconds
- **T1:** 3–5 seconds
- **T2:** 6–15 seconds
- **T3:** 16–30 seconds
- **T4:** 30–60+ seconds

### Use
- Add duration in small jumps (don’t double repeatedly).
- Randomize: short–short–long–short to prevent “guessing the release.”
