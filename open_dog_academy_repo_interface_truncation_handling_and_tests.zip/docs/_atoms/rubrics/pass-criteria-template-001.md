ID: `rubric-pass-criteria-template-001`
Type: rubric_template
Status: stable
Path: `docs/_atoms/rubrics/pass-criteria-template-001.md`

---

## Pass criteria rubric template (copy into skills)

Use this structure so every skill is testable the same way.

### Test setup
- **Environment:** (quiet / moderate / public)
- **Equipment:** (leash length, harness/collar, treats)
- **Handler rules:** (one cue? can repeat? can lure?)

### Pass criteria (example format)
- **Accuracy:** ≥ __/10 correct reps
- **Latency:** responds within __ seconds
- **Duration:** holds for __ seconds (if relevant)
- **Distraction level:** succeeds with __ distractions present
- **Recovery:** returns to baseline within __ seconds after an error

### Fail criteria
- Repeated stress signals (yellow→red)
- Safety risk (lunging toward hazard)
- Handler needs to physically force position

### Notes
- List common “cheats” (leaning, creeping, sniffing) and how they are scored.

**Rule:** pass criteria should fit in one screen and be runnable in under 10 minutes.
