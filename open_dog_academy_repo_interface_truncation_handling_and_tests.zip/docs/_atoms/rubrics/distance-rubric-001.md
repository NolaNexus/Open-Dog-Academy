ID: `rubric-distance-001`
Type: rubric
Status: draft
Path: `docs/_atoms/rubrics/distance-rubric-001.md`

---

## Distance rubric (how far the dog can do it)

### Levels (suggested)
- **D0:** 0–3 ft (same room / at your side)
- **D1:** 3–10 ft
- **D2:** 10–30 ft
- **D3:** 30–60 ft
- **D4:** 60+ ft / field distance

### Use
- Increase distance only when success is ≥ 80% at the current level.
- Pair distance increases with **lower distractions** until stable.
