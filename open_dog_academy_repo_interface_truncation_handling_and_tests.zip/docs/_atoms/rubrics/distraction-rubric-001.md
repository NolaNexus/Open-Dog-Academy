ID: `rubric-distraction-001`
Type: rubric
Status: draft
Path: `docs/_atoms/rubrics/distraction-rubric-001.md`

---

## Distraction rubric (what’s competing with you)

### Levels (suggested)
- **X0:** calm, familiar space
- **X1:** low movement / mild noises
- **X2:** moderate novelty (new room, mild people movement)
- **X3:** high value competing reinforcers (sniffing spots, dogs at distance)
- **X4:** “hard mode” (play, running dogs, wildlife scents, crowds)

### Use
- Raise distractions *after* distance/duration are stable.
- If your dog can’t take food, you’re beyond the learning zone—back up.
