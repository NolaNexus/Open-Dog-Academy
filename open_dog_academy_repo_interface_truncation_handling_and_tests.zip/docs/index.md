![Open Dog Academy logo (placeholder)](assets/branding/logo.png)

# Open Dog Academy (ODA)

A **modular, welfare-first** dog training knowledge base built for:
- **single-dog private training**
- **free weekly group meetups**
- future **MkDocs + GitHub Pages** publishing

This repo is organized like software:
- **Standards** are the single source of truth (safety, measurement, policies).
- **Skills** are atomic (one file per `SKILL_ID`).
- **Class guides** sequence skills into curricula.
- **Instructor guides** are minute-by-minute scripts for teaching groups.
- **Manuals** are general “whole-dog” references.
- **Profiles** (stored outside this repo) hold dog/household-specific implementations.
- **LAB** is for experiments and weird ideas (kept quarantined until they earn promotion).

## Start here
- [Start Here](start-here.md)
- [Roadmap](roadmap.md)
- [Format Policy](format-policy.md)

## Quick navigation
- [Standards](standards/academy-standards.md)
- [Classes Index](indexes/class-guides-index.md)
- [Instructor Guides Index](indexes/instructor-guides-index.md)
- [Skills Index](indexes/skills-index.md)
- [Manuals](manuals/manual-socialization.md)
- [LAB](lab/index.md)

## Principles (short version)
- **Welfare-first** training: humane, reward-based methods by default.
- **Management + reinforcement + gradual exposure** is the backbone.
- **Measure what matters**: clear pass criteria beat vibes.
- **Generalize on purpose**: change one variable at a time and keep reps clean.
- **Remote cue devices** (vibrate/beep/flash) are treated as **conditioned cues**, not punishers.
- **Quarantine novelty**: experiments live in LAB until they’re safe and repeatable.

## Contributing (where things go)
- If it’s a **non-negotiable rule** → `docs/standards/`
- If it’s an **atomic behavior** → `docs/skills/`
- If it’s a **teachable sequence** → `docs/classes/` or `docs/instructor-guides/`
- If it’s **general reference** → `docs/manuals/`
- If it’s **one-dog/one-household specific** → store it in **Profiles** (outside this repo): see [Profiles + Household Specs](ops/profile-storage.md)
- If it’s **experimental / not proven yet** → `docs/lab/`
