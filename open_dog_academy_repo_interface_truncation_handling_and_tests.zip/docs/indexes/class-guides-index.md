# Class Guides Index
Updated: 2026-01-10

- [class-guide-cooperative-care.md](../classes/class-guide-cooperative-care.md)
- [class-guide-independence.md](../classes/class-guide-independence.md)
- [class-guide-leash-skills.md](../classes/class-guide-leash-skills.md)
- [class-guide-nosework.md](../classes/class-guide-nosework.md)
- [class-guide-obedience.md](../classes/class-guide-obedience.md)
- [class-guide-off-leash.md](../classes/class-guide-off-leash.md)
- [class-guide-rally.md](../classes/class-guide-rally.md)
- [class-guide-regulation.md](../classes/class-guide-regulation.md)
- [class-guide-shaping-arcade.md](../classes/class-guide-shaping-arcade.md)
- [work-and-sport-foundations/index.md](../classes/work-and-sport-foundations/index.md)
- [class-guides-work-and-sport-foundations.md (stub)](../classes/class-guides-work-and-sport-foundations.md)
