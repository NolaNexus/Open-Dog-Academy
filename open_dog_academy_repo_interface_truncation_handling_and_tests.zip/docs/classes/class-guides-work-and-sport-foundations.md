# Work + Sport Foundations (Moved)
Path: docs/classes/class-guides-work-and-sport-foundations.md
Status: stub
Updated: 2026-01-10

This suite has been modularized into a folder of smaller guide files:

- **Canonical location:** [Work + Sport Foundations](work-and-sport-foundations/index.md)

Reason: this reduces duplication, supports the **Atoms are truth** pattern, and prevents truncation/drift.
