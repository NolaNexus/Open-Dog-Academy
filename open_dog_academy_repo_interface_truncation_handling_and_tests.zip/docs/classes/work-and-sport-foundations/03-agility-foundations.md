# Agility Foundations (Safety-First, Low Impact)
Path: docs/classes/work-and-sport-foundations/03-agility-foundations.md
Status: draft
Updated: 2026-01-10

## 1) Purpose
Build body awareness, confidence, and directional communication without high-impact jumping. This is pre-agility for injury prevention.

## 2) Prerequisites
- Comfortable moving on varied surfaces
- Can follow a lure/target
- Can rest on a mat between reps

## 3) Outcomes
- Confident on low obstacles
- Follows basic directionals
- Has a warm-up/cool-down habit

## 4) Skill inventory (IDs)
- AG_WARMUP_ROUTINE
- AG_TARGETING
- AG_DIRECTIONALS
- AG_REAR_END_AWARENESS
- AG_FORWARD_FOCUS
- AG_TABLE_SETTLE

## 5) Progression levels
- L0: targets + confidence platforms
- L1: around cone / wrap / low tunnel (optional)
- L2: 2–3 obstacle sequences, no jumping
- L3: speed control (accelerate/decelerate cues)
- L4: low jumps only if body condition and vet clearance make sense

## 6) Default session plan
--8<-- "_atoms/protocols/session-start-ritual-001.md"

--8<-- "_atoms/protocols/session-structure-001.md"

--8<-- "_atoms/protocols/syllabus-8session-001.md"

## 7) Graduation battery
--8<-- "_atoms/templates/graduation-battery-template-001.md"

**Agility-specific pass criteria (example)**
- Warm-up performed calmly
- 3 short sequences, ≥ 80% success at D2
- Table/settle 10s between sequences

## 8) Setup mapping (optional)
- Confidence platforms + table/settle station
- Directional cones/posts

## Shared safety blocks
--8<-- "_atoms/safety/safety-gating-001.md"

--8<-- "_atoms/concepts/arousal-management-001.md"

--8<-- "_atoms/templates/logging-template-001.md"
