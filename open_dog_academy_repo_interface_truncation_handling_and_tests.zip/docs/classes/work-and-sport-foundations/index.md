# Work + Sport Foundations
Path: docs/classes/work-and-sport-foundations/index.md
Status: draft
Updated: 2026-01-10

This suite is an **assembly**: it sequences sport/work foundation guides while pulling shared, reusable truth blocks from [Atoms](../../_atoms/index.md).

Definitions of "work," "sport," and "tasks" live in: [Work + Sport + Task Taxonomy](../../manuals/manual-work-sport-task-taxonomy.md).

## How to use this suite
- Pick **one** guide and run it for 2–4 weeks.
- Use the same measurement/logging format across guides so progress is comparable.

--8<-- "_atoms/templates/class-guide-spine-001.md"

## Guides
1) [Nosework Foundations](01-nosework-foundations.md)
2) [Rally Foundations](02-rally-foundations.md)
3) [Agility Foundations](03-agility-foundations.md)
4) [Trick Training + Shaping](04-trick-shaping.md)
5) [Retrieve Foundations](05-retrieve-foundations.md)
6) [Service-Style Task Foundations](06-service-task-foundations.md)
7) [Tracking / Trail Foundations](07-tracking-trail-foundations.md)
8) [Disc / Toy Play Skills](08-toy-play.md)
