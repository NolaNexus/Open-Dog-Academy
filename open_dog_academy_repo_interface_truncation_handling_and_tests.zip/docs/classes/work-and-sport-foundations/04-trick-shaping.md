# Trick Training + Shaping (Creativity Engine)
Path: docs/classes/work-and-sport-foundations/04-trick-shaping.md
Status: draft
Updated: 2026-01-10

## 1) Purpose
Build learning-to-learn: shaping, novelty, confidence, and handler timing. This is the backbone of a dog arcade and many sports.

## 2) Prerequisites
- Marker understood (or you can teach it first)
- Willingness to offer behaviors (or can be shaped from tiny steps)

## 3) Outcomes
- Dog offers behaviors without shutting down
- Can chain 2–4 behaviors
- Can handle variable reinforcement without collapsing

## 4) Skill inventory (IDs)
- SHAPE_OFFERING
- SHAPE_STAY_IN_GAME
- SHAPE_TARGETS
- SHAPE_OBJECT_INTERACTION
- SHAPE_CHAIN_2
- SHAPE_CHAIN_3
- SHAPE_VARIABLE_REINFORCEMENT

## 5) Progression levels
- L0: capture simple offers
- L1: build targets (nose/paw)
- L2: object interactions (touch/pick up)
- L3: two-step chains
- L4: variable reinforcement + random jackpots

## 6) Default session plan
--8<-- "_atoms/protocols/session-start-ritual-001.md"

--8<-- "_atoms/protocols/session-structure-001.md"

--8<-- "_atoms/protocols/errorless-learning-001.md"

--8<-- "_atoms/protocols/reward-tiering-001.md"

--8<-- "_atoms/protocols/syllabus-8session-001.md"

## 7) Graduation battery
--8<-- "_atoms/templates/graduation-battery-template-001.md"

**Shaping-specific pass criteria (example)**
- Offers ≥ 10 behaviors in 2 minutes without frustration spikes
- Completes a 2-step chain at D2 with ≥ 80% success

## 8) Setup mapping (optional)
- Small prop bin; one "active" prop at a time
- Clear reset spot (mat) between reps

## Shared measurement blocks
--8<-- "_atoms/concepts/marker-timing-001.md"

--8<-- "_atoms/troubleshooting/troubleshooting-loop-001.md"

--8<-- "_atoms/templates/logging-template-001.md"
