# Rally Foundations (Station Flow + Position Control)
Path: docs/classes/work-and-sport-foundations/02-rally-foundations.md
Status: draft
Updated: 2026-01-10

## 1) Purpose
Create smooth station-to-station working rhythm: heel position, pivots, fronts, finishes, sits/downs, and handler mechanics.

## 2) Prerequisites
- Loose leash foundations
- Sit/down understood
- Can take food near mild distractions

## 3) Outcomes
- Dog maintains working position through transitions
- Performs station skills with minimal prompting
- Recovers quickly after small mistakes

## 4) Skill inventory (IDs)
- RALLY_START_LINE
- RALLY_HEEL_LIFE
- RALLY_TURNS
- RALLY_HALT_SIT
- RALLY_FRONT
- RALLY_FINISH_L / RALLY_FINISH_R
- RALLY_PIVOT
- RALLY_STATION_RECOVERY

## 5) Progression levels
- L0: single-station reps
- L1: two-station mini sequences
- L2: 5–7 station sequences at D1–D2
- L3: 10–15 station mini-course with distractions
- L4: longer silent-handler stretches (optional advanced)

## 6) Default session plan
--8<-- "_atoms/protocols/session-start-ritual-001.md"

--8<-- "_atoms/protocols/session-structure-001.md"

--8<-- "_atoms/protocols/syllabus-8session-001.md"

## 7) Graduation battery
--8<-- "_atoms/templates/graduation-battery-template-001.md"

**Rally-specific pass criteria (example)**
- 10-station mini-course at D2
- Accuracy ≥ 85% overall
- Recovers to working state within 10s after errors

## 8) Setup mapping (optional)
- Signs or cue cards; a clear start line; a reward zone
- Pivot box or perch for rear-end awareness

## Shared measurement blocks
--8<-- "_atoms/concepts/handler-mechanics-001.md"

--8<-- "_atoms/rubrics/latency-rubric-001.md"

--8<-- "_atoms/rubrics/duration-rubric-001.md"

--8<-- "_atoms/checklists/generalization-checklist-001.md"

--8<-- "_atoms/templates/logging-template-001.md"
