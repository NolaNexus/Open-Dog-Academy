# Nosework Foundations (Calm Search + Indication)
Path: docs/classes/work-and-sport-foundations/01-nosework-foundations.md
Status: draft
Updated: 2026-01-10

## 1) Purpose
Build calm, systematic searching with a clear indication (e.g., **nose-hold**) suitable for sealed scent posts and indoor search games.

## 2) Prerequisites
- Food motivation (or toy motivation)
- Can work in low distraction without panicking
- Basic "start line" behavior (stand or sit calmly for 2–5s)

## 3) Outcomes
- Searches without frantic scanning
- Finds target odor reliably
- Indicates with consistent nose-hold (duration scales)

## 4) Skill inventory (IDs)
- NW_START_LINE
- NW_SEARCH_PATTERN
- NW_ODOR_IMPRINT
- NW_INDICATION_NOSEHOLD
- NW_FALSE_ALERT_CONTROL
- NW_SEARCH_END

## 5) Progression levels (criteria-based)
- L0: food-on-target (no odor), nose in zone 0.5–1s
- L1: odor paired with food, 1–2 boxes/posts
- L2: odor without visible food, 3–6 posts
- L3: simple puzzles (height change, corners, mild airflow)
- L4: multi-area searches, "no odor" blanks included

## 6) Default session plan
--8<-- "_atoms/protocols/session-start-ritual-001.md"

--8<-- "_atoms/protocols/session-structure-001.md"

--8<-- "_atoms/protocols/syllabus-8session-001.md"

## 7) Graduation battery
--8<-- "_atoms/templates/graduation-battery-template-001.md"

**Nosework-specific pass criteria (example)**
- Start line calm 5s
- 3 searches with 1 target + 2 blanks
- Indication nose-hold ≥ 2s, ≥ 85% success at D2
- No frantic false-alert trend

## 8) Setup mapping (optional)
- Sealed scent posts + clear indication zone
- Calm gate before/after searches

## Shared measurement blocks
--8<-- "_atoms/rubrics/proofing-ladder-001.md"

--8<-- "_atoms/rubrics/distraction-rubric-001.md"

--8<-- "_atoms/checklists/generalization-checklist-001.md"

--8<-- "_atoms/templates/logging-template-001.md"
