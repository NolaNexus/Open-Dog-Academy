# Tracking / Trail Foundations
Path: docs/classes/work-and-sport-foundations/07-tracking-trail-foundations.md
Status: draft
Updated: 2026-01-10

## 1) Purpose
Build calm following behavior: sustained sniffing, steady pace, and a clear end-of-trail indication.

## 2) Prerequisites
- Comfortable outdoors on varied surfaces
- Can work on a long line without panic

## 3) Outcomes
- Sustained low-arousal sniffing
- Follows simple trails reliably
- Indicates end-of-trail reward

## 4) Skill inventory (IDs)
- TR_START_RITUAL
- TR_FOLLOW_LINE
- TR_END_INDICATION

## 5) Progression levels
- L0: food drops every step (short, straight)
- L1: food drops every 2–3 steps (short turns)
- L2: longer straight + 1–2 turns
- L3: variable surfaces + longer gaps between food
- L4: novel environments + mild distractions

## 6) Default session plan
--8<-- "_atoms/protocols/session-start-ritual-001.md"

--8<-- "_atoms/protocols/session-structure-001.md"

--8<-- "_atoms/protocols/syllabus-8session-001.md"

## 7) Graduation battery
--8<-- "_atoms/templates/graduation-battery-template-001.md"

**Tracking-specific pass criteria (example)**
- Follows a 20–40m trail with 2 turns at D2
- Shows sustained sniffing with no frantic scanning

## 8) Setup mapping (optional)
- Long line + safe harness
- Simple markers for start/end zones

## Shared blocks
--8<-- "_atoms/concepts/arousal-management-001.md"

--8<-- "_atoms/templates/logging-template-001.md"
