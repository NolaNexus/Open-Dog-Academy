# Service-Style Task Foundations (Generalized)
Path: docs/classes/work-and-sport-foundations/06-service-task-foundations.md
Status: draft
Updated: 2026-01-10

## 1) Purpose
Train generalized task building blocks without claiming service-dog status. Modular behaviors: targeting, retrieving, pushing buttons, carrying, and "find" games.

## 2) Prerequisites
- Marker understood
- Can settle between reps

## 3) Outcomes
- Reliable targeting (nose/paw)
- Fetch/bring basics
- "Find it" object search
- Button press with cue discrimination

## 4) Skill inventory (IDs)
- TASK_TARGET_NOSE
- TASK_TARGET_PAW
- TASK_BUTTON_PRESS
- TASK_BRING_ITEM
- TASK_FIND_ITEM
- TASK_CARRY

## 5) Progression levels
- L0: single target behavior
- L1: target + release
- L2: two-step chains (target → fetch)
- L3: generalize props/locations
- L4: discriminate cues + light distractions

## 6) Default session plan
--8<-- "_atoms/protocols/session-start-ritual-001.md"

--8<-- "_atoms/protocols/session-structure-001.md"

--8<-- "_atoms/protocols/errorless-learning-001.md"

--8<-- "_atoms/protocols/syllabus-8session-001.md"

## 7) Graduation battery
--8<-- "_atoms/templates/graduation-battery-template-001.md"

**Task-foundations pass criteria (example)**
- Completes a 2-step chain (target → bring) at D2 with ≥ 80% success
- Performs a button press on cue with < 3 prompts across 10 reps

## 8) Setup mapping (optional)
- Limit active props (one at a time)
- Clear reset station between reps

## Shared blocks
--8<-- "_atoms/safety/safety-gating-001.md"

--8<-- "_atoms/checklists/generalization-checklist-001.md"

--8<-- "_atoms/templates/logging-template-001.md"
