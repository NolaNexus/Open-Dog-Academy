# Disc / Toy Play Skills (Structured Play as Training)
Path: docs/classes/work-and-sport-foundations/08-toy-play.md
Status: draft
Updated: 2026-01-10

## 1) Purpose
Turn play into a controllable reinforcement system: start/stop, out, re-engage, and cool-down. Useful for dogs who love toys and for sport motivation.

## 2) Prerequisites
- Enjoys toy play (otherwise this may not be worth emphasizing)
- Can take food for calm resets

## 3) Outcomes
- Play starts and ends on cue
- Dog outs/drops under arousal
- Dog can settle after play

## 4) Skill inventory (IDs)
- PLAY_START
- PLAY_OUT
- PLAY_RETURN
- PLAY_RESET
- PLAY_COOLDOWN

## 5) Progression levels
- L0: engage/disengage game (low intensity)
- L1: out + re-engage with food reset
- L2: short fetch/tug sequences with returns
- L3: add movement + mild distractions
- L4: sport-like patterns (disc throws / toy placements) with calm gate

## 6) Default session plan
--8<-- "_atoms/protocols/session-start-ritual-001.md"

--8<-- "_atoms/protocols/session-structure-001.md"

--8<-- "_atoms/protocols/reward-tiering-001.md"

--8<-- "_atoms/protocols/syllabus-8session-001.md"

## 7) Graduation battery
--8<-- "_atoms/templates/graduation-battery-template-001.md"

**Toy-play pass criteria (example)**
- Outs within 2s across 10 reps at D2
- Returns to handler or mat within 5s across 5 reps
- Settles within 30s after play ends

## 8) Setup mapping (optional)
- Clear play lane + safe footing
- Clear calm gate (mat) before re-engage

## Shared blocks
--8<-- "_atoms/safety/safety-gating-001.md"

--8<-- "_atoms/templates/logging-template-001.md"
