# Retrieve Foundations (Functional + Sport-Ready)
Path: docs/classes/work-and-sport-foundations/05-retrieve-foundations.md
Status: draft
Updated: 2026-01-10

## 1) Purpose
Develop clean retrieve mechanics: pick up, hold, deliver, release—useful for sport, service-style tasks, and household help.

## 2) Prerequisites
- Comfortable mouthing toys or objects
- Can trade willingly (or teach first)

## 3) Outcomes
- Calm pick-up (no frantic pouncing)
- Stable hold
- Clean delivery to hand / front position
- Reliable out/drop

## 4) Skill inventory (IDs)
- RET_PICKUP
- RET_HOLD
- RET_DELIVER_TO_HAND
- RET_FRONT_PRESENT
- RET_OUT
- RET_OBJECT_DISCRIM (optional)

## 5) Progression levels
- L0: mouth target object briefly
- L1: hold 3–5s
- L2: deliver from 1–3m
- L3: deliver from 10m with distractions
- L4: discriminate between 2–3 objects (optional)

## 6) Default session plan
--8<-- "_atoms/protocols/session-start-ritual-001.md"

--8<-- "_atoms/protocols/session-structure-001.md"

--8<-- "_atoms/protocols/reward-tiering-001.md"

--8<-- "_atoms/protocols/syllabus-8session-001.md"

## 7) Graduation battery
--8<-- "_atoms/templates/graduation-battery-template-001.md"

**Retrieve-specific pass criteria (example)**
- Picks up on cue within 3s (L2 distractions)
- Holds 5s without chewing
- Delivers to hand from 5m with ≥ 80% success
- Releases within 2s on cue

## 8) Setup mapping (optional)
- One retrieve lane; one object bin
- Clear reset spot between reps

## Shared blocks
--8<-- "_atoms/rubrics/latency-rubric-001.md"

--8<-- "_atoms/templates/logging-template-001.md"
