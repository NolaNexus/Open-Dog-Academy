# Open Dog Academy — Private Class Guide: Advanced Off-Leash Reliability
Filename: `class-guide-off-leash.md`
Version: 2.0 (private format + Diverse Dog Training reference integrated)
Date: 2026-01-09

This is a **course-syllabus + instructor guide** for **single-dog private off-leash reliability**.
Core idea: off-leash freedom is earned through **staged environments, proofing, and safety-first management**.

This guide integrates:
- Diverse Dog Training’s published advanced off-leash targets: **off-leash heeling, reliable recall, stay, leave it, drop it, and staying within a required distance under real-world distractions**.
- Long-line → off-leash transition methods described in guide-dog style recall guidance.
- “Cue hygiene” best practices (avoid testing, avoid repeating, always reinforce, don’t punish returns).

---

## 0) How to use this document
- Run as **1 private lesson/week** (45–60 min) + **daily micro practice**.
- Do not attempt off-leash in uncontained areas until criteria are met.
- Progress by **criteria**, not by calendar.

---

## 1) Course overview

### 1.1 Purpose
Train the complete off-leash safety stack:
- default check-ins + proximity control
- everyday recall + emergency recall
- emergency stop at distance
- impulse control (leave it / drop it / disengage)
- boundary/range control
- neutrality around real-world distractions

### 1.2 Audience
- Dogs who can work for reinforcement and tolerate a long line.
- Handler willing to train in controlled environments and follow local leash laws.

### 1.3 Delivery model (private)
- 8–12 weeks typical (criteria-based)
- 1×/week private lesson (45–60 min)
- Homework baseline: 10–20 min/day split into micro sessions
- Environment ladder:
  1) indoor / yard
  2) fenced field
  3) long line outdoors (low distraction)
  4) long line outdoors (moderate distraction)
  5) off-leash in enclosed areas only
  6) off-leash in broader spaces only if criteria + legality allow

---

## 2) Safety policy (shared)

See: `../standards/academy-safety-and-welfare.md`.

---

## 3) Measurement standard (shared)

See: `../standards/academy-standards.md`.

---

## 4) Required skill checklist (Diverse-aligned + wide-berth complete)

### 4.1 Engagement + proximity control
- Default check-in
- Name response / orient
- Handler range control (stay within working radius)

**Pass (minimum)**
- Check-in rate: ≥ 1 per 30s during 10 min movement at D1–D2
- Range control: remains within chosen radius for 10 min at D1–D2 without repeated cueing

### 4.2 Recall system (two recalls + positions)
- Everyday recall
- Emergency recall (distinct cue; jackpot history)
- Recall-to-position (front/heel/station)

**Pass (minimum)**
- Everyday recall: ≥ 90% from ≥ 20 m at D2 (controlled spaces)
- Emergency recall: ≥ 95% in controlled spaces; used sparingly
- Recall-to-position: ≥ 85% at D1–D2, holds 3s

### 4.3 Off-leash heeling (Diverse-aligned)
- Informal off-leash heel (life heel)
- Optional: formal heel patterns off leash in enclosed spaces

**Pass (minimum)**
- Maintains heel zone for 60s with turns/halts: ≥ 85% at D2 (enclosed)

### 4.4 Stay / stop (Diverse-aligned)
- Stay (sit/down/stand) under distraction
- Emergency stop at distance (down or stand)

**Pass (minimum)**
- Stay: 60s at 5–10 m at D2 (enclosed or long line)
- Stop: ≤ 2.0s response at ≥ 15 m, ≥ 85% at D2 (long line first)

### 4.5 Leave it + drop it (Diverse-aligned)
- Leave it (stationary)
- Leave it (moving)
- Drop/Out + Trade
- Automatic disengage

**Pass (minimum)**
- Moving leave it / disengage: returns attention within ≤ 2–3s, ≥ 85% at D2
- Drop/Out: ≤ 2.0s, ≥ 80–90% depending on arousal tier

### 4.6 “Required distance” / boundary skills (Diverse-aligned)
- Boundary/edge control
- “Go to” / send to spot
- Range limiter (stay within a required distance)

**Pass (minimum)**
- Boundary: ≥ 80–90% stops/returns at marked edge (context dependent)
- Go-to spot: ≥ 85% at 10 m, holds ≥ 10s (D2)
- Required distance: maintains within radius for 10 min (D2)

---

## 5) Core protocols (how skills are built)

### 5.1 Stage-first recall build (cue value + management)
1) Choose cue (fresh if prior recall is “optional”)
2) Charge cue (pair cue → reward repeatedly)
3) Leash follow game (dog chases you; reward)
4) Long line distance increases (10 ft → 15 → 20…)
5) Off-leash only in quiet enclosed spaces first
6) Add distractions gradually; if failures occur, step back a level

### 5.2 Long line → drag line → off leash (safe transition)
- Start practicing with the long line held.
- Then allow the dog to drag the long line in an enclosed area.
- Shorten the dragging line only when responses are immediate.
- If the dog misses the cue, pick up the line and reset; do not keep “calling into failure.”
- If distractions overwhelm, go back to the previous step.

### 5.3 Premack recall (recall earns return to fun)
- Recall → reward → release back to sniff/play
- This prevents recall from predicting “fun ends.”

### 5.4 Emergency recall rules
- Unique cue
- Few reps per week
- Massive reinforcement (“jackpot”)
- Never used casually

### 5.5 Emergency stop build (easy → distance → distraction)
- Start at 1–3 m, reward instantly
- Increase distance first, then distraction
- Keep reps very low to prevent conflict

---

## 6) Private lesson sequence (10-session default)
This is a recommended order; progress by criteria.

### Session 1 — Check-ins + cue charging + short recalls
### Session 2 — Long line handling + recall away from sniff (easy)
### Session 3 — Collar grab comfort + recall-to-position
### Session 4 — Stay foundations + stop-and-wait
### Session 5 — Emergency recall introduction (few reps) + release patterns
### Session 6 — Moving leave-it + disengage work
### Session 7 — Stop at distance (long line) + range game
### Session 8 — Off-leash heeling (enclosed) + boundary intro
### Session 9 — Real-world D2 proofs (multi-context, controlled)
### Session 10 — Graduation battery + off-leash permission rules

---

## 7) Graduation battery (10–15 minutes, minimalist)
- 10 min movement sample (check-in rate + range control)
- Everyday recall: 5 reps from varied distances
- Emergency recall: 1–2 reps max
- Emergency stop: 3 reps at distance
- Moving leave-it/disengage: 5 reps
- Drop it / trade: 3 reps
- Off-leash heel (enclosed): 60s

**Pass:** meets the pass criteria in Section 4 at D2 in controlled environments.

---

## 8) Maintenance plan
- Daily: reinforce check-ins (life rewards)
- 3×/week: 5–10 min recall + stop tune-up
- Monthly: run graduation battery as an audit
- After major routine changes: temporarily reduce difficulty and rebuild reinforcement history

---


---

## Optional: Remote cue device integration (vibrate / beep / flashlight)
- Policy + conditioning ladder: `../standards/remote-cue-devices.md`
- Optional skill modules (if used):
  - [RCD_WEAR_COMFORT](../skills/rcd/RCD_WEAR_COMFORT.md)
  - [RCD_SIGNAL_ORIENT](../skills/rcd/RCD_SIGNAL_ORIENT.md)
  - [RCD_SIGNAL_RECALL](../skills/rcd/RCD_SIGNAL_RECALL.md)
  - [RCD_SIGNAL_STOP](../skills/rcd/RCD_SIGNAL_STOP.md)
  - [RCD_SIGNAL_PLACE](../skills/rcd/RCD_SIGNAL_PLACE.md)

## References (format + off-leash frameworks)

- Diverse Dog Training — Off Leash Reliability (skill targets: off-leash heel, reliable recall, stay, leave it, drop it, required distance under distractions)
  - https://www.diversedogtraining.com/off-leash-reliability
- Guide Dogs for the Blind — Recall (long line → drag line → off-leash progression; step back if misses; increase rewards when transitioning off leash)
  - https://www.guidedog.org/PuppyRaising/PuppyRaiserManual/PuppyDevelopment/Recall.aspx
- Whole Dog Journal — How to teach recall (cue hygiene; don’t “test”; long line progression; add distance gradually)
  - https://www.whole-dog-journal.com/training/how-to-teach-a-dog-to-come-when-called/
- AKC — Reliable recall tips (reward check-ins; avoid repeating cue; always reward; add “gotcha”/collar hold occasionally)
  - https://www.akc.org/expert-advice/training/teach-dog-to-come-when-called/
  - https://www.akc.org/expert-advice/training/reliable-recalls-how-to-train-your-dog-to-come-when-called/
- Valley Canine — Reliable Recall course outline (example: recall phases, emergency recall, boundaries, off-leash manners under distraction)
  - https://www.valleycanine.net/reliable-recall-course/
- Syllabus essentials
  - https://cetl.uconn.edu/resources/design-your-course/creating-your-syllabus/
- Lesson plan components
  - https://americanenglish.state.gov/files/ae/resource_files/lesson_planning_101-pre-recording_0.pdf

