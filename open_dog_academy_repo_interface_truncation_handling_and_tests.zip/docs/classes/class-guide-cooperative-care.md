# Open Dog Academy — Class Guide: Cooperative Care (Consent → Grooming/Vet Handling)
Filename: `class-guide-cooperative-care.md`
Version: 1.0
Date: 2026-01-10

This is a **course-syllabus + instructor guide** hybrid designed to be:
- **Repeatable**
- **Measurable**
- **Modular**

---

## 0) How to use this document
- 1 session/week (45–60 min) + daily 5–10 minute micro-practice.
- Select 1–3 skills per session.
- Progress is criteria-based (not time-based).
- For group teaching, pair with `instructor-guides/` scripts.

---

## 1) Course overview

**Purpose:** Teach consent-based handling to reduce stress and bite risk during grooming and vet care.

**Outcomes:**
- Start button + chin rest as consent behaviors
- Calm handling of paws, ears, mouth
- Brush, nail, and muzzle conditioning
- Simulated exam sequence under consent

---

## 2) Prerequisites + materials
Prereqs: marker understanding recommended  
Materials: treats, towel target, brush/comb, nail tool, basket muzzle

---

## 3) Measurement standard (shared)
See: `../standards/academy-standards.md`.

---

## 4) Skill inventory
- [CC_START_BUTTON](../skills/cc/CC_START_BUTTON.md)
- [CC_CHIN_REST](../skills/cc/CC_CHIN_REST.md)
- [CC_PAWS](../skills/cc/CC_PAWS.md)
- [CC_EARS](../skills/cc/CC_EARS.md)
- [CC_MOUTH](../skills/cc/CC_MOUTH.md)
- [CC_BRUSH](../skills/cc/CC_BRUSH.md)
- [CC_NAILS](../skills/cc/CC_NAILS.md)
- [CC_MUZZLE](../skills/cc/CC_MUZZLE.md)
- [CC_INJECTIONS_SIM](../skills/cc/CC_INJECTIONS_SIM.md)

---

## 5) Progression levels
L0 consent foundation → L1 handling → L2 tools/duration → L3 vet realism

---

## 6) Graduation battery (10–15 min)
Start button offered; basic checks; 30 sec brushing; muzzle wear 2 minutes; mock exam sequence.

---

## 7) Maintenance
2–3x/week 2-minute refresh; monthly mock exam.

---

## 8) Group teaching notes
Coop care in groups requires calm dogs, spacing, and strict opt-out respect.
Use Level 1–2 instructor guides and keep sessions short.
