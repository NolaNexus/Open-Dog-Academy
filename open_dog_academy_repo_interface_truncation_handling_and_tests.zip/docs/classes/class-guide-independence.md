# Open Dog Academy — Class Guide: Independence (Crate Comfort → Alone-Time Resilience)
Filename: `class-guide-independence.md`
Version: 1.0
Date: 2026-01-10

This is a **course-syllabus + instructor guide** hybrid designed to be:
- **Repeatable**
- **Measurable**
- **Modular**

---

## 0) How to use this document
- 1 session/week (45–60 min) + daily 5–10 minute micro-practice.
- Select 1–3 skills per session.
- Progress is criteria-based (not time-based).
- For group teaching, pair with `instructor-guides/` scripts.

---

## 1) Course overview

**Purpose:** Build confinement and alone-time resilience using gradual, reward-based plans.

---

## 2) Materials
Crate or safe room/pen, camera helpful, chew/lick options, high-value food.

---

## 3) Measurement standard (shared)
See: `../standards/academy-standards.md`.

---

## 4) Skill inventory
- [IND_CRATE](../skills/ind/IND_CRATE.md)
- [IND_ALONE](../skills/ind/IND_ALONE.md)
- [IND_SETTLE_SOLO](../skills/ind/IND_SETTLE_SOLO.md)
- [IND_CONFINEMENT](../skills/ind/IND_CONFINEMENT.md)
- [IND_DEPARTURE_CUES](../skills/ind/IND_DEPARTURE_CUES.md)
- [IND_RECOVERY_ROUTINE](../skills/ind/IND_RECOVERY_ROUTINE.md)

---

## 5) Progression levels
L0 positive confinement → L1 micro absences → L2 departure cue neutrality → L3 household integration

---

## 6) Graduation battery
10 min calm confinement; 10 min calm absence; calm departure cues; settles while you do a task 10 min.

---

## 7) Group teaching notes
Teach the *starter steps* in meetups and send home graduated plans.
Never push a dog into distress in a group context.
