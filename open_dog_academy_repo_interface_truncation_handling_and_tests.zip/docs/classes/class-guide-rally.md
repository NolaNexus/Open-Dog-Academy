# Open Dog Academy — Private Class Guide: Rally Foundations (Station Flow + Precision)
Filename: `class-guide-rally.md`  
Version: 1.0  
Date: 2026-01-09  
Delivery: **single-dog private**, criteria-based, data-friendly

Rally here is treated as:
- **obedience in motion**
- **station-to-station fluency**
- **handler mechanics + recovery**
- designed to map cleanly onto your **Rally/Obedience Lane** (questable stations)

---

## 0) How to use this guide
- 1×/week private lesson (45–60 min) + daily micro-practice
- Work 1–3 station skills/session
- Progress by criteria; keep sequences short until precision stabilizes

---

## 1) Measurement standard (shared)
Per rep:
`skill_id, context, distraction_tier, distance_m, duration_s, correct_bool, latency_s, error_type, notes`

Distraction tiers:
D0 none, D1 mild, D2 moderate, D3 high

Default pass thresholds:
Accuracy ≥ 90% over 20 trials; latency ≤ 2.0s; 3 contexts; graduation at D2

### Rally-specific metrics
- `position_error_cm` (heel offset estimate)
- `station_prompt_count` (handler prompts per station)
- `sequence_length` (stations)
- `recovery_time_s` (time to reset after an error)

---

## 2) Outcomes (measurable)
By graduation, the dog can:
- start a rally run in working state
- maintain an informal heel position through turns and halts
- perform common station behaviors (sit/down/front/finish/pivot)
- complete a short course with stable engagement and fast recovery

---

## 3) Skill inventory (IDs)
### Core
- RALLY_START_LINE (ready position 3–5s)
- RALLY_HEEL_LIFE (informal heel / reinforcement zone)
- RALLY_TURNS_L / RALLY_TURNS_R
- RALLY_UTURN_180
- RALLY_HALT_SIT
- RALLY_SIT / RALLY_DOWN / RALLY_STAND (as stations)
- RALLY_FRONT
- RALLY_FINISH_L / RALLY_FINISH_R
- RALLY_PIVOT (rear-end awareness)
- RALLY_STATION_FOCUS (commit to station task)
- RALLY_RECOVERY_RESET (reset protocol)
- RALLY_RELEASE (clean end-of-run)

### Optional advanced
- RALLY_SPEED_CHANGES
- RALLY_DISTANCE_HEEL (handler distance within lane)
- RALLY_SEND_TO_MAT (station)
- RALLY_DISTRACTION_PROOF (people/dogs at distance)

---

## 4) Pass criteria (minimum)
### Heel (life heel)
- Pass: maintain heel zone for 60s with turns/halts, ≥ 85% at D2
- Latency: responds to turn/halt cues ≤ 2s median

### Turns/halts
- Pass: correct turn response ≥ 90% at D1–D2
- Halt sit: sits within 2s, ≥ 90%

### Front + finish
- Pass: front position within tolerance, ≥ 85% at D2
- Finish L/R: correct side ≥ 80–85% at D2

### Pivot (rear-end awareness)
- Pass: can pivot 90–180 degrees with handler, ≥ 80% at D1–D2

### Sequence fluency
- Pass: 10-station mini-course at D2 with:
  - overall station success ≥ 85%
  - recovery_time_s ≤ 10s after any error (reset protocol works)

---

## 5) Private session template (repeatable)
- Warmup: calm gate + 30s heel zone + 1 easy station
- Block A: new/clean station skill
- Block B: proof one variable (distance OR distraction OR duration)
- Block C: mini-sequence 2–6 stations + recovery practice
- Debrief: homework + metric target

---

## 6) 10-session default sequence (private)

### Session 1 — Start line + heel zone foundations
Targets: RALLY_START_LINE, RALLY_HEEL_LIFE  
Homework: 2×/day 2–3 min reinforcement zone walk

### Session 2 — Halts + sits + left/right turns
Targets: RALLY_HALT_SIT, RALLY_TURNS_L/R  
Homework: 10 halts/day in daily life (paid)

### Session 3 — Front behavior + reward placement
Targets: RALLY_FRONT  
Homework: 1–2 min front reps/day

### Session 4 — Finish left + finish right
Targets: RALLY_FINISH_L/R  
Homework: 10 reps/day split (5+5)

### Session 5 — Pivot + rear-end awareness
Targets: RALLY_PIVOT  
Homework: 1–2 min pivot work/day

### Session 6 — Two-station → five-station sequences
Targets: RALLY_STATION_FOCUS, RALLY_RECOVERY_RESET  
Homework: 3 mini sequences/week (3–5 stations)

### Session 7 — Downs/stands as stations + speed change intro
Targets: RALLY_DOWN, RALLY_STAND, optional RALLY_SPEED_CHANGES  
Homework: station changes in yard (easy)

### Session 8 — Distraction proofing (D2) + handler neutrality
Targets: RALLY_DISTRACTION_PROOF, RALLY_HEEL_LIFE  
Homework: 2 proofing walks/week; log position errors

### Session 9 — Full mini-course (10–15 stations)
Targets: sequence fluency + recovery  
Homework: 1 full run/week + short station drills

### Session 10 — Graduation battery + maintenance plan
Run standardized battery (Section 7) + define monthly audits.

---

## 7) Graduation battery (10–15 min)
- Start line 5s (D2)
- Heel pattern 60–90s (turns, halt sit, speed change optional)
- Front + finish (both directions if trained)
- Pivot 180 degrees
- 10-station mini-course at D2

**Pass:** meets criteria in Section 4.

---

## 8) Error taxonomy (for logs)
- `heel_drift`
- `lagging`
- `forging`
- `wide_turn`
- `missed_station`
- `extra_prompt`
- `slow_recovery`
- `arousal_spike`
- `stress_withdrawal`

---

## 9) Station mapping (campus/hardware)
### Recommended modules
- Rally/Obedience lane with **station stands** (signs/prompts)
- Floor markers for heel zone + turns
- Pivot platform / box
- Start line tile + overhead state light
- Optional: button to request “start run” (dog ask)

### Automation-friendly events
- `RALLY_RUN_START` (RFID + start line held)
- `RALLY_STATION_COMPLETE` (manual tap or camera inference)
- `RALLY_RESET` (handler presses reset button; logs error)
- `RALLY_RUN_END` (release)

---

## 10) Maintenance plan
- 2×/week: 5–10 min “mini course”
- Daily: 5–10 life halts + heel moments
- Monthly: graduation battery audit

---
End of rally class guide.
