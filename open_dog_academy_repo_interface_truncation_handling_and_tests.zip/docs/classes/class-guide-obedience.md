# Open Dog Academy — Private Class Guide: Obedience (Basic → Intermediate → Advanced)
Filename: `class-guide-obedience.md`
Version: 2.0 (private format + basic added)
Date: 2026-01-09

This is a **course-syllabus + instructor guide** hybrid for **single-dog private training**.
Design goals:
- **Repeatable** (any handler can run it)
- **Measurable** (data-friendly pass criteria)
- **Modular** (can be taught as a 6–12 week program or self-paced)

---

## 0) How to use this document
- Run as **1 private session/week** (45–60 min) + daily micro-practice.
- Each session selects **1–3 skills** only.
- Progress by **criteria**, not by calendar.

---

## 1) Course overview

### 1.1 Purpose
Build a dog who can:
- communicate clearly via cues and releases
- maintain composure under distraction
- perform obedience skills with **duration / distance / distraction (DDD)** proofing

### 1.2 Audience
- Dogs of any age who can eat treats and engage with the handler.
- Handlers who can practice **~10–20 minutes/day** split into micro-sessions.

### 1.3 Delivery model (private)
**Recommended cadence**
- 1×/week private lesson (45–60 min)
- 5–6 days/week homework
- 1 lighter day (de-load) as needed (stress/over-arousal trend)

**Session time split**
- 5–10 min: regulation + warmup
- 25–35 min: training blocks (2–3 blocks)
- 5–10 min: real-world application + homework plan

---

## 2) Prerequisites & materials

### 2.1 Prerequisites (minimum)
- Can take food calmly
- Comfortable wearing collar/harness
- Can work in a quiet space with minimal distractions

### 2.2 Required gear (generalized)
- Flat collar or well-fitted harness
- 6 ft leash
- Long line 15–30 ft (for later proofing)
- Treat pouch + high-value food
- Mat/bed (“place”)
- Optional: toy/tug

### 2.3 Reinforcement rules (academy default)
- Marker-based teaching (click/word)
- Reward placement steers body position
- Keep reps short; avoid drilling
- No punishment-based pressure during learning reps

---

## 3) Measurement standard (shared)

See: `../standards/academy-standards.md`.

---

## 4) Skill inventory (ID-based)

This class references one file per skill under `../skills/ob/`.

### OB skills (core)
- [OB_NAME — Name response / orient to handler](../skills/ob/OB_NAME.md)
- [OB_MARKER — Marker understanding (click/yes)](../skills/ob/OB_MARKER.md)
- [OB_TOUCH — Hand target (touch)](../skills/ob/OB_TOUCH.md)
- [OB_SIT — Sit](../skills/ob/OB_SIT.md)
- [OB_DOWN — Down](../skills/ob/OB_DOWN.md)
- [OB_STAND — Stand](../skills/ob/OB_STAND.md)
- [OB_LOOSE_LEASH — Loose leash foundations (reinforcement zone)](../skills/ob/OB_LOOSE_LEASH.md)
- [OB_PLACE — Place / mat (settle)](../skills/ob/OB_PLACE.md)
- [OB_RECALL — Recall (foundations)](../skills/ob/OB_RECALL.md)
- [OB_LEAVE_IT — Leave it (impulse control)](../skills/ob/OB_LEAVE_IT.md)
- [OB_DROP — Drop / Out (trade-based)](../skills/ob/OB_DROP.md)
- [OB_HANDLING — Handling tolerance starter](../skills/ob/OB_HANDLING.md)
- [OB_COLLAR_GRAB — Collar grab comfort](../skills/ob/OB_COLLAR_GRAB.md)
- [OB_STAY — Stay (duration)](../skills/ob/OB_STAY.md)
- [OB_DOOR_MANNERS — Door manners / threshold control](../skills/ob/OB_DOOR_MANNERS.md)
- [OB_HEEL — Heel foundations / life heel](../skills/ob/OB_HEEL.md)
- [OB_RELEASE — Release cue understanding](../skills/ob/OB_RELEASE.md)
- [OB_RECALL_TO_POS — Recall to position (front/heel)](../skills/ob/OB_RECALL_TO_POS.md)

---

## 5) Private session template (repeatable)

### 4.1 Opening (5–10 min)
- Gear check
- Regulation rep: mat settle / calm gate
- 3 easy wins (touch, sit, hand target)

### 4.2 Training blocks (2–3 blocks, 8–12 min each)
Each block:
- Teach/clean skill (high success)
- Proof ONE variable only (distance OR duration OR distraction)
- Stop while dog wants more

### 4.3 Application (5–10 min)
- “Life rep”: apply skill in a realistic context (doorway, leash walk, yard)

### 4.4 Homework plan (5 min)
- 2–3 micro-drills
- 1 metric target (e.g., “sit latency ≤2s in yard”)

---

## 5) Curriculum map (three levels)

### Level 1 — Basic Obedience (Foundation)
**Goal:** cues are understood; reinforcement history is strong; dog is optimistic about training.

#### Required skill set (Basic)
- [OB_NAME — Name response / orient to handler](../skills/ob/OB_NAME.md)
- [OB_MARKER — Marker understanding (click/yes)](../skills/ob/OB_MARKER.md)
- [OB_TOUCH — Hand target (touch)](../skills/ob/OB_TOUCH.md)
- [OB_SIT — Sit](../skills/ob/OB_SIT.md)
- [OB_DOWN — Down](../skills/ob/OB_DOWN.md)
- [OB_STAND — Stand](../skills/ob/OB_STAND.md)
- [OB_LOOSE_LEASH — Loose leash foundations (reinforcement zone)](../skills/ob/OB_LOOSE_LEASH.md)
- [OB_PLACE — Place / mat (settle)](../skills/ob/OB_PLACE.md)
- [OB_RECALL — Recall (foundations)](../skills/ob/OB_RECALL.md)
- [OB_LEAVE_IT — Leave it (impulse control)](../skills/ob/OB_LEAVE_IT.md)
- [OB_DROP — Drop / Out (trade-based)](../skills/ob/OB_DROP.md)
- [OB_HANDLING — Handling tolerance starter](../skills/ob/OB_HANDLING.md)

#### Basic pass criteria (minimum)
- Each core cue: ≥ 80% at D0–D1, latency ≤ 3.0s
- Place: 20s hold at D0, 10s at D1
- Loose leash: can walk 20 steps in the reinforcement zone at D0–D1 (≥ 80% of steps)

---

### Level 2 — Intermediate Obedience (Functional Reliability)
**Goal:** skills work in daily life with moderate distractions.

#### Required skill set (Intermediate)
- Sit/down/stand: fluent
- Stay: duration + mild distance
- Heel foundations (informal → formal option)
- Recall to front or hand target
- Finish left/right (optional)
- Leave it: stationary + mild movement
- Drop it: under mild arousal
- Place: 60s with handler moving
- Door manners (wait / release)
- Neutrality around people/dogs at distance (focus + disengage)

#### Intermediate pass criteria (minimum)
- Core cues: ≥ 90% at D1–D2, median latency ≤ 2.5s
- Stay: 60s at 5–10 m at D1; 30s at D2
- Recall (short-to-mid): ≥ 90% at D2 in controlled environments

---

### Level 3 — Advanced Obedience (Wide Berth)
**Goal:** advanced control options (pet + sport foundations), strong proofing, clean chains.

#### Advanced skill library (choose based on goals)
- Formal heel patterns (turns/halts/pace)
- Distance control (position changes at distance)
- Stand for exam / cooperative handling
- Retrieve foundations (hold → deliver)
- Go-to/send to place at distance
- Go-out to target (optional)
- Signals (hand-only) (optional)
- Directed retrieve/jumps (optional competition)
- Scent discrimination (optional)

#### Advanced pass criteria (suggested)
- Core chains (heel → sit → recall → finish): ≥ 85% at D2
- Advanced options: ≥ 70–85% depending on skill complexity (logged separately)

---

## 7) Lesson sequence (private) — 10-session default
This is a recommended order for one-dog private work. Adjust by criteria.

### Session 1 — Markers + engagement + sit/down + touch
### Session 2 — Loose leash foundations + place
### Session 3 — Recall foundations + collar grab comfort
### Session 4 — Leave it + drop/trade
### Session 5 — Stay (duration) + door manners
### Session 6 — Heel foundations + “life heel” turns/halts
### Session 7 — Stand + handling tolerance (exam starter)
### Session 8 — Recall to position + beginnings of chains
### Session 9 — Proofing plan (D2 exposure) + error repair
### Session 10 — Graduation battery + maintenance plan

---

## 8) Graduation battery (10–15 minutes, minimalist)
- Sit/down/stand in sequence (D2)
- Place 60s (D2)
- Stay 60s @ 5–10 m (D1–D2)
- Loose leash 1 minute (D2)
- Recall to front/target (D2)
- Leave it + drop/trade (D2)
- Optional: heel pattern 60–90s

**Pass:** meets default thresholds for the “Required skill set” of the chosen level.

---

## 9) Maintenance plan
- Daily: 2–5 “life reps” (doorway, leash start, mat settle)
- 3×/week: 5–10 min skills battery lite
- Monthly: run graduation battery as an audit

---

## References (format + scope)
```text
Syllabus essentials (overview/objectives/assessments/schedule):
https://cetl.uconn.edu/resources/design-your-course/creating-your-syllabus/

Lesson plan components (objective/materials/procedure/assessment):
https://americanenglish.state.gov/files/ae/resource_files/lesson_planning_101-pre-recording_0.pdf

AKC class/curriculum pattern (example 8-week outline + homework expectation):
https://www.akc.org/products-services/training-programs/canine-good-citizen/links/curriculum-sample/

AKC obedience scope examples:
https://www.akc.org/sports/obedience/getting-started/classes/