# Open Dog Academy — Private Class Guide: Shaping + Arcade Literacy (Buttons, Patterns, Chains)
Filename: `class-guide-shaping-arcade.md`  
Version: 1.0  
Date: 2026-01-09  
Delivery: **single-dog private**, criteria-based, data-friendly

This guide builds the learning engine that powers your campus “dog arcade”:
- **offer behavior**
- **stay in the game** (frustration tolerance)
- **nose/paw targeting** (inputs)
- **prompt-response games** (lights, sounds)
- **chaining** + **variable reinforcement** (safe anti-compulsion rules)

---

## 0) How to use this guide
- 1×/week private lesson (45–60 min) + daily 3–10 min micro sessions
- Keep shaping sessions **short** (1–3 minutes) and stop early
- Track frustration and compulsion risk (anti-gadget trap)

---

## 1) Measurement standard (shared)
Per rep:
`skill_id, context, distraction_tier, distance_m, duration_s, correct_bool, latency_s, error_type, notes`

Distraction tiers:
D0 none, D1 mild, D2 moderate, D3 high

Default pass thresholds:
Accuracy ≥ 90% over 20 trials; latency ≤ 2.0s; 3 contexts; graduation at D2

### Shaping/arcade-specific metrics
- `offer_rate_per_min` (how often dog offers behaviors)
- `frustration_signs_bool` (whine, paw slam, quit)
- `reset_time_s` (time to re-engage after an error)
- `button_force_est` (optional; for hardware durability)
- `compulsion_flag` (repetitive pressing without prompt)

---

## 2) Safety + anti-compulsion rules
Arcade systems can accidentally create “slot machine brain.” We prevent that.

### 2.1 Core rules
- Rewards are **earned by matching a prompt**, not by spamming.
- Add a **cooldown** after each completed trial (2–10s depending on arousal).
- If compulsion appears: reduce repetition, increase sniff breaks, reduce variable rewards.

### 2.2 Handler override
- Human can pause the arcade (maintenance, safety, recovery).
- Dog requests (“dog ask”) should not allow endless play without supervision.

---

## 3) Outcomes (measurable)
By graduation, the dog can:
- offer behaviors calmly (not frantic)
- target with nose and paw on cue
- press the correct button based on a prompt (color/pattern)
- complete 2–3 step chains before reward
- tolerate variable reward schedules without escalating

---

## 4) Skill inventory (IDs)
### Shaping engine
- SHAPE_MARKER_FLUENT (marker means “you got it”)
- SHAPE_OFFERING (offer behaviors)
- SHAPE_STAY_IN_GAME (frustration tolerance)
- SHAPE_RESET (reset protocol)

### Inputs (buttons/targets)
- ARC_NOSE_TARGET
- ARC_PAW_TARGET
- ARC_BUTTON_PRESS (general)
- ARC_BUTTON_HOLD (optional)

### Prompt-response literacy
- ARC_PROMPT_ATTEND (looks at prompt light)
- ARC_MATCH_COLOR (press matching color button)
- ARC_MATCH_PATTERN (press pattern sequence)
- ARC_GO_NOGO (press only when lit)

### Chaining + rewards
- ARC_CHAIN_2
- ARC_CHAIN_3
- ARC_VARIABLE_REWARD
- ARC_COOLDOWN_ACCEPT (settle during cooldown)

---

## 5) Pass criteria (minimum)
### Offering + staying in game
- SHAPE_OFFERING pass: offer_rate_per_min ≥ 6 at D0–D1 without escalating frustration
- SHAPE_STAY_IN_GAME pass: after 3 misses, re-engages within ≤ 10s, ≥ 80%

### Nose/paw targeting
- ARC_NOSE_TARGET pass: ≥ 90% at D1–D2, latency ≤ 2s
- ARC_PAW_TARGET pass: ≥ 85% at D1–D2, latency ≤ 2.5s

### Prompt-response
- ARC_GO_NOGO pass: presses only when lit ≥ 85% at D1–D2
- ARC_MATCH_COLOR pass: ≥ 80% across 20 trials at D1–D2 (this is hard; 80% is solid)

### Chaining
- ARC_CHAIN_2 pass: completes 2-step chain ≥ 85% at D1–D2
- ARC_CHAIN_3 pass: ≥ 70–80% at D1–D2 (complexity increases)

### Variable reward (safe)
- ARC_VARIABLE_REWARD pass: maintains stable arousal with random reward (e.g., 60–90% rewarded) for 3 sessions, no compulsion flag trend

---

## 6) Private session template (repeatable)
- Warmup: calm gate + 2 easy target reps
- Block A: shaping engine (offering / stay-in-game)
- Block B: input skill (nose or paw)
- Block C: prompt-response mini game (5–15 trials max)
- Debrief: define cooldown and daily micro session plan

---

## 7) 10-session default sequence (private)

### Session 1 — Marker fluency + offering
Targets: SHAPE_MARKER_FLUENT, SHAPE_OFFERING  
Homework: 2×/day 1–2 min “capture offers”

### Session 2 — Nose target → button press (single button)
Targets: ARC_NOSE_TARGET, ARC_BUTTON_PRESS  
Homework: 10 reps/day (split); stop early

### Session 3 — Paw target (separate) + impulse control on button
Targets: ARC_PAW_TARGET, SHAPE_STAY_IN_GAME  
Homework: 5–10 paw reps/day, low volume

### Session 4 — Go/No-Go (press only when lit)
Targets: ARC_GO_NOGO, ARC_PROMPT_ATTEND  
Homework: 10–15 trials/day max + cooldown practice

### Session 5 — Match color (two buttons)
Targets: ARC_MATCH_COLOR (easy mode), ARC_COOLDOWN_ACCEPT  
Homework: 10 trials/session; keep accuracy high

### Session 6 — Match color (3–4 buttons) + reset protocol
Targets: ARC_MATCH_COLOR, SHAPE_RESET  
Homework: 2–3 short sessions/week; log accuracy

### Session 7 — Pattern memory (2-step) + chain-2
Targets: ARC_MATCH_PATTERN (intro), ARC_CHAIN_2  
Homework: 5–10 trials/session, 3×/week

### Session 8 — Chain-3 + random chance reward (carefully)
Targets: ARC_CHAIN_3, ARC_VARIABLE_REWARD  
Homework: 2×/week only; watch compulsion flags

### Session 9 — Generalization (new room / different button spacing)
Targets: generalization at D1–D2  
Homework: 1 new-context session/week

### Session 10 — Graduation battery + maintenance plan
Run standardized battery (Section 8) + define anti-compulsion monitoring rules.

---

## 8) Graduation battery (10–12 min)
- Offering: 1 minute capture session (offer rate logged)
- Nose target: 10 reps
- Paw target: 10 reps
- Go/No-Go: 20 trials
- Match color: 20 trials (2–3 colors)
- Chain-2: 10 trials

**Pass:** meets criteria in Section 5 at D1–D2 without compulsion trend.

---

## 9) Error taxonomy (for logs)
- `no_offer`
- `frustration_escalation`
- `button_spam`
- `wrong_button`
- `ignored_prompt`
- `slow_reset`
- `over_arousal`
- `stress_withdrawal`

---

## 10) Station mapping (campus/hardware)
### Recommended modules
- Large HDPE-capped piezo buttons (nose+paw safe)
- Overhead state light (idle/ready/in-game/cooldown)
- Prompt display (color + brightness)
- RFID gating (dog present) + human override
- Reward bank (treat/topper) with cooldown governor
- Camera for behavior auditing + compulsion monitoring

### Automation-friendly events
- `ARC_IDLE`
- `ARC_READY` (RFID present)
- `ARC_TRIAL_START` (prompt shown)
- `ARC_CORRECT` / `ARC_INCORRECT`
- `ARC_CHAIN_COMPLETE`
- `ARC_COOLDOWN`
- `ARC_COMPULSION_FLAG` (spam detected)

---

## 11) Maintenance plan
- 2–3×/week: 5-minute arcade session (short)
- Weekly: 1 session focused on “stay in game”
- If button spam rises: reduce trials, increase cooldown, add sniff breaks, return to Go/No-Go

---
End of shaping + arcade class guide.
