# Open Dog Academy — Private Class Guide: Nosework (Foundations → Odor → Indication)
Filename: `class-guide-nosework.md`  
Version: 1.0  
Date: 2026-01-09  
Delivery: **single-dog private**, criteria-based, data-friendly

Nosework in this academy is built around:
- **calm searching**
- **clear indication** (default: **nose-hold**)
- **blanks** (no-odor searches) to prevent guessing
- **repeatable station design** (sealed scent posts, start line, reward bank)

---

## 0) How to use this guide
- Run as **1 private session/week** (45–60 min) + **daily micro practice**.
- Each session selects **1–3 micro-skills**.
- Progress by criteria (pass thresholds), not by calendar.

---

## 1) Measurement standard (shared)
Per rep log:
`skill_id, context, distraction_tier, distance_m, duration_s, correct_bool, latency_s, error_type, notes`

Distraction tiers:
- D0 none, D1 mild, D2 moderate, D3 high

Default pass thresholds (unless overridden):
- Accuracy ≥ 90% over 20 trials
- Median latency ≤ 2.0s (search skills often measured by time-to-source instead)
- 3 contexts
- Graduation at D2

### Nosework-specific metrics
Add these fields when useful:
- `search_time_s` (start line → indication)
- `false_alert_bool`
- `source_proximity_cm` (how close nose is to source at indication)
- `indication_duration_s`
- `handler_prompted_bool`

---

## 2) Safety + welfare rules
- Keep arousal **low-to-moderate** (nosework should regulate, not spike).
- Avoid slippery surfaces, sharp edges, unstable props.
- Do not “help” by pointing repeatedly; allow the dog to solve.
- Keep reps short; end while the dog wants more.

---

## 3) Outcomes (measurable)
By graduation, the dog can:
- start a search calmly on cue
- search a defined area systematically (without frantic scanning)
- locate target odor in a simple search field
- perform a consistent **nose-hold indication** at source
- complete **blank searches** without guessing

---

## 4) Skill inventory (IDs)
### Core skills
- NW_START_LINE (calm ready position 2–5s)
- NW_RELEASE_SEARCH (release into search)
- NW_SEARCH_PATTERN (systematic searching)
- NW_ODOR_IMPRINT (odor recognition)
- NW_SOURCE_COMMIT (commit to source area)
- NW_IND_NOSEHOLD (nose-hold indication)
- NW_HANDLER_STILL (handler neutrality / no help)
- NW_END_SEARCH (return to handler / station)
- NW_BLANK_OK (blank searches without false alert)
- NW_RESET_PROTOCOL (how to reset after errors)

### Optional advanced skills
- NW_HEIGHT (height change searches)
- NW_AIRFLOW (corners, mild airflow problems)
- NW_MULTIPLE_AREAS (room-to-room transitions)
- NW_DISTRACTION_RESILIENCE (food odors, toys present)

---

## 5) Pass criteria (what “good” looks like)
### NW_START_LINE
- Pass: holds start line 3s, ≥ 90% at D1–D2, no creeping.

### NW_ODOR_IMPRINT
- Pass: chooses target box/post ≥ 85% in simple 2-choice setups at D0–D1.

### NW_IND_NOSEHOLD (nose-hold)
- Pass: nose within 5 cm of source, hold ≥ 2.0s, ≥ 85% at D1–D2.
- Honors: hold ≥ 3–5s with steady body, ≥ 85% at D2.

### NW_BLANK_OK (blanks)
- Pass: completes 2 blank searches without false alert in a 4-search set, repeated across 3 sessions.

### Search performance (field-level)
- Pass: finds 1 hide in ≤ 60s in simple fields (3–6 posts) at D2, ≥ 80–85% success, no escalating false alerts.

---

## 6) Private session template (repeatable)
- Warmup (5–8 min): calm gate → 2 easy wins (touch, mat) → start line rep
- Block A (8–12 min): teach/clean micro-skill (e.g., nose-hold shaping)
- Block B (8–12 min): search field reps (2–4 reps only)
- Block C (8–12 min): blanks + reset protocol
- Debrief (5 min): homework + one metric target

---

## 7) 10-session default sequence (private)
> Progress by criteria. Some dogs will need 2–3 sessions per stage; that’s normal.

### Session 1 — “Box game” foundation (no odor yet)
Targets: NW_START_LINE, NW_RELEASE_SEARCH, NW_SEARCH_PATTERN  
Drills: 1–2 boxes with food; build calm approach + “search” release  
Homework: 2×/day 2–3 min box game

### Session 2 — Odor imprint (paired with reinforcement)
Targets: NW_ODOR_IMPRINT  
Drills: odor + food paired, 1–2 posts; fast reinforcement at source  
Homework: 3–5 imprint reps/day (short)

### Session 3 — Nose-hold indication shaping (separate from searching)
Targets: NW_IND_NOSEHOLD  
Drills: shape nose contact to a target plate → duration → calm stillness  
Homework: 1–2 min/day nose-hold shaping

### Session 4 — Combine: short search → nose-hold → reward
Targets: NW_SOURCE_COMMIT, NW_IND_NOSEHOLD  
Drills: 2–3 posts; reward only at source after nose-hold  
Homework: 3 short searches/day (very easy)

### Session 5 — Add blanks (anti-guessing)
Targets: NW_BLANK_OK, NW_RESET_PROTOCOL  
Drills: 1 hide + 1 blank; teach “no odor = return to handler”  
Homework: 4-search set 3×/week (2 hide / 2 blank)

### Session 6 — Increase posts + distance (still easy)
Targets: NW_SEARCH_PATTERN, NW_HANDLER_STILL  
Drills: 4–6 posts; handler stays neutral, let dog solve  
Homework: 2 sessions/week of 4–6 post fields

### Session 7 — Novel context (new room / new surface)
Targets: NW_MULTIPLE_AREAS (intro), NW_DISTRACTION_RESILIENCE (mild)  
Drills: same difficulty, new place; keep success high  
Homework: 1 novel-context search/week + easy reps

### Session 8 — Height change (optional) + corners
Targets: NW_HEIGHT (intro), NW_AIRFLOW (intro)  
Drills: slightly elevated post; corner hides in easy form  
Homework: 1–2 height reps/session, keep it fun

### Session 9 — Field proofing (D2)
Targets: field-level reliability + blanks  
Drills: 6–10 posts; mix 1–2 hides + blanks; log times  
Homework: 2 proofing sessions/week, low rep count

### Session 10 — Graduation battery + maintenance plan
Run standardized battery (Section 8) + define monthly audits.

---

## 8) Graduation battery (10–12 min)
- Start line 5s (D2)
- 4-search set:
  - 2 hides + 2 blanks, 3–6 posts each
  - log search_time_s, false_alert_bool
- Indication: nose-hold ≥ 2s at source on both hides
- Reset protocol: after a blank, returns to handler within ≤ 10s

**Pass:** meets the pass criteria in Section 5 at D2 in controlled environments.

---

## 9) Error taxonomy (for logs)
- `frantic_search`
- `false_alert`
- `handler_helping`
- `no_commit`
- `break_start_line`
- `weak_indication`
- `stress_withdrawal`
- `over_arousal`

---

## 10) Station mapping (campus/hardware)
### Recommended modules
- **Start line tile** (mat/plate) + optional “ready” light
- **Sealed scent posts** (swappable scent pods)
- **Indication zone** (nose-hold plate or proximity sensor area)
- **Reward bank** (human-delivered or controlled dispenser; avoid compulsion)
- **Blank posts** (identical hardware, no odor)

### Automation-friendly events
- `NW_START` (RFID present + start-line held)
- `NW_INDICATE` (nose-hold duration threshold met)
- `NW_FALSE_ALERT` (indication without odor; mark in logs)
- `NW_END` (return to handler / station)

---

## 11) Maintenance plan
- 2–3×/week: 2–4 searches (low reps)
- Monthly: run graduation battery as an audit
- If false alerts rise: increase blanks, reduce difficulty, reinforce calm

---
End of nosework class guide.
