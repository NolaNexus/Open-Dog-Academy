# Open Dog Academy — Class Guide: Leash Skills (Loose Leash → Heel → Public Etiquette)
Filename: `class-guide-leash-skills.md`
Version: 1.0
Date: 2026-01-10

This is a **course-syllabus + instructor guide** hybrid designed to be:
- **Repeatable**
- **Measurable**
- **Modular**

---

## 0) How to use this document
- 1 session/week (45–60 min) + daily 5–10 minute micro-practice.
- Select 1–3 skills per session.
- Progress is criteria-based (not time-based).
- For group teaching, pair with `instructor-guides/` scripts.

---

## 1) Course overview

**Purpose:** Build safe, low-conflict leash walking that scales from neighborhood walks to public places.

**Outcomes:**
- 10-minute LLW walk with ≥80% slack leash (tier 1–2)
- Clean U-turn escape hatch
- Pass-bys at planned distances with no lunging
- Optional short heel and public etiquette sequences

---

## 2) Prerequisites + materials
Prereqs: marker understanding; comfort wearing harness/collar  
Materials: 6–10 ft leash, optional long line, treats, optional mat

---

## 3) Measurement standard (shared)
See: `../standards/academy-standards.md`.

---

## 4) Skill inventory (ID-based)
- [LS_ENGAGE](../skills/ls/LS_ENGAGE.md)
- [LS_ZONE](../skills/ls/LS_ZONE.md)
- [LS_LL_WALK](../skills/ls/LS_LL_WALK.md)
- [LS_AUTO_SIT_STOP](../skills/ls/LS_AUTO_SIT_STOP.md)
- [LS_TURNS](../skills/ls/LS_TURNS.md)
- [LS_PASSBY](../skills/ls/LS_PASSBY.md)
- [LS_HEEL](../skills/ls/LS_HEEL.md) (optional)
- [LS_PUBLIC_ETIQUETTE](../skills/ls/LS_PUBLIC_ETIQUETTE.md)

---

## 5) Progression levels

**Level 0:** Engage + zone  
**Level 1:** LLW + stops + turns  
**Level 2:** Pass-bys  
**Level 3:** Public etiquette + optional heel

Unlock criteria: complete pass criteria in each skill file at current distraction tier.

---

## 6) Session template
Warmup → LLW block → Turns/Pass-by block → Etiquette/Heel block → Cooldown

---

## 7) Graduation battery (10–15 min)
- 5-minute LLW segment (tier 2)
- 5 U-turns + 5 stops
- 3 planned pass-bys
- 1 settle 60–120 sec

---

## 8) Maintenance
3x/week short refresh, 1x/week pass-by practice, monthly public outing

---

## 9) Group teaching notes
Use:
- `../standards/group-class-safety.md`
- `../ops/group-meetup-playbook.md`
- `../instructor-guides/level-1-basic.md` and `level-2-intermediate.md`
