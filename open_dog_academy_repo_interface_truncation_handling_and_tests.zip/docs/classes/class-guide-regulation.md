# Open Dog Academy — Class Guide: Regulation (Arousal → Recovery → Start Lines)
Filename: `class-guide-regulation.md`
Version: 1.0
Date: 2026-01-10

This is a **course-syllabus + instructor guide** hybrid designed to be:
- **Repeatable**
- **Measurable**
- **Modular**

---

## 0) How to use this document
- 1 session/week (45–60 min) + daily 5–10 minute micro-practice.
- Select 1–3 skills per session.
- Progress is criteria-based (not time-based).
- For group teaching, pair with `instructor-guides/` scripts.

---

## 1) Course overview

**Purpose:** Build regulation skills that stabilize obedience, off-leash, sports, and public life.

---

## 2) Materials
Mat/bed, treats, optional lick mat/scatter feed.

---

## 3) Measurement standard (shared)
See: `../standards/academy-standards.md`.

---

## 4) Skill inventory
- [REG_RELAX](../skills/reg/REG_RELAX.md)
- [REG_STARTLINE](../skills/reg/REG_STARTLINE.md)
- [REG_RECOVER](../skills/reg/REG_RECOVER.md)
- [REG_AROUSAL_DOWN](../skills/reg/REG_AROUSAL_DOWN.md)
- [REG_FRUSTRATION](../skills/reg/REG_FRUSTRATION.md)
- [REG_BOUNDARIES](../skills/reg/REG_BOUNDARIES.md)

---

## 5) Progression levels
L0 relax → L1 start lines → L2 recovery/downshift → L3 frustration/boundaries

---

## 6) Graduation battery
3-min settle tier 2; start line 10 sec (5 reps); recovery 5 trials; 10 training reps with low frustration.

---

## 7) Group teaching notes
Regulation is meetup gold: stationing, short rounds, lots of breaks.
Use Level 0–2 instructor guides.
