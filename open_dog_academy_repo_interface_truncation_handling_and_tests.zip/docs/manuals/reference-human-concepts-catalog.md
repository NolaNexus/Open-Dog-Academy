# Open Dog Academy — Human-Side Concepts Catalog (High-Level → Niche)
Path: `docs/manuals/reference-human-concepts-catalog.md`  
Version: 1.1  
Date: 2026-01-09

A **waterfall taxonomy** of what the humans need to know and do to run Open Dog Academy safely and sustainably: training craft, safety, ops, engineering, governance, and continuous improvement.

Design goals
- **Over-complete:** cover real-world household + facility + training operations.
- **Low redundancy:** one concept lives in one main place; cross-links used instead of repeats.
- **Actionable:** every concept should be convertible into SOPs, checklists, or design constraints.

---

## 0) Constitution: Ethics, Welfare, and Decision Rules
### 0.1 Core training values
- Force-free, reward-based defaults
- Management first; training second; “set up to win”
- Prevent rehearsal of unwanted reps
- Build confidence, not compliance-by-stress

### 0.2 Welfare guardrails (daily operational)
- Sleep, rest, decompression are “requirements,” not luxuries
- Temperature safety (heat/cold risk planning)
- Enrichment balance (calm + active + social + rest)
- Avoid obsession loops (fetch/tug/button spam)

### 0.3 Risk posture
- Autonomy without unsafe autonomy (Dog Ask → supervised approvals)
- Fail-safe design mindset (water off on fault; actuators stop)
- Redundancy in high-cost failures (leaks, gates, treadmill)
- “Stop rules” for stress, injury risk, or equipment anomalies

### 0.4 Scope boundaries and escalation
- When to call vet (medical red flags)
- When to call certified behavior pro (aggression, severe anxiety)
- What not to DIY (high-risk bite sports, severe bite history without pro)

---

## 1) Training Craft (human skill: teaching cleanly)
### 1.1 Observation literacy (read the dog)
- Stress signals (avoidance, lip licks, freezing)
- Arousal signals (frantic scanning, vocalization, pacing)
- Fatigue signals (sloppy reps, slow response)
- Preference signals (what reinforcers really matter today)

### 1.2 Timing and mechanics
- Marker timing (precision)
- Reinforcer delivery placement (where it lands matters)
- Rate of reinforcement (dense vs thin)
- Micro-session rhythm (short wins; avoid drilling)

### 1.3 Criteria design (splitting, shaping, proofing)
- Splitting vs lumping decisions
- Shaping plans (approximation ladder)
- Proofing plan (duration/distance/distraction)
- Generalization plan (new rooms/outdoors/guests/weather)
- Prompt plans + fade strategy

### 1.4 Reinforcer strategy (economy management)
- Reinforcer menu and value scaling (low/medium/high)
- Premack principle (access rewards)
- Reward budgets (meal/play/prize banks)
- Variable reinforcement: bounded randomness + pity cap
- Jackpot governance (when, why, and how much)

### 1.5 Error handling (humans prevent spirals)
- Arrange environment to prevent errors
- Neutral reset cues; calm breaks
- Avoid accidental reinforcement of mistakes
- Switch to easy reps to preserve confidence

### 1.6 Behavior change strategy (planner role)
- Antecedent management (setup)
- Reinforce alternatives (DRI/DRA)
- Desensitization + counterconditioning
- Maintenance plan (keep skills alive)

---

## 2) Human Safety & Handling (physical + procedural)
### 2.1 Handling mechanics
- Leash safety (no wraps, no burns)
- Body positioning during excitement
- Safe tug mechanics (start/stop/out rules)
- Bite prevention practices (respect thresholds)

### 2.2 Kid safety protocols
- Supervision rules (who, when, where)
- “No-interrupt zones” (dog on station = do not disturb)
- Safe petting scripts for kids
- Food/toy boundary rules

### 2.3 Multi-animal safety (dog/cat/chickens/guest dogs)
- Separation protocols during feeding
- Controlled intros and parallel routines
- Fence-line training lanes (separate from play loop)
- Guest dog mode SOPs

### 2.4 Facility safety
- Slip/trip hazards and housekeeping
- Chemical/tool storage rules
- Electrical safety around wet zones
- Everyone knows E-stop locations and meaning

---

## 3) Campus Operations (SOPs that keep it usable)
### 3.1 Daily routines
- Morning check-in (weight/photos)
- Meals (dispense + slow feed + water check)
- Structured play loop session (quest vs free)
- End-of-day shutdown (clean mode, refill checks)

### 3.2 Cleaning operations
- Cleaning mode: disable actuators; close water solenoid
- Wet zone rinse + squeegee + drain clearing
- Hair trap maintenance
- Ball/toy sanitation routine
- Camera lens wipe routine
- Mold/mildew prevention in spa shack

### 3.3 Refills and consumables
- Kibble hopper refill standards
- Prize/topper refill standards (portion control)
- Filter schedule (water/air)
- Consumables inventory (towels, wipes, inserts, gaskets)

### 3.4 Fault response playbooks
- Leak detected → shutoff + isolate + inspect
- Jam detected → safe stop + cleanout + test cycle
- Dog stress incident → abort + decompression protocol
- Injury suspicion → stop + assess + vet threshold decision
- Post-incident review (root cause + prevention)

---

## 4) Engineering & Build Literacy (human-side hardware competence)
### 4.1 Layout and flow planning
- Indoor core vs play loop vs spa shack zoning
- One-way corridors and airlocks (double gates)
- Line-of-sight management (avoid chicken triggers)
- Human ergonomics (grooming height, tool access)
- ADA-style accessibility thinking (for human mobility needs)

### 4.2 Materials and construction principles
- Stainless where possible; HDPE/UHMW for wear liners
- Radiused edges; no snag points; toe-trap avoidance
- Washable surfaces and drainage planning
- Noise damping/isolation mounts (prevent resonance)
- UV and freeze durability planning outdoors

### 4.3 Water systems literacy
- Normally-closed solenoid (fail OFF)
- Leak detection containment (catch pans, drains)
- Backflow considerations (where relevant)
- Winterization (freeze protection, drain-down)

### 4.4 Electrical and controls basics
- Power distribution and fusing
- Low-voltage separation from mains
- Weatherproofing, strain relief, drip loops
- Cable management and labeling
- EMI/noise considerations for sensors

### 4.5 Modularity and serviceability
- Cartridge bay standards
- Tool-less cleanouts for jam zones
- Field-replaceable sensors philosophy
- Spare parts inventory strategy

---

## 5) Automation & Software Systems Thinking
### 5.1 State machines and interlocks
- Global state model enforcement
- Priority rules (FAULT > override > RFID)
- Cooldowns and caps to prevent compulsion loops
- Supervised-only enforcement for risky modules

### 5.2 Event-driven architecture
- Events: press, RFID present, weigh stable, request made, fault
- Actions: dispense, unlock, notify, log, snapshot
- Idempotency (no duplicate request spam)
- Watchdogs (auto-fail to safe state)

### 5.3 Permissions and governance
- Human override: definition + physical indicator
- Guest profiles and restrictions
- Admin-only operations (calibration, config changes)

### 5.4 Data pipeline literacy
- What to log vs what not to log
- Session IDs + module IDs + timestamps
- Data quality checks (bad sensors, drift)
- Privacy thinking (camera zones, retention)

### 5.5 Alerts and notifications
- What deserves SMS (safety/fault/requests)
- What stays dashboard-only
- Rate limits to avoid alert fatigue
- Escalation logic for repeating faults

---

## 6) Measurement, Evaluation, and Curriculum Management
### 6.1 Metrics humans should care about
- Skill: success rate, latency, duration, error types
- Regulation: recovery time, spam presses, cooldown triggers
- Health: weight trend, water intake trend, food consumption
- Utilization: station usage patterns (what he actually uses)

### 6.2 Benchmarking and audits
- Baseline week (before changing systems)
- Monthly mini-audit (5-minute test battery)
- Equipment audit (bolts, seals, hoses, sensors)
- Safety audit (gates, surfaces, E-stops, snags)

### 6.3 Curriculum planning (tracks and levels)
- Track selection and prioritization
- Unlock criteria (quantitative thresholds)
- Deload weeks (reduce intensity, increase calm enrichment)
- Seasonal scheduling (heat/cold adaptations)

### 6.4 Experiment design (you’re building a lab)
- One change at a time
- Define success metric before change
- A/B testing (e.g., calm gate duration)
- Confound control (sleep, weather, visitors)

---

## 7) Human UX: Documentation, Signage, and Consistency
### 7.1 Documentation discipline
- SOP per station
- Cue dictionary (voice + hand + station prompt)
- Wiring diagrams and parts list
- Versioned configuration (caps/cooldowns/mappings)
- Change log + rollback plan

### 7.2 Signage and household rules
- Kid-friendly signage (“Don’t touch when RED”)
- Guest instructions (“Use this gate”)
- Station etiquette (“Don’t lure dog off mat mid-rep”)

### 7.3 Consistency across people
- Standard reward placement rules
- Standard tug rules and stop rules
- “No freelancing” policy for guests/helpers

---

## 8) Maintenance Literacy (keep the campus alive)
### 8.1 Wear parts, spares, and consumables
- UHMW/HDPE liners, silicone bumpers, gaskets
- Spare sensors (RFID, load cell amp, beams)
- Fasteners, T-nuts, cable glands
- Cleaning agents compatible with surfaces

### 8.2 Calibration and verification schedules
- Load cell calibration (food/prize)
- Flow sensor verification (water)
- Camera framing checks (consistent body photos)
- Button sensitivity checks (piezo thresholds)

### 8.3 Environmental durability management
- UV exposure plans (covers, materials)
- Freeze protection plans (drain-down, heat trace if used)
- Dust/hair filtration and enclosure sealing
- Corrosion prevention (galvanic isolation planning)

---

## 9) Human Roles, Permissions, and Social System
### 9.1 Roles
- Admin/owner (config, calibration, safety policies)
- Helper (SOP-only operations)
- Guest (no override; supervised access only)

### 9.2 Access control concepts
- Keyed switches for supervised zones
- Admin RFID/PIN for override (optional)
- Physical locks for tool cabinets and chemicals

### 9.3 Training consistency governance
- Standard cue dictionary enforcement
- Standard reinforcement budgets
- Regular alignment check-ins (“are we training the same rules?”)

---

## 10) Emergency Preparedness (boring, essential)
### 10.1 Facility failures
- Power outage plan (safe shutdown behavior)
- Flood/leak plan (water off; isolate)
- Heat plan (disable high-arousal modules)
- Fire/smoke plan (evac routes; leashes ready)

### 10.2 Dog health flags (triage literacy)
- Heat stress recognition and stop rules
- Limping/pain stop rules
- GI monitoring thresholds (vomit/diarrhea)
- “Call vet now” vs “watch” thresholds (written)

### 10.3 Incident documentation
- What happened, trigger, mitigation
- Hardware involvement (fault logs)
- Behavior antecedents (sleep, novelty, guests)

---

## 11) Expansion Planning (scaling without chaos)
### 11.1 Scaling principles
- Add one new station at a time
- Validate cleaning burden before expanding
- Keep calm stations proportion high
- Maintenance time budget and spare parts budget

### 11.2 Anti-gimmick selection rubric
A new module must satisfy at least one:
- reduces risk
- reduces workload
- improves health monitoring
- teaches transferable skill
- provides calm enrichment with low injury risk

### 11.3 Interoperability discipline
- New modules must use the same state model and cue language
- New rewards must obey budget banks
- New risks must be classified SUPERVISED unless proven safe

---

## 12) “One concept, one home” index (anti-redundancy)
- **Dog body language / observation:** 1.1  
- **Reinforcer economy/banks:** 1.4  
- **Stop rules / stress aborts:** 0.3, 3.4, 10.2  
- **Cleaning/refill operations:** 3.2, 3.3  
- **Interlocks/state machine:** 5.1  
- **Calibration:** 8.2  
- **Scaling rubric:** 11.2  

---
End of human-side catalog.
