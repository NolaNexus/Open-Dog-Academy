# Open Dog Academy — Socialization Manual (Index)
Path: `docs/manuals/manual-socialization.md`  
Version: 1.1  
Date: 2026-01-10  
Applies to: Puppies → Adolescents → Adults (with age-specific notes)

This manual is intentionally **modular** to prevent truncation issues and to make it easy to reuse sections in class guides, handouts, and AI handoffs.

> Key idea  
> Socialization is **not** “meet everyone.” Socialization is learning that the world is **safe, predictable, and navigable**, with strong skills for **neutrality, choice, and recovery**.

---

## How to use this manual
- Read **Parts 1–2** once (definitions + principles).
- Use **Part 3** as your exposure menu.
- Use **Part 4** to run sessions correctly.
- Use **Part 5** to log results and turn “socialization” into repeatable training stations.
- Use **Part 6** when things go sideways.

---

## Modules
1. [Part 1 — Definitions + Development](socialization/01-definitions-and-development.md)
2. [Part 2 — Principles, Goals, Body Language](socialization/02-principles-goals-bodylanguage.md)
3. [Part 3 — Categories Checklist](socialization/03-categories-checklist.md)
4. [Part 4 — Protocols, Schedules, Safety](socialization/04-protocols-schedules-safety.md)
5. [Part 5 — Data + Integration](socialization/05-data-and-campus-integration.md)
6. [Part 6 — Mistakes + Templates + Priorities](socialization/06-mistakes-templates-priorities.md)
7. [Part 7 — Sources](socialization/07-sources.md)

---

## Modularity rule (theme going forward)
When a file approaches the repo’s doc-length caps, split it into **small, reusable modules**:
- one module = one problem domain (definitions, protocol, troubleshooting, template)
- index page links modules in a teachable order
- modules should stand alone (minimal cross-dependencies)
