# Work + Sport + Task Taxonomy
Updated: 2026-01-10
Status: draft

This manual defines what ODA means by **work**, **sport**, and **tasks**, and how they map to classes, skills, and LAB experiments.

## Definitions (ODA)
### Life skills
Behaviors that make everyday life safer and easier (loose leash, recall, calm greetings, cooperative care, regulation).

### Sport
A **rule set** + environment + scoring system (nosework, rally, agility, etc.). Sport training typically emphasizes:
- repeatable criteria
- ring/arena entry routines
- handling mechanics
- proofing under predictable distractions

### Work
A **job outcome** that solves a real problem for the handler or community (service-style assistance tasks, farm chores, SAR-style games, therapy-dog style visiting skills, etc.).

### Task
A **functional behavior sequence** performed for an outcome.
- A task can be part of **work** (assist tasks) or part of **sport** (retrieve exercises, indications).
- ODA uses *task* to mean “functional sequence,” not “mystical dog superpower.”

### Game / enrichment
A reinforcement-driven activity meant to build learning capacity, confidence, and regulation. Games are welcome in ODA, but they must remain **portable** and **safe**.

## Where these live in the repo
- **Life skills:** primarily `docs/skills/` and core class guides (`docs/classes/class-guide-*.md`).
- **Sport foundations:** `docs/classes/` + sport skill folders (e.g., `docs/skills/nw/`, `docs/skills/rally/`, `docs/skills/ag/`).
- **Work tasks:** `docs/skills/task/` plus task/service-oriented class guides.
- **Games:** live in class guides when they create a transferable behavior; otherwise they stay in **LAB**.

## Skill chaining: two styles (why arcade ≠ pentesting)
Both of these can produce “real” skills, but they chain behavior differently:

### Arcade-style chaining (discrete-trial loop)
- Best for: repetition, clarity, impulse control, learning-to-learn
- Risks: compulsive grinding, frustration if payout is inconsistent
- ODA location: LAB (project) + `docs/skills/arc/` (primitives)
- Reference: [Arcade loop chaining](../lab/skill-chaining/arcade-loop.md)

### Pentesting-style chaining (exploration chain)
- Best for: problem solving, handler management literacy, strategy switching
- Risks: reinforcing “loophole hunting” in real life if boundaries are fuzzy
- ODA location: LAB (concept) anchored to regulation + indication skills
- Reference: [Pentesting exploration chaining](../lab/skill-chaining/pentesting-exploration.md)

## Promotion rules (LAB → Curriculum)
A LAB project can graduate into main curriculum when:
- safety checklist exists and is tested
- rules are stable enough that a novice handler can run it
- failure modes are documented (how it goes wrong and how to prevent it)
- the project yields at least one transferable behavior that can be written as a `SKILL_ID`

When promoting:
1) extract non-negotiables into **Standards**
2) extract teachable how-to into a **Manual** or **Class Guide**
3) extract measurable behavior(s) into **Skills**
