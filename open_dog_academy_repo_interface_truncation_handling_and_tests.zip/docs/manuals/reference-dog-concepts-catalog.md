# Open Dog Academy — Dog-Side Concepts Catalog (High-Level → Niche)
Path: `docs/manuals/reference-dog-concepts-catalog.md`  
Version: 1.1  
Date: 2026-01-09

A **waterfall taxonomy** of what dogs can learn and do: skills, habits, sport foundations, working-role task families, and behavior-change targets. Designed to feed the Open Dog Academy’s **stations, quests, and data model**.

Design goals
- **Over-complete:** include most domains humans actually train.
- **Low redundancy:** when a concept belongs in multiple domains, it appears once with “See also” links.
- **Build-oriented:** items are phrased so they can map to modules, prompts, criteria, and metrics.

---

## 0) Learning & Performance Layer (meta, but dog-facing outcomes)

### 0.1 Performance dimensions (how any skill can be expanded)
- **Accuracy** (correct choice/position)
- **Latency** (response time)
- **Duration** (hold time)
- **Distance** (from handler/station)
- **Distraction** (people/animals/noise/food)
- **Context** (room/outdoor/weather/time)
- **Fluency** (fast + correct + resilient)
- **Generalization** (works in new places/setups)
- **Reliability under arousal** (works when excited or stressed)

### 0.2 Regulation & resilience (state skills)
- **Arousal control:** upshift/downshift
- **Recovery time:** settle after play/startle
- **Frustration tolerance:** keep trying without spiraling
- **Novelty tolerance:** new surfaces/objects/sounds
- **Startle recovery:** “reset and re-engage”
- **Rest skills:** relaxing on cue, sleeping in varied environments

### 0.3 Reinforcer literacy (dog’s “economy” understanding)
- Food rewards vs toy rewards vs access rewards
- Working for meals (“earn to eat”)
- Variable reinforcement tolerance (doesn’t quit when payout isn’t constant)
- “Work ends” signals (terminal marker / release)

---

## 1) Communication & Consent (dog expresses and receives information)

### 1.1 Receiving cues (input channels)
- Verbal cues
- Hand signals
- Body cues (handler posture/motion)
- Environmental cues (harness on/off, station lights, location)
- Combined cues (voice + gesture)
- Remote cues (beacon/prompt light; speaker cues if used)

### 1.2 Giving signals (output channels)
- Eye contact / check-in
- Targeting (nose/paw)
- Indication behaviors (freeze, sit, down, paw)
- Carry/bring behaviors (deliver object)
- Request buttons (Dog Ask)
- “All done” signals (break/release target)

### 1.3 Consent / cooperative “start button” behaviors
- Chin rest
- Nose-on-plate
- Paw-on-mat
- “Ready” button press
- Maintain consent during handling (hold to continue; release to stop)

See also: **4) Cooperative Care**.

---

## 2) Foundation Obedience & Manners (companion OS)

### 2.1 Engagement and orientation
- Name response
- Auto check-in (voluntary attention)
- Reorientation from distraction
- Following target/hand
- “Find it”/scatter reset (decompression tool)

### 2.2 Core positions and transitions
- Sit / down / stand
- Position changes on cue (sit↔down, stand↔down)
- Stand for exam
- Controlled movement into position (no creeping)

### 2.3 Stationing & boundaries
- Place/mat/bed
  - duration holds
  - distance sends
  - relaxation on mat
- Platform/board work
- Boundary line (stay behind tape/edge)
- “Go behind” / “go to your spot” in household routines

### 2.4 Impulse control and safety controls
- Wait at doors/gates/food bowl
- Leave it (food/objects/animals)
- Drop it / out
- Take it (controlled grab)
- Settle after excitement (post-tug/post-door)

### 2.5 Recall families (including emergency control)
- Casual recall
- Formal recall (front + finish)
- “Check-in recall” (return to zone)
- Emergency stop
  - down at distance
  - stand-stay at distance
- “Find me” (seek handler on cue)
- Automatic return on boundary (e.g., yard edge)

### 2.6 Leash and equipment manners (behavioral, not hardware)
- Loose leash walking
- Heel (formal/informal; left/right)
- Position changes while walking
- Passing distractions politely
- Long-line skills (sniff + respond)

### 2.7 Social manners (people and dogs)
- Polite greetings (no jumping)
- Neutrality around dogs
- Handling acceptance by familiar humans
- Calm in crowds / public spaces
- Default “four on the floor”
- Gentle mouth / no mouthing

See also: **3) Household Integration**, **11) Environmental Proofing**.

---

## 3) Household Integration (multi-human, multi-animal, real life)

### 3.1 Kid-heavy home skills
- Tolerance of sudden movement/noise
- “Go to station” when kids play
- Ignore toys/food mess
- Gentle interactions (approach/leave on cue)

### 3.2 Multi-dog skills
- Play start/stop cues
- Consent breaks during play
- Parallel calmness (settle near other dog)
- Turn-taking on shared resources (with management)

### 3.3 Cat cohabitation skills
- Disengage from cat on cue
- Default calm when cat moves
- “Look → back to handler” pattern

### 3.4 Poultry / livestock safety skills
- Fence-line neutrality
- Response to movement triggers (chicken flaps/runs)
- “Leave it” under prey-like motion
- Recall away from livestock areas
- Stationing during chores

### 3.5 Resource etiquette
- Sharing space around bowls/toys (when appropriate)
- Trade game (give object → get reward)
- “Wait your turn” at stations

See also: **5) Behavior Modification Domains** for guarding/reactivity categories.

---

## 4) Cooperative Care & Maintenance (Spa curriculum)

### 4.1 Handling foundations (voluntary)
- Body handling tolerance (ears, paws, tail, belly)
- Collar grabs (positive association)
- Restraint alternatives (side lean, chin rest)
- Muzzle training (comfort + duration)

### 4.2 Grooming behaviors
- Brushing acceptance
- Bath stationing
- Towel drying
- Dryer acclimation (supervised)
- “Paw wipe” stationing (mud corridor)

### 4.3 Paw/nail care behaviors
- Paw presentation
- Nail clipping tolerance
- Dremel tolerance
- Pad inspection
- Booties acceptance (optional)

### 4.4 Vet-care behaviors (non-medical dosing)
- Temperature position tolerance
- Stethoscope handling
- Eye/ear exam acceptance
- Accepting topical applications
- Bandage tolerance
- “Recovery settle” routines

---

## 5) Behavior Modification Domains (catalog of targets)
> Domain map only. Not a protocol.

### 5.1 Fear / anxiety clusters
- Novel objects
- Novel surfaces
- Novel people
- Novel places/vehicles
- Grooming tool fear
- Veterinary fear
- Noise sensitivities (thunder/fireworks)

### 5.2 Reactivity clusters
- Dog reactivity (leash/barrier)
- Human reactivity
- Vehicle/bike reactivity
- Fence-line reactivity
- Trigger stacking management (multiple triggers)

### 5.3 Separation-related behaviors
- Isolation distress
- Confinement distress
- Departure cue sensitivity
- Hyper-attachment patterns

### 5.4 Compulsion / obsession patterns
- Light/shadow chasing (avoid training these games)
- Obsessive fetch loops
- Repetitive licking/chewing
- Demand barking / button mashing

### 5.5 Destructive behaviors
- Chewing
- Digging
- Counter surfing
- Trash raiding

### 5.6 Aggression contexts (catalog)
- Fear-based
- Pain-related
- Territorial
- Resource guarding
- Predatory sequence (chase/grab) management

See also: **2) Foundation impulse control**, **3) Household management**, **11) Proofing**.

---

## 6) Enrichment (non-competitive “life enrichment” skill families)

### 6.1 Foraging and food work
- Scatter feeding
- Snuffle/forage drawers
- Slow feeder patterns
- Lick work (if used)
- Work-to-eat chains (task → food)

### 6.2 Nosework games (calm enrichment)
- Container searches
- Exterior searches
- Buried searches
- Discrimination (choose target odor among decoys)
- Indication styles
  - freeze / stillness
  - nose hold
  - sit/down at source
- Search patterns (systematic vs free)

### 6.3 Object games and problem solving
- Retrieve to hand
- Retrieve to target bin
- Hide-and-seek (find person/toy)
- Object naming (fetch “ball”, “tug”, “rope”)
- “Bring X to Y” (delivery chains)

### 6.4 Sensory enrichment (safe)
- Texture paths
- Novel stable surfaces
- Gentle sound habituation (non-startling)
- Visual novelty (non-flashing, non-laser)

### 6.5 Social enrichment
- Parallel walks
- Structured play with rules
- Cooperative games with handler

---

## 7) Fitness, Conditioning, and Body Awareness (athlete track)

### 7.1 Conditioning targets
- Aerobic endurance (sustained)
- Strength (safe resistance)
- Mobility/flexibility
- Coordination and balance
- Weight management support

### 7.2 Proprioception and body control
- Cavaletti rails (low)
- Step-over/step-up
- Pivot box (rear-end awareness)
- Backing up on cue
- Side stepping (advanced)
- “Feet on platform” precision

### 7.3 Warm-up / cool-down routines (trainable)
- Start-of-session warmup pattern
- Post-session settle routine
- Hydration routine after exercise

### 7.4 Conditioning tools (skills around equipment)
- Dog-driven treadmill walking (supervised)
- Targeting on treadmill entry/exit
- “Stop” and “step off” reliability

See also: **12) Sports** for agility/flyball foundations.

---

## 8) Field Skills & Real-World Practicalities

### 8.1 Travel and transport
- Car entry/exit calmly
- Harness/seatbelt comfort
- Waiting at open doors
- Loading with distractions

### 8.2 Public access manners (even if not service dog)
- Crowds
- Elevators/stairs
- Shopping carts/rollers
- Food distractions
- “Ignore dropped food” under pressure

### 8.3 Outdoor life skills
- Boundary habits in yard
- Recall away from wildlife
- Neutrality at fences
- Trail etiquette (passing people/dogs)

---

## 9) Cognitive Skills (dog “arcade” curriculum)

### 9.1 Discrimination and matching
- Color/brightness matching (if used)
- Shape matching
- Texture matching
- Scent matching (strongest domain)

### 9.2 Sequencing and memory
- Pattern copying (Simon)
- Multi-step chains (A → B → C)
- Checklist chains (complete any 3)
- Delayed response (wait → choose)
- “Go/No-go” inhibition games (press only when allowed)

### 9.3 Concept learning (advanced)
- Same vs different
- Categories (toy vs non-toy; soft vs hard)
- “Fetch the one that smells like X”
- Quantity concepts (very advanced; optional)

### 9.4 Communication games
- Choice making (2-option → 4-option)
- Yes/No training
- Request refinement (call me vs play)

---

## 10) Working Role Task Families (conceptual task libraries)
> These are “families” that can be trained without claiming certification.

### 10.1 Assistance task families
- Retrieve/deliver
- Carry items
- Push/pull (doors, drawers, switches) *with safety limits*
- Locate person (“find Nola”) / locate object (“find phone”)
- Interrupt routines (nudge/paw target)
- Guide-to-location (go to mat, go to door)

### 10.2 Detection/search foundations
- Odor imprinting (target odor association)
- Search patterns
- Indication reliability
- “Reward at source” stability

### 10.3 Therapy-style competencies (behavioral)
- Calm neutrality
- Gentle greeting
- Handling tolerance
- Startle recovery

---

## 11) Environmental Proofing (systematic generalization)
### 11.1 Distraction libraries
- Food on ground
- Other dogs
- Loud noises
- Fast motion (kids, bikes)
- Novel objects/surfaces
- Wind/rain/snow conditions

### 11.2 Context switches
- Indoor core vs outdoor loop vs spa shack
- Day vs night
- Guest presence
- After exercise vs before exercise

### 11.3 Reliability under emotional load
- After a startle
- When frustrated
- When overexcited
- When tired

---

## 12) Sports Foundations (skill families; optional competition)
> Listed as foundations you can build safely.

### 12.1 Obedience foundations
- Heeling precision
- Front/finish
- Directed retrieves (advanced)
- Scent articles (advanced)

### 12.2 Rally foundations
- Station sequences
- Handler/dog communication fluency
- Distraction resilience

### 12.3 Agility foundations (low-impact by default)
- Tunnel confidence
- Contact behaviors (low platform)
- Sends/handling cues
- Weaves (later; careful)
- Jumps (optional; supervised; low height)

### 12.4 Flyball/disc foundations
- Tug reward control (start/stop/out)
- Recall racing patterns
- Retrieve to hand
- Drop on cue

### 12.5 Canicross foundations
- Harness cues
- Directionals
- Passing manners

### 12.6 Herding foundations (context-dependent)
- Stop/lie down
- Directionals
- Calm exposure to livestock

### 12.7 Protection sports (catalog only)
- Control under arousal
- Out cue reliability  
*(Not recommended without skilled club/pro oversight.)*

---

## 13) “One concept, one home” index (anti-redundancy)
- **Arousal/recovery/frustration:** 0.2, 5.4, 11.3  
- **Consent/start buttons:** 1.3, 4.x  
- **Nosework:** 6.2, 10.2  
- **Impulse control (wait/leave it/out):** 2.4  
- **Livestock/chickens:** 3.4  
- **Compulsion risk (laser/light chasing):** 5.4, 6.4  
- **Tug:** 6.3 (rules), 12.4 (sport foundations)

---
End of dog-side catalog.
