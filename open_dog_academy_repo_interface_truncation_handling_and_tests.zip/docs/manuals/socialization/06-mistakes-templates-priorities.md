# Open Dog Academy — Socialization Manual — Part 6: Mistakes, Templates, Priorities
Path: `docs/manuals/socialization/06-mistakes-templates-priorities.md`  
Parent: [Socialization Manual Index](../manual-socialization.md)

---

## 12) Common mistakes (and how to avoid them)

### 12.1 Mistake: forcing interaction
Fix:
- increase distance
- reduce intensity
- reinforce calm observation
AAHA warns forced exposure can worsen fear and create a behavioral emergency.  
Source: AAHA.

### 12.2 Mistake: flooding (too much, too fast)
Fix:
- split the stimulus (distance, duration, intensity)
- do fewer reps
- do more decompression between exposures

### 12.3 Mistake: rewarding the wrong thing
Example:
- dog barks, then you shove treats into the barking  
Fix:
- reward *before* barking when calm observation occurs
- if barking happens, increase distance and wait for calm moment

### 12.4 Mistake: dog parks as primary “dog socialization”
Fix:
- prioritize neutrality and parallel exposure
- use controlled greetings with known stable dogs  
AKC Reunite advises avoiding dog parks during early social exposure for puppies; the broader lesson applies: avoid uncontrolled high-variance interactions.

Source: AKC Reunite.

### 12.5 Mistake: stacking novelty
Fix:
- one new thing per session until dog is confident

---

## 13) Example plans (drop-in templates)

### 13.1 “Dogs at a distance” plan (neutrality)
- Set distance where dog can eat.
- 10 reps: look at dog → treat.
- 5 reps: look at dog → check-in → treat.
- Leave.  
Repeat 3x/week.

### 13.2 “Chickens behind barrier” plan
- Start far enough that your dog stays soft.
- Mark calm looks and sniffing.
- Cue recall-to-mat and reward.
- End with orchard sniff session.  
Repeat 2–4x/week.

### 13.3 “Vacuum sound” plan (tool sound)
- Vacuum present but off → treats.
- Vacuum on in another room at low duration → treats.
- Increase duration slowly; never chase fear.

### 13.4 “Handling” plan (consent)
- Chin rest 1s → reward.
- Touch ear 0.5s → reward.
- Stop while dog still wants more.  
Repeat daily, 1–3 minutes.

---

## 14) How to choose what to socialize next (priority rules)
Pick exposures that:
1) occur frequently in your dog’s real life
2) have high consequence if feared (grooming, vet, car)
3) support household safety (kids, cat, chickens)
4) support academy autonomy (calm gate reliability, disengage skills)

---

