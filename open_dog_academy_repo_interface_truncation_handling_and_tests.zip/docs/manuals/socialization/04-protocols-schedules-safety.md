# Open Dog Academy — Socialization Manual — Part 4: Protocols, Schedules, Safety
Path: `docs/manuals/socialization/04-protocols-schedules-safety.md`  
Parent: [Socialization Manual Index](../manual-socialization.md)

---

## 7) Protocols (how to do it correctly)

### 7.1 The Exposure Ladder (distance + intensity ladder)
1) **Observe at distance** (dog calm)  
2) **Mark + reward** calm observation  
3) **One step closer** OR **one notch louder**  
4) **Short repeat** (3–10 reps)  
5) **Leave on a win** (avoid fatigue)

Rule: if stress rises, move back down the ladder.

### 7.2 Engage–Disengage (neutrality engine)
- Present stimulus at safe distance
- Dog looks at stimulus (engage) → mark → reward
- Dog looks away (disengage) → mark → reward
Goal: stimulus becomes a cue to reorient, not a cue to escalate.

### 7.3 “Find it” decompression breaks
- Toss a few treats in grass or on snuffle area
- Purpose: reduce arousal, encourage sniffing, reset nervous system
Use after mild stress spikes.

### 7.4 Parallel exposure (dogs and animals)
- Walk parallel to stimulus at distance
- Do not allow greeting until body language is soft and reorientation is easy
- If greeting occurs, keep it short and end before tension rises

### 7.5 Handling socialization: consent-based micro reps
- Teach a start button (chin rest or nose-on-plate)
- Handle for 1 second → reward
- Stop before dog wants to stop
This prevents grooming/vet contexts from becoming fear triggers.

AAHA: forced exposure can worsen fear; if dog withdraws or fears, do not increase exposure.  
Source: AAHA.

### 7.6 Fear period protocol (when a dog is in a fear window)
- Reduce novelty load
- Avoid “big new” experiences
- Increase predictability (routine)
- Pair unavoidable novelty with high-value reinforcement at comfortable distance
Purdue explicitly recommends keeping experiences positive and not forcing engagement during fear periods.  
Source: Purdue developmental stages.

---

## 8) Schedules, frequency, and rest (applied socialization planning)

### 8.1 Micro-session guidance
- 3–10 minutes per exposure session
- 1–3 exposures per day depending on dog state
- More frequent short sessions > rare long sessions

### 8.2 Spacing between sessions
Spacing benefits learning and prevents fatigue.
- Prefer hours between “novel exposures” when possible
- Avoid stacking multiple new exposure types back-to-back

### 8.3 Days per week and deloads
- Socialization is lifelong; rest days are not mandatory for *mental* exposures if they remain gentle and positive.
- A **deload day** (lighter novelty) is useful if:
  - food interest drops
  - avoidance increases
  - barking/over-arousal rises
  - recovery time trends worse

### 8.4 Puppy schedule (if academy supports puppies later)
Goal: frequent, brief, positive exposures across categories.
- Daily: 3–10 micro exposures (very short)
- Safety: controlled environments; hygiene; avoid unknown-dog high-traffic locations  
Sources: AVSAB + Purdue + AKC Reunite.

### 8.5 Adolescent schedule (6–18 months)
Goal: neutrality and impulse control around triggers.
- 3–6 days/week structured exposure
- 1 day/week deload if reactivity rises
- Emphasize disengage and recovery

### 8.6 Adult schedule
Goal: maintain stability and prevent regression.
- 2–4 exposures/week is often enough to maintain
- Add refreshers when routines change (new house, new baby, new equipment)

---

## 9) Safety: vaccines, disease risk, and “safe exposure”
AAHA notes there is no medical reason to delay puppy classes/social exposure until the vaccination series is completed **when exposure is managed responsibly** (avoid sick animals, practice hygiene, etc.), and that missing social exposure can be a bigger risk than disease in many cases.  
Source: AAHA.

This is not medical advice. Coordinate with your veterinarian for local disease risk and your dog’s vaccine plan.

---

