# Open Dog Academy — Socialization Manual — Part 2: Principles, Goals, Body Language
Path: `docs/manuals/socialization/02-principles-goals-bodylanguage.md`  
Parent: [Socialization Manual Index](../manual-socialization.md)

---

## 3) Core principles (academy rules that prevent “bad socialization”)

### 3.1 Consent and choice (agency)
The dog should be able to:
- approach and retreat
- opt into closer distance
- request breaks (sniff break, mat settle)  
Forced interaction is a common cause of fear sensitization.

AAHA explicitly warns that **forced exposure** can aggravate fear; if a dog withdraws or shows fear, do not increase exposure without veterinary guidance.  
Source: AAHA.

### 3.2 One variable at a time (avoid “trigger stacking”)
Keep exposures simple:
- new place + familiar people
- new person + familiar place
- new sound at low intensity + safe distance  
Stacking multiple new stressors at once can flood the dog and cause negative learning.

### 3.3 “Happy and wanting more”
Effective socialization ends:
- before the dog is tired
- before frustration rises
- while the dog is still engaged and comfortable

### 3.4 Safety and hygiene
For puppies not fully vaccinated:
- choose controlled areas
- avoid unknown-dog high-traffic places
- avoid dog parks  
AKC Reunite includes similar “common sense” caution and explicitly advises avoiding dog parks during early exposures.

Source: AKC Reunite.

### 3.5 No punishment in socialization
Punishment during exposure risks creating:
- association: “scary thing → pain/stress”
- worse reactivity and avoidance  
Use distance and reinforcement, not coercion.

---

## 4) Socialization goals (what “success” looks like)
The Open Dog Academy defines success as:

### 4.1 Emotional goals
- curiosity > caution
- calm observation
- quick recovery after surprises
- reduced startle amplitude over time

### 4.2 Behavioral goals
- can disengage on cue (“touch,” “let’s go,” “find it”)
- can settle on a mat in novel environments
- can pass people/dogs without greeting
- can accept routine handling (cooperative care)

### 4.3 Measurement goals
- improved latency to reorient to handler
- stable treat-taking and sniffing during exposures
- reduced stress-score trend over weeks
- fewer “abort” sessions needed

---

## 5) Body language: field guide for “go forward” vs “back up”
This is the human-side detection layer.

### 5.1 Green (safe to continue)
- loose body, soft face
- normal breathing
- sniffing/grounding
- taking treats gently
- able to look away from stimulus

### 5.2 Yellow (slow down / increase distance)
- closed mouth, tense posture
- ears pinned or forward-stiff
- scanning
- treat taking becomes “chompier”
- delayed responses to cues

### 5.3 Red (stop / retreat / end session)
- freezing, crouching, tucked tail
- hard stare, stalking
- refusing food
- repeated shake-offs, frantic panting
- escape attempts or explosive barking/lunging

AAHA’s guidance: if dog withdraws or shows fear, do not increase exposure; forced exposure can worsen fear.  
Source: AAHA.

---

