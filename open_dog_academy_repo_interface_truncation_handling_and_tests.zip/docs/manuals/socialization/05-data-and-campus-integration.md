# Open Dog Academy — Socialization Manual — Part 5: Data + Integration
Path: `docs/manuals/socialization/05-data-and-campus-integration.md`  
Parent: [Socialization Manual Index](../manual-socialization.md)

---

## 10) Data and measurement (Open Dog Academy logging spec)
Design socialization like a lab: measure enough to learn, not enough to drown in graphs.

### 10.1 Minimal exposure log fields (canonical atom)

--8<-- "_atoms/templates/logging-template-001.md"


### 10.2 Stress scoring (simple and usable)
- 0 = relaxed (green)
- 1 = alert but calm (green)
- 2 = mild tension (yellow)
- 3 = significant tension (yellow/red)
- 4 = over threshold (red)
- 5 = panic / cannot recover (red)

### 10.3 Automation triggers (suggested)
- If score ≥4: auto-suggest deload + increase distance next time
- If repeated score 3 sessions in a row: reduce intensity and simplify
- If treat refusal appears: end session and decompress

### 10.4 Safety gating (canonical atom)

--8<-- "_atoms/safety/safety-gating-001.md"

### 10.5 Proofing ladder (canonical atom)

--8<-- "_atoms/rubrics/proofing-ladder-001.md"

### 10.6 Generalization checklist (canonical atom)

--8<-- "_atoms/checklists/generalization-checklist-001.md"

### 10.7 Troubleshooting loop (canonical atom)

--8<-- "_atoms/troubleshooting/troubleshooting-loop-001.md"

---

## 11) Campus integration (how socialization becomes stations)

### 11.1 “Exposure Lanes” (controlled novelty corridors)
- Visual barrier options (fence cloth, hedges, panels)
- Adjustable distance markers
- One stimulus at a time
- Built-in escape route to calm zone

### 11.2 Calm Gate + Decompression Orchard
- Calm gate is the “emotion reset.”
- Orchard can serve as calm enrichment after exposure (sniffing is regulatory).

### 11.3 Observation perch (safe vantage point)
- Platform or mat where dog watches stimuli at distance
- Reward calm watching
- Leave before stress builds

### 11.4 Dog Ask integration
- Dog can request “OUTSIDE,” “PLAY,” “CALL ME”
- Socialization sessions can be initiated by humans or scheduled; dog requests should not force exposures
- Requests for high-stimulation areas can be gated by calm gate and human override

### 11.5 Cooperative care integration
Handling socialization is part of socialization.
- Start button behaviors (chin rest) are the “passport” to grooming and tools.

---

