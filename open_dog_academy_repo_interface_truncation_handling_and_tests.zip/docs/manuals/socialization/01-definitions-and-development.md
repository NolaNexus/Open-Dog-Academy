# Open Dog Academy — Socialization Manual — Part 1: Definitions + Development
Path: `docs/manuals/socialization/01-definitions-and-development.md`  
Parent: [Socialization Manual Index](../manual-socialization.md)

---

## 1) Definitions (what we mean by “socialization”)

### 1.1 Socialization (broad)
**Positive, safe exposure** to the sights, sounds, surfaces, beings, handling, and environments a dog will encounter, so the dog develops:
- **optimistic expectations** (“new things predict good outcomes”)
- **emotional stability** (low fear, low over-arousal)
- **behavioral fluency** (can choose calm behavior under novelty)

AKC Reunite emphasizes socialization is more than meeting people/dogs; it includes exposures to **sights, sounds, and textures** a dog will experience throughout life.  
Source: AKC Reunite (Socialization) — see Sources section.

### 1.2 Social exposure vs socialization
- **Social exposure:** the dog is near the thing.
- **Socialization:** the dog experiences the thing **as safe** (positive or at least comfortably neutral), and can **recover** and **repeat**.

### 1.3 Neutrality (the academy’s default target)
Neutrality means:
- dog notices stimulus
- dog stays under threshold (soft body, can eat, can disengage)
- dog can pass or coexist without needing to greet/interact

Neutrality is often the correct goal for adult dogs and for high-distraction environments.

### 1.4 “Under threshold”
A dog is under threshold when they can:
- eat treats normally
- sniff the ground
- respond to simple cues
- show soft body language  
If the dog freezes, refuses food, hard stares, panics, or tries to escape, you are **over threshold**.

---

## 2) Why it matters (and when it matters most)

### 2.1 Sensitive socialization period (puppies)
Multiple veterinary and welfare sources identify a **sensitive period** for socialization roughly **3–14 weeks**, sometimes extending to **12–16 weeks** depending on the source and individual variability. During this time, puppies learn very quickly what is safe vs unsafe, and experiences can have lasting impact.  
Sources: Purdue Canine Welfare Science; AVSAB position statement; additional welfare resources (see Sources).

### 2.2 Fear periods (puppies/adolescents)
Purdue’s canine welfare resources describe:
- first fear period: ~**8–10 weeks**
- second fear period: ~**6–14 months**
- typical duration: **~1–3 weeks**  
During fear periods, negative experiences can imprint strongly; the training strategy shifts toward **protecting confidence** and **avoiding scary exposures**.

Source: Purdue Canine Welfare Science (Puppy Developmental Stages).

### 2.3 Socialization is lifelong
AAHA warns against the belief that social exposure should only occur during certain periods, and that forced exposure can worsen fear and create a behavioral emergency. Socialization continues across life and should be adapted to the individual dog.

Source: AAHA Behavior Management Guidelines (Age and Behavior).

---

