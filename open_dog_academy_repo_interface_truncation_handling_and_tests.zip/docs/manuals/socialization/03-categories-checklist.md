# Open Dog Academy — Socialization Manual — Part 3: Categories Checklist
Path: `docs/manuals/socialization/03-categories-checklist.md`  
Parent: [Socialization Manual Index](../manual-socialization.md)

---

## 6) Socialization categories (comprehensive waterfall checklist)
Use this as a menu. You do not need to complete everything. Pick what matters for your dog’s real life.

### 6.1 Humans
**Appearance**
- hats, helmets, hoods
- beards, masks
- sunglasses
- uniforms (high-visibility vests)
- umbrellas
- big coats, dragging clothing

**Movement styles**
- running, biking, skating (AKC Reunite example)
- limping, shuffling
- carrying large objects
- people who gesture a lot

**Assistive devices**
- wheelchairs, walkers, crutches (AKC Reunite example)

**Behavior**
- loud talkers, laughing groups
- kids playing at a distance (controlled)

### 6.2 Dogs (social skills vs neutrality skills)
**Neutrality (default)**
- see dog → stay calm → disengage → reward
- parallel walking with distance
- passing behind a visual barrier

**Social interaction (optional, carefully selected)**
- greeting known calm dogs
- brief sniff greetings → “break” cue → leave
- play with consent breaks

**High-risk contexts**
- chaotic greetings
- crowded dog parks
- leash-to-leash greetings with stiff bodies  
These are usually not the best “socialization tools” for building stability.

### 6.3 Other animals (your campus advantage)
- cats (calm disengage)
- chickens (behind barrier; distance first)
- wildlife at distance (squirrels, rabbits)
- livestock sounds/smells (if relevant)

### 6.4 Places and environments
- parking lots (watching from distance)
- front yard/driveway exposures
- vet parking lot (without entering)
- grooming table presence (AKC Reunite example)
- hardware store exterior (distance)
- car ride routines
- stairs, elevators (AKC Reunite example)

### 6.5 Surfaces and textures
AKC Reunite includes examples such as shiny floors, gravel, wobbly footing.  
Add:
- metal grates (safe ones)
- ramps
- wet surfaces (controlled)
- bath mat, rubber mat, turf
- sand, snow, mud (seasonal)

### 6.6 Sounds
AKC Reunite examples: banging pots, vacuum, lawn mower.  
Add:
- doorbell
- dryer (spa shack)
- clippers/rotary tool (coop care)
- power tools at a distance (very gentle)
- vehicles passing (cars/trucks)

### 6.7 Handling and cooperative care
- collar grabs (positive)
- brushing
- paw handling
- ear handling
- nail tool exposure (off → distant on → nearer)
This overlaps with the Cooperative Care track but is also a key part of socialization.

### 6.8 Being alone (independence)
Many behavior problems stem from insufficient independence training.
- short separations with enrichment
- “I’m leaving” cues made boring
- safe confinement comfort (if used)

### 6.9 Gear
- harness
- boots (if used)
- muzzle training (optional but often valuable)
- raincoat/jacket (if used)

---

