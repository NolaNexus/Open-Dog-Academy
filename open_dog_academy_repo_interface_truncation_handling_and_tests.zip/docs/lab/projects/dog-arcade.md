# Dog Arcade — Project (Lab)
Updated: 2026-01-10
Status: draft

## What this is
A **game-based learning system** where the dog earns reinforcement by interacting with simple, consistent interfaces (buttons, targets, scent ports) under clear rules.

The goal is not “gadgets.” The goal is:
- high reps of **impulse control** and **operant clarity**
- low-friction daily enrichment
- a measurable pathway from “fun game” → “real-world skills”

## Where this connects in ODA
- Skills: the Arcade skill set lives in `docs/skills/arc/` (e.g., `ARC_READY`, `ARC_CORRECT`, `ARC_COOLDOWN`).
- Standards: must obey [Safety + Welfare](../../standards/academy-safety-and-welfare.md) and [Remote Cue Devices](../../standards/remote-cue-devices.md).

## Chaining model
This project uses **discrete-trial loop chaining**.

See: [Arcade loop chaining](../skill-chaining/arcade-loop.md)

## Design constraints (non-negotiables)
- **Correctness feedback must be independent of payout.** The dog should always know *what was correct* even when rewards are variable.
- **No startling outputs:** no harsh buzzers, no strobe.
- **Frustration management:** include cooldowns, easy wins, and a “calm reset” path.

## Minimal viable arcade loop
1. **READY** signal (module-local prompt)
2. Dog performs the offered action
3. System marks **CORRECT / INCORRECT**
4. Optional payout from a budgeted reward bank
5. **COOLDOWN** (short) → return to READY

## Example games (starter set)
- **Button discrimination:** “press lit button” vs “ignore unlit”
- **Station check-in:** dog targets a mat or station plate to start a round
- **Scent port:** nose in → hold → mark
- **Impulse control bonus:** dog looks away from bait for 1–2 seconds

## Metrics worth logging (keep it simple)
- attempts per session
- correct %
- latency to respond
- frustration indicators (rapid re-pressing, vocalization, leaving station)

## Promotion criteria (Lab → Curriculum)
Promote a game to Skills/Class Guides once:
- rules are stable and teachable
- it reliably produces a transferable behavior (not just “arcade proficiency”)
- failure modes and safety constraints are documented
