# Arcade Loop Chaining (LAB)
Updated: 2026-01-10
Status: draft

## The chain model
Arcade systems are best treated as a **discrete-trial loop**:

1) **READY / opt-in** (dog chooses to start)
2) **Offer** (prompt, light, button cue, target presented)
3) **Attempt** (dog action)
4) **Feedback** (correct/incorrect marker that is *not* identical to payout)
5) **Payout** (optional; budgeted)
6) **Cooldown** (brief lockout / settle) → back to READY

## Why this works
- Clear boundaries reduce compulsive “machine gambling” loops.
- The dog gets information (feedback) even when payout is variable.
- Cooldowns prevent arousal creep.

## Required primitives (common)
- opt-in behavior (start ritual)
- default idle (what to do when nothing is offered)
- incorrect recovery (reset to neutral)
- settle/cooldown acceptance

## Common failure modes + fixes
- **Spam pressing:** add a longer cooldown + reinforce *pause*; make READY dependent on calm.
- **Frustration on no-payout rounds:** decouple feedback from payout; use predictable payout schedules early.
- **Hard to disengage:** train “all done” to a jackpot + a transition activity (sniff walk, chew, nap).

## Data worth logging
- attempts per minute
- correct %
- aborts / disengagement latency
- cooldown triggers
