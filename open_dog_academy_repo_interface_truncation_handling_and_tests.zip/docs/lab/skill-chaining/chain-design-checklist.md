# Chain Design Checklist (LAB)
Updated: 2026-01-10
Status: draft

Use this checklist whenever you invent a new “game,” task, or sport obstacle.

## Safety gates
- No pinch points, choke points, or entrapment risks.
- Nothing splinters/shatters; nothing small enough to swallow.
- No reinforcement for destructive behavior.
- Clear human override: stop cue ends the run and the dog gets paid.

## Behavior design
- Define the **start ritual** (opt-in).
- Define the **default state** (what the dog does when waiting).
- Define the **terminal behavior** (what ends the chain successfully).
- Define the **bail-out** (how the dog earns reinforcement for quitting safely).
- Define **incorrect recovery** (what happens after a mistake).

## Reinforcement economics
- Daily budget (food, toy time, play time) is explicit.
- Rate limiting exists (cooldown, session cap, or both).
- Variable reinforcement is introduced only after the dog understands the rule.

## Transferability
- What real-world skill does this create?
- What contexts will you generalize to (rooms, surfaces, handlers, distractions)?
- What would make you promote this out of LAB?
