# Skill Chaining (LAB)
Updated: 2026-01-10
Status: draft

## What “skill chaining” means in ODA
A **chain** is a sequence of behaviors where one behavior becomes the cue for the next.

## Chain families
ODA commonly uses three chain families:
- **Discrete-trial loops (arcade-style):** repeated rounds with clear *start → attempt → feedback → cooldown*.
- **Exploration chains (pentesting-style):** the dog searches/probes for a valid solution, then indicates success.
- **Functional sequences (work-task style):** short, practical sequences (e.g., target → retrieve → deliver) where reliability matters more than novelty.

## Chain hygiene (keep chains safe and portable)
- **Start + stop are explicit:** a start ritual and an end ritual reduce obsessive looping.
- **Bail-out is trained:** the dog gets paid for disengaging on cue ("all done").
- **Error recovery exists:** what should the dog do after a mistake? (reset to station, re-orient, try again)
- **Rate limiting is real:** cooldowns, variable reinforcement, and daily budgets prevent compulsive grinding.
- **Generalization is planned:** run the chain in new rooms, new surfaces, and new handlers before claiming “reliable.”

## Docs in this folder
- [Arcade loop chaining](arcade-loop.md)
- [Pentesting exploration chaining](pentesting-exploration.md)
- [Chain design checklist](chain-design-checklist.md)
