# LAB
Updated: 2026-01-10

The LAB is where **experimental** canine projects live.

- Prototypes, novel sports, game mechanics, scoring systems, hardware interfaces
- Anything that isn’t mature enough (or general enough) to be part of the academy curriculum

## LAB rules (so experiments don’t poison the knowledge base)
- **Safety first:** if it can trap a body part, dispense food, or surprise the dog → default to **human-supervised**.
- **No standards in LAB:** if something becomes a non-negotiable, promote it to `docs/standards/`.
- **Keep experiments diffable:** Markdown first; external videos hosted elsewhere and linked.
- Every project doc should include:
  - Goal + target audience
  - Safety assumptions + failure modes
  - Success criteria + what data to log
  - What would make this graduate out of LAB

## Skill chaining frameworks
- [Skill Chaining (index)](skill-chaining/index.md)
- [Arcade loop chaining](skill-chaining/arcade-loop.md)
- [Pentesting exploration chaining](skill-chaining/pentesting-exploration.md)
- [Chain design checklist](skill-chaining/chain-design-checklist.md)

## Projects
- [Dog Arcade — Project](projects/dog-arcade.md)
- [Dog Pentesting Sport — Concept](projects/dog-pentesting-sport.md)
