# Branding (placeholder)

This site currently uses a **placeholder logo**:

- Logo: `docs/assets/branding/logo.png`
- Web-optimized version: `docs/assets/branding/logo.webp`
- Favicon: `docs/assets/branding/favicon.png`

## How to replace later
1. Export your final logo as **PNG** or **SVG**.
2. Overwrite `docs/assets/branding/logo.png` (same filename).
3. Overwrite `docs/assets/branding/favicon.png` (32×32 recommended).
4. Rebuild the site.

Keeping filenames stable prevents broken links in docs and navigation.
