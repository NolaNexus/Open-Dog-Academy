# Research Index

Research is stored as **tasks and syntheses**, not as piles of PDFs.

## Registry
- `index.yml` — machine-readable task registry (optional)
- `tasks_v3/` — research tasks (Markdown)

## Recommended workflow
- Start with a task in `tasks_v3/`
- Write a synthesis in `docs/reference/extracts/` keyed to sources
- Promote stable rules into `docs/standards/` and `docs/specs/`
- Promote teachable units into `docs/skills/` and `docs/classes/`
