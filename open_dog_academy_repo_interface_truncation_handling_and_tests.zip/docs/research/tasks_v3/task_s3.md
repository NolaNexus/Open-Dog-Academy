---
id: oda_task_s3
type: research_task
domain: program_ops
modules: []
audience: [maintainer]
risk: medium
status: draft
source_type: N/A
updated: 2026-01-10
---

# task S3

## from_master_pack
### Task S3 — Schools/college rules (ADA/Section 504/IDEA)
Queries:
- “service animals in schools ADA Section 504 guidance”
- “service animal K-12 policy guidance”
Deliverables:
- K-12 vs college differences
- parent/student checklist + boundary notes
Map: Policy_Schools, Service_PublicAccess_Advanced  
Domain: legal | Risk: high

## deep_search_queries
- (copy from above)

## required_outputs
- citation_block
- reusable_artifacts (defs/checklists/gear rules/safety triggers/module mapping)
- tags (domain/audience/use_type/risk)

## synthesis_targets
- likely standards to create:
- likely specs/protocols/lessons to update:
- assessments to add:
