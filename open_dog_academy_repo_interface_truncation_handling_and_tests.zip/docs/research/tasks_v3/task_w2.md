---
id: oda_task_w2
type: research_task
domain: program_ops
modules: []
audience: [maintainer]
risk: medium
status: draft
source_type: N/A
updated: 2026-01-10
---

# task W2

## from_master_pack
### Task W2 — Surfaces, weather, wildlife, and regional hazards (Montana-friendly)
Queries:
- “dog training cold weather safety paw protection”
- “wildlife encounters safety dogs bears coyotes”
Deliverables:
- regional hazard checklist + emergency scripts
Map: Facilities_Safety, Health_FirstAid  
Domain: facilities, health | Risk: high

---

## deep_search_queries
- (copy from above)

## required_outputs
- citation_block
- reusable_artifacts (defs/checklists/gear rules/safety triggers/module mapping)
- tags (domain/audience/use_type/risk)

## synthesis_targets
- likely standards to create:
- likely specs/protocols/lessons to update:
- assessments to add:
