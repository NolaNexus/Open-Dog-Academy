---
id: oda_task_s5
type: research_task
domain: program_ops
modules: []
audience: [maintainer]
risk: medium
status: draft
source_type: N/A
updated: 2026-01-10
---

# task S5

## from_master_pack
### Task S5 — Service dog task library taxonomy (broad + ethical limits)
Queries:
- “service dog tasks taxonomy mobility hearing psychiatric autism guide retrieval”
- “service dog mobility assistance safety concerns bracing counterbalance”
Deliverables:
- task categories + suitability matrix (dog traits × handler needs)
- explicit safety boundaries for mobility/bracing (refer-out)
Map: Service_TaskLibrary, Service_Tasks_Framework, Service_Tasks_Medical  
Domain: tasks, health | Risk: high

---

## deep_search_queries
- (copy from above)

## required_outputs
- citation_block
- reusable_artifacts (defs/checklists/gear rules/safety triggers/module mapping)
- tags (domain/audience/use_type/risk)

## synthesis_targets
- likely standards to create:
- likely specs/protocols/lessons to update:
- assessments to add:
