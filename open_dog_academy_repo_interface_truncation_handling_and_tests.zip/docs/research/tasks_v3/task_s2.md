---
id: oda_task_s2
type: research_task
domain: program_ops
modules: []
audience: [maintainer]
risk: medium
status: draft
source_type: N/A
updated: 2026-01-10
---

# task S2

## from_master_pack
### Task S2 — Employment accommodations (EEOC/ADA Title I)
Queries:
- “EEOC guidance service animal workplace accommodation ADA”
- “ADA Title I reasonable accommodation service dog documentation”
Deliverables:
- employer/employee checklist
- interactive process template language
Map: Policy_Employment, Service_PublicAccess_Advanced  
Domain: legal, housing_employment | Risk: high

## deep_search_queries
- (copy from above)

## required_outputs
- citation_block
- reusable_artifacts (defs/checklists/gear rules/safety triggers/module mapping)
- tags (domain/audience/use_type/risk)

## synthesis_targets
- likely standards to create:
- likely specs/protocols/lessons to update:
- assessments to add:
