---
id: oda_task_u4
type: research_task
domain: program_ops
modules: []
audience: [maintainer]
risk: medium
status: draft
source_type: N/A
updated: 2026-01-10
---

# task U4

## from_master_pack
### Task U4 — Herding / stock exposure ethics + rules (careful scope)
Queries:
- “AKC herding regulations instinct test safety”
- “herding stock safety guidelines dog training”
Deliverables:
- strong safety boundaries + refer-out triggers
Map: Sports_Herding, Policy_Disclaimers  
Domain: sports, ethics | Risk: high

## deep_search_queries
- (copy from above)

## required_outputs
- citation_block
- reusable_artifacts (defs/checklists/gear rules/safety triggers/module mapping)
- tags (domain/audience/use_type/risk)

## synthesis_targets
- likely standards to create:
- likely specs/protocols/lessons to update:
- assessments to add:
