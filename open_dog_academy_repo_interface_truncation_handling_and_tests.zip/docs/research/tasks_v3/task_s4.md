---
id: oda_task_s4
type: research_task
domain: program_ops
modules: []
audience: [maintainer]
risk: medium
status: draft
source_type: N/A
updated: 2026-01-10
---

# task S4

## from_master_pack
### Task S4 — Behavior problem triage + safety referral system (must-have)
Queries:
- “dog bite risk assessment ladder referral criteria veterinary behaviorist”
- “reactivity management protocols safety muzzle management”
- “resource guarding evidence-based protocol”
Deliverables:
- triage flowchart (green/yellow/red)
- “stop and refer” triggers
- management templates (muzzle, barriers, distance)
Map: Behavior_Triage, Safety_Muzzle, Policy_Disclaimers  
Domain: behavior_cases, behavior_mod | Risk: high

## deep_search_queries
- (copy from above)

## required_outputs
- citation_block
- reusable_artifacts (defs/checklists/gear rules/safety triggers/module mapping)
- tags (domain/audience/use_type/risk)

## synthesis_targets
- likely standards to create:
- likely specs/protocols/lessons to update:
- assessments to add:
