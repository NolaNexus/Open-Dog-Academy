---
id: oda_task_v2
type: research_task
domain: program_ops
modules: []
audience: [maintainer]
risk: medium
status: draft
source_type: N/A
updated: 2026-01-10
---

# task V2

## from_master_pack
### Task V2 — Position statements from professional orgs (comparative)
Queries:
- “AVSAB position statement aversive training electronic collars”
- “BSAVA BVA position statement e-collars”
Deliverables:
- stance table + rationale; quotes only where wording matters
Map: Ethics_Welfare, Policy_Disclaimers  
Domain: ethics | Risk: medium

## deep_search_queries
- (copy from above)

## required_outputs
- citation_block
- reusable_artifacts (defs/checklists/gear rules/safety triggers/module mapping)
- tags (domain/audience/use_type/risk)

## synthesis_targets
- likely standards to create:
- likely specs/protocols/lessons to update:
- assessments to add:
