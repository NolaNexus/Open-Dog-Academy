# Open Dog Academy Roadmap
Updated: **2026-01-10**

This roadmap is a **working plan** for building a modular, welfare-first training academy knowledge base.

It is designed to:
- keep goals obvious
- keep next steps unambiguous
- prevent duplication drift (single source of truth)
- prevent “turncation” (truncation) issues via enforced doc limits

---

## How to use this roadmap (best practice)
- Treat **Milestones** as outcomes with checklists + exit criteria.
- Keep “**Next**” small (the next 1–3 chunks of work).
- Move finished items into **Completed** so the plan stays readable.
- Prefer tasks that end in a **validator** (CI catches regressions automatically).

---

## Status board

### Now
- Convert core curriculum docs into **assemblies** (skills/classes that include atoms instead of copying content).
- Expand the atom library around the most reused concepts (criteria, timing, safety, proofing).

### Next
- Define and apply **Status taxonomy** (`stub` → `draft` → `stable`) across skills + atoms.
- Add an **auto-generated Skills Index / Class Index** (so indexes can’t drift).

### Later
- LAB “graduation pipeline” (rubric + versioned releases of Dog Arcade / Dog Pentesting Sport).
- Field ops + hazards taxonomy expansion.

---

## Completed (recent, keep short)
- ✅ Interface truncation runbook + chat-safe chunk exports (`chunk_for_chat.py`)
- ✅ Validator test suite (unittest) wired into CI
- ✅ Repo hygiene: `.gitignore`, `.editorconfig`, strict MkDocs build
- ✅ CI gates: file size caps, YAML parsing, skill link validation
- ✅ Anti-truncation guardrails: `doc-limits.yml` + validator + warnings
- ✅ Atom system (truth blocks): `_atoms/` + include validation + atom validation
- ✅ Demo conversions:
  - `OB_RECALL` refactored into an atom-powered assembly
  - Work + Sport Foundations split into modular suite docs
- ✅ “Where does private stuff go?” policy: Profiles kept out of this repo by default

(If this list grows, move older items into `docs/reference/exports_YYYY-MM-DD/` as a changelog snapshot.)

---

## Operating principles (non-negotiables)

### Modularity default
**Mantra:** *Atoms are truth. Assemblies are playlists.*

- If content repeats **2+ times**, atomize it.
- Assemblies should be mostly: ordering + examples + links + includes.

### Truncation response loop (when a doc gets big)
1) **Warning (~85%)**: treat as “refactor now.”
2) Run a split plan:
   - `python3 scripts/suggest_doc_split.py <doc.md>`
3) Split at `##` boundaries into modules + an index page.
4) Extract reusable blocks into `_atoms/` and include them.

---

## Repo zones (what lives where)
| Zone | Purpose |
|---|---|
| `docs/standards/` | Academy policies + safety/welfare rules |
| `docs/_atoms/` | Reusable truth blocks (protocols, rubrics, templates, checklists) |
| `docs/skills/` | Skill pages keyed by `SKILL_ID` (assemblies) |
| `docs/classes/` | Class guides (assemblies) |
| `docs/instructor-guides/` | Teaching scripts (assemblies) |
| `docs/manuals/` | Deep dives that stitch skills together (assemblies) |
| `docs/lab/` | Experiments + prototypes with graduation criteria |
| `docs/reference/` | Sources, extracts, exports |
| `docs/ops/` | Operating playbooks + contributor guidance |

---

## Milestones (ordered, with exit criteria)

### M1 — Platform MVP (publishable + guarded)
**Goal:** the website builds, deploys, and stays clean.

**Deliverables**
- [ ] Replace `repo_url` placeholder in `mkdocs.yml`.
- [x] Add “Contributing + Editing” doc: `docs/contributing.md`.
- [x] CI quality gates (sizes, YAML parse, strict MkDocs build).
- [x] Anti-truncation gates (doc limits + warnings).
- [x] Atoms system gates (atoms validator + include validator).
- [ ] Confirm GitHub Pages settings match the deploy workflow.

**Exit criteria**
- Green CI on `main`.
- Site deploys consistently.
- New contributors can place content correctly on the first try.

---

### M2 — Curriculum MVP (teach a complete path)
**Goal:** someone can follow a clean path from Level 0 → Level 2 without missing pieces.

**Deliverables**
- [ ] Define **status taxonomy** (`stub` → `draft` → `stable`) and apply it:
  - atoms, skills, class guides, instructor guides
- [x] Convert at least **one** core skill into an atom-powered assembly (`OB_RECALL`).
- [x] Convert at least **one** class suite into modular assemblies (Work + Sport Foundations).
- [ ] Convert the “core 10” skills into assemblies (atom-powered, minimal duplication).
- [ ] Create a “Level 0 → Level 2 learning path” page that links the core sequence.

**Exit criteria**
- No missing prerequisites in the recommended path.
- Each skill has pass criteria and a repeatable training plan.
- Content stays under caps and is atomized where reused.

---

### M3 — Advanced reliability (off-leash + public etiquette)
**Goal:** reliability under distance, duration, distraction with humane proofing.

**Deliverables**
- [ ] Upgrade the Off-Leash class guide into modular assemblies (split + includes).
- [ ] Standardize proofing across skills using shared rubrics (latency/distance/duration/distraction).
- [ ] Add “failure mode” troubleshooting atoms where needed (over-arousal, sniff-lock, avoidance).

**Exit criteria**
- A trainer can run the program without inventing missing steps.
- Success criteria are measurable and consistent across docs.

---

### M4 — Field ops + hazards (usable in real life)
**Goal:** practical, phone-friendly field checklists and risk management.

**Deliverables**
- [ ] Hazards taxonomy expansion (by category, not location folders).
- [ ] Travel + transport protocols (vehicle, boarding, hotels, public transit).
- [ ] Emergency planning (contacts, grab-and-go kit, evacuation behavior plan).
- [ ] Household safety playbook (kids/cats/chickens/other dog).

**Exit criteria**
- These docs can be used in the moment without feeling like homework.

---

### M5 — LAB program (design experiments that can graduate)
**Goal:** build weird things safely, then harvest the good parts.

**Deliverables**
- [ ] LAB graduation rubric: safety, repeatability, scoring, failure modes.
- [ ] Dog Arcade v0: a small set of games with clear rules and data logging.
- [ ] Dog Pentesting Sport v0: event types + scoring + safety/ethics boundaries.
- [ ] Extraction process: “LAB → atoms → assemblies” checklist.

**Exit criteria**
- LAB outputs produce reusable atoms and/or teachable curricula, not sprawling one-offs.

---

## Backlog (parking lot)
- Index generation: auto-build skills/classes/instructor indexes from filesystem + metadata.
- Metadata enforcement: validate `ID/Type/Status/Path` headers for more doc types.
- Export tooling: “compile assemblies into one PDF/longform” (optional, external).
