# Instructor Guide: Level 1 — Basic Skills (Group Meetup Script)
Version: 1.0  
Updated: 2026-01-10  
Status: draft  
Class length: **60 minutes**  
Target group size: **4–6 dogs**  
Prereqs:
- Dog can eat in the environment
- Dog can orient to handler
- Handler can follow spacing rules

---

## 1) Purpose + success criteria

### Purpose
Install the “home base” skills that make dogs easy in public:
- sit/down as defaults
- loose leash basics
- leave-it intro
- settle on a mat

### Success criteria (end of class)
- Dog can:
  - perform sit/down with 80% success in this environment (with help)
  - take 3–5 steps on a loose leash with reinforcement
  - disengage from a low-value distraction on “leave it” (easy version)
  - settle on mat for 10–20 seconds with reinforcement

---

## 2) Setup

- Standard station line + red zone barrier.
- Add a “walking lane” behind stations for 1–2 teams at a time.

---

## 3) Minute-by-minute script (60 min)

### 0:00–0:10 Arrival + decompression + review rules
- 60 seconds “find it”
- quick check-ins: who is green/yellow/red today?

---

### 0:10–0:20 Block 1 — Sit/Down (lure → cue)
**Teach**
- Lure sit, mark, treat
- Add cue once dog is predicting the lure
- Repeat for down (from sit or standing)

**Pass criteria**
- 8/10 reps: dog completes with minimal lure help.

**Pitfalls**
- repeating cues
- luring too fast
**Fix**
- slow hands, one cue, reset calmly

---

### 0:20–0:32 Block 2 — Loose leash basics (reinforce position)
**Goal**: dog learns “near you is profitable.”

**Teach**
- Start standing still: dog steps into leash slack → mark → treat at your seam
- Add 1 step: step forward → if slack → mark → treat
- If leash tightens: stop, wait for slack, reward slack

**Pass criteria**
- Dog achieves slack within 3 seconds after a stop 8/10 times.

**Coach notes**
- This is not “heel.” This is “don’t tow your human.”

---

### 0:32–0:37 Reset
- Decompress, water, sniff.
- Rotate who uses the walking lane next.

---

### 0:37–0:49 Block 3 — Leave it (intro) + Mat settle
**Leave it (easy)**
- Present low-value item in closed fist
- Dog sniffs/licks → wait
- When dog backs off → mark → reward from other hand
- Add verbal “leave it” once the pattern is predictable

**Mat settle**
- Toss treat to mat → down/sit → mark calm → treat
- Build to 10–20 seconds

**Pass criteria**
- 5 reps: dog disengages from fist item within 2 seconds
- Dog remains on mat 10 seconds with 2–3 treats

---

### 0:49–0:54 Reset
- Calm pattern game: 1–2–3 treat or “find it” scatters

---

### 0:54–1:00 Homework + criteria for Level 2
**Homework**
- Sit/down: 10 reps each per day
- Loose leash: 3 mini-walks/day of 1 minute
- Leave it: 5 reps/day
- Mat settle: 1 minute total/day in tiny chunks

**Ready for Level 2 when**
- dog stays under threshold with closer dogs
- dog offers sit/down reliably
- leash slack improves with stops
- can settle briefly on mat

