# Instructor Guide — Off-Leash Club — Reliability lab (strict prerequisites)
Filename: `off-leash-club.md`
Level: Club
Updated: 2026-01-10

---

## Objective
- Structured practice for off-leash reliability skills with staged access and conservative safety gates.

## Prerequisites (eligibility gate)
- Graduation from off-leash track prerequisites.
- Must demonstrate: recall on long line ≥9/10; stop cue ≥9/10 in low distraction.
- No bite history or serious aggression in group club.
- Follow: `../standards/group-class-safety.md` + `../standards/academy-safety-and-welfare.md`.

## Setup (layout + gear)
- Secure fenced area preferred.
- Zones: A leash-only, B long-line, C off-leash trial.
- Emergency leashes staged.
- Remote cue devices allowed only if conditioned: `../standards/remote-cue-devices.md`.

---

## 60-minute agenda (minute-by-minute)
**0–10:** Arrival + equipment checks + decompression.

**10–20:** Warmup: long-line recalls + check-ins.

**20–35:** Block A: recall games (one dog at a time).

**35–50:** Block B: stop/down + boundary rules.

**50–60:** Off-leash trial (only if criteria met) then leashed cooldown.

---

## Station / rotation details
- Recall lane: one team at a time; others station.
- Stop lane: controlled movement, no running dogs.
- Off-leash trial: 2-minute test; downgrade immediately on failures.

---

## Reset protocol (when a dog goes over threshold)
- Any failed recall/stop: downgrade to long line.
- Any fixation: increase distance; return to stationing.
- No free-for-all play; this is a skills lab.

---

## Homework (send-home)
- 3x/week: long-line recall games.
- 2x/week: stop cue practice.
- Weekly: off-leash trial only if criteria holds.
