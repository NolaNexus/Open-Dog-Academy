# Instructor Guide — Level 2 — Intermediate (duration + distance + distractions)
Filename: `level-2-intermediate.md`
Level: 2
Updated: 2026-01-10

---

## Objective
- Improve fluency under mild–moderate distractions.
- Build duration/distance and safer pass-bys.
- Reinforce stationing and start lines.

## Prerequisites (eligibility gate)
- Dog can work on leash without repeated lunging.
- Handler follows spacing rules.
- Reactive dogs must be stable at distance or run private sessions.
- Follow: `../standards/group-class-safety.md`.

## Setup (layout + gear)
- Cones/markers for 10–15 ft spacing.
- Visual barriers if available.
- Each team: leash, treats, optional mat.
- Roles: Greeter, Safety Lead, Coach.

---

## 60-minute agenda (minute-by-minute)
**0–5:** Arrival: spacing, decompression loop, no greetings.

**5–10:** Warmup: check-ins + zone.

**10–25:** Block A (Duration): start lines + mat settle.

**25–40:** Block B (Movement): LLW + turns/U-turns.

**40–55:** Block C (Pass-bys): parallel walking then planned pass-bys.

**55–60:** Cooldown + homework.

---

## Station / rotation details
- Station 1: start line waits (REG_STARTLINE).
- Station 2: mat settle (REG_RELAX).
- Movement lane: cone slalom; reward slack.
- Pass-by lane: two lanes with buffer; Safety Lead controls spacing.

---

## Reset protocol (when a dog goes over threshold)
- Increase distance immediately on stiffness, vocalizing, leash loading.
- Use U-turn escape hatch and move behind barrier.
- If repeated threshold events: decompression corner only (settle + engage).

---

## Homework (send-home)
- 3x/week: 5 min LLW + 5 U-turns.
- 3x/week: 2 min mat settle.
- 1x/week: 5 planned pass-bys at safe distance.
- Track: leash slack %, threshold incidents.
