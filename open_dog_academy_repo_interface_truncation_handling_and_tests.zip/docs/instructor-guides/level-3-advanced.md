# Instructor Guide — Level 3 — Advanced (real-world sequences + emergency foundations)
Filename: `level-3-advanced.md`
Level: 3
Updated: 2026-01-10

---

## Objective
- Combine skills into functional sequences.
- Add emergency foundations (recall games on long line, stop cues).
- Prepare for public etiquette and sport foundations.

## Prerequisites (eligibility gate)
- Pass Level 2 reliably.
- Handler can advocate for space.
- Off-leash is not practiced unless criteria + secure environment.
- Follow: `../standards/group-class-safety.md`.

## Setup (layout + gear)
- Larger space preferred.
- Long lines in designated lane.
- Decompression corner + visual barriers.

---

## 60-minute agenda (minute-by-minute)
**0–5:** Arrival + decompression.

**5–10:** Warmup: start line + engage.

**10–25:** Block A: sequence walk (LLW → stop → auto-sit → release).

**25–40:** Block B: emergency foundations (long line recall games; stop games).

**40–55:** Block C: public etiquette simulation (settle + pass-bys).

**55–60:** Cooldown + checklist.

---

## Station / rotation details
- Sequence lane: LLW 20 steps → stop → auto-sit → release.
- Emergency lane: long-line recalls with jackpots; stop cue practice.
- Etiquette corner: mats; instructor walks by as distraction.

---

## Reset protocol (when a dog goes over threshold)
- If arousal rises: downgrade to settle + sniff decompression.
- If lunging rehearses: increase distance and do pattern games.
- If leash safety fails: Safety Lead steps in; team exits lane.

---

## Homework (send-home)
- 2x/week: 10-min sequence walks.
- 2x/week: 10 recall games on long line.
- 1x/week: public etiquette short outing.
- Track: recovery time, incidents.
