# Instructor Guide: Level 0 — Foundations (Group Meetup Script)
Version: 1.0  
Updated: 2026-01-10  
Status: draft  
Class length: **60 minutes**  
Target group size: **4–6 dogs**  
Prereqs: none (but see eligibility in `standards/group-class-safety.md`)

---

## 1) Purpose + success criteria

### Purpose
Teach humans how to train, and give dogs predictable structure.

### Success criteria (end of class)
- Handler can:
  - deliver reinforcers cleanly
  - use a marker (or “yes”) with decent timing
  - keep dog under threshold in a group line
- Dog can (in this environment):
  - eat treats
  - orient back to handler repeatedly
  - do 5–10 seconds of stationing (mat/spot) with help

---

## 2) Setup

### Layout
- Stations in a wide circle or two rows facing the same direction
- Barrier zone labeled “RED ZONE / DECOMPRESS”
- Cones marking 10–15 ft spacing

### Required gear (per team)
- harness or flat collar + 4–6 ft leash
- treats (high value)
- optional mat/towel

---

## 3) Minute-by-minute script (60 min)

### 0:00–0:10 Arrival + decompression + rules
- Direct each team to a station.
- Ask for 60 seconds of “find it” scatter feeding.
- Read rules:
  1) no greetings
  2) keep spacing
  3) if your dog escalates, step behind barrier

**Coach notes**
- You’re not training yet—you’re building safety.

---

### 0:10–0:20 Block 1 — Marker + delivery
**Goal**: “marker predicts treat” and handlers stop fumbling.

**Teach**
- Choose marker: clicker or “yes”
- Reps: marker → treat (10 reps)

**Pass criteria**
- Dog visibly perks up at marker 8/10 reps.

**Common pitfalls**
- Treat before marker → cue confusion
- Slow delivery → dog disengages
**Fix**
- “Marker then treat to mouth level.” Keep treats ready.

---

### 0:20–0:32 Block 2 — Name game + orienting
**Goal**: dog orients when called, without leash pressure.

**Teach**
- Say name once → when dog looks → mark → treat
- If dog doesn’t look: make a tiny sound, step away, then mark/treat the look

**Progression**
- Add 1 step of distance (handler takes a step back)

**Pass criteria**
- 8/10 reps: dog looks within 2 seconds.

---

### 0:32–0:37 Reset
- Water break.
- 1 minute sniffing or scatter feed.
- Check the line: any dogs in yellow/red? Increase spacing now.

---

### 0:37–0:49 Block 3 — Stationing (mat/spot) + calm reinforcement
**Goal**: teach dogs that “staying put” pays.

**Teach**
- Toss treat onto mat → dog steps on → mark → treat on mat
- Build to: 3 seconds on mat
- If dog leaves: reset by tossing treat back to mat

**Pass criteria**
- Dog chooses mat 5 times without needing leash guidance.

**Coach notes**
- Pay low and calm (to the floor), not hyped up.

---

### 0:49–0:54 Reset
- “find it” scatters
- one calming breath cue for humans: slow exhale, loosen shoulders

---

### 0:54–1:00 Homework + wrap
- Hand out / read the homework card:
  - 10 reps/day marker → treat
  - 10 reps/day name game
  - 5 reps/day mat game

**Graduation to Level 1 criteria**
- Dog can stay under threshold in group line
- Dog eats treats reliably
- Dog orients to handler repeatedly

---

## 4) Helper roles (if available)
- Greeter: parking/unloading flow
- Safety lead: spacing + red zone support
- Floater: resets cones, brings barriers, hands out homework cards

