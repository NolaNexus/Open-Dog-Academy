# REG_FRUSTRATION — Frustration tolerance (errors without meltdown)

**Type:** skill reference  
**Status:** draft  
**Last updated:** 2026-01-10

---

## 1) Definition
- Dog handles ‘no reward’ moments and keeps working calmly.

## 2) Goals
- **Handler:** Keep error rate low.
- **Dog:** Persists without big frustration behaviors.

## 3) Prerequisites
- Clear marker system

## 4) Equipment + setup
- Use easy tasks; short reps.

## 5) Teaching steps (progression)
1. Alternate easy wins with tiny challenges.
2. Reinforce calm resets.
3. End early on success.

## 6) Pass criteria (minimum)
- 20 reps with ≤2 frustration behaviors (vocalize, leash bite, jump).

## 7) Proofing plan
- Increase challenge slowly; add distractions later.

## 8) Common pitfalls + fixes
- Difficulty jumps → meltdown; reduce.
- Long sessions → fatigue; shorten.
