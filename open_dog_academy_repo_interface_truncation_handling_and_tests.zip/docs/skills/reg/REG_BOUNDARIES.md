# REG_BOUNDARIES — Impulse control boundaries (calm earns access)

**Type:** skill reference  
**Status:** draft  
**Last updated:** 2026-01-10

---

## 1) Definition
- Dog stays calm near exciting rewards; access is earned via calm.

## 2) Goals
- **Handler:** Stage access; reinforce offered disengagement.
- **Dog:** Calm gets access.

## 3) Prerequisites
- Start line + leave-it foundations

## 4) Equipment + setup
- Barriers and distance; staged access rewards.

## 5) Teaching steps (progression)
1. Reward at distance; calm → mark.
2. Release to reward.
3. Increase proximity.
4. Add motion gradually.

## 6) Pass criteria (minimum)
- Holds calm 5 sec near reward for 5 reps.

## 7) Proofing plan
- Generalize to greetings, toys, food bowls.

## 8) Common pitfalls + fixes
- Lunging to access reward → reset.
- Repetition without breaks → frustration; shorten.
