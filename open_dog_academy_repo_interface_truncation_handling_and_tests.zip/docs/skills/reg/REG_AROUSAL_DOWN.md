# REG_AROUSAL_DOWN — Arousal downshift routine

**Type:** skill reference  
**Status:** draft  
**Last updated:** 2026-01-10

---

## 1) Definition
- Dog reduces intensity using a trained routine (sniff → settle).

## 2) Goals
- **Handler:** Cue routine early.
- **Dog:** Transitions down.

## 3) Prerequisites
- REG_RELAX

## 4) Equipment + setup
- Sniff breaks, scatter feed, lick mat, mat.

## 5) Teaching steps (progression)
1. Cue routine after mild excitement.
2. Sniff 30–60 sec.
3. Settle; pay calm.
4. Gradually shorten routine.

## 6) Pass criteria (minimum)
- Downshifts within ≤2 minutes after moderate excitement.

## 7) Proofing plan
- Practice after play, visitors, training.

## 8) Common pitfalls + fixes
- Expecting instant calm → teach the bridge routine.
- Using only when over threshold → condition earlier.
