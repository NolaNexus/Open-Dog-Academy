# REG_STARTLINE — Start line / ready-wait-release routine

**Type:** skill reference  
**Status:** draft  
**Last updated:** 2026-01-10

---

## 1) Definition
- Dog waits calmly until released, reducing impulsive launching.

## 2) Goals
- **Handler:** Consistent release cue; reward waiting.
- **Dog:** Holds position.

## 3) Prerequisites
- Sit/down stay or stationing

## 4) Equipment + setup
- Leash/long line; treats.

## 5) Teaching steps (progression)
1. Position → mark 1 sec wait.
2. Add release to reinforcement.
3. Increase to 3–10 sec.
4. Add movement and mild distractions.

## 6) Pass criteria (minimum)
- 10-sec wait for 5 reps with one cue max.

## 7) Proofing plan
- Use at doors, food bowl, play, training starts.

## 8) Common pitfalls + fixes
- Releasing on break → reinforces; reset.
- No clear release cue → standardize.
