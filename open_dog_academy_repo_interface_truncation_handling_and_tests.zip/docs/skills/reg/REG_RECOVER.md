# REG_RECOVER — Recovery after startle / interruption

**Type:** skill reference  
**Status:** draft  
**Last updated:** 2026-01-10

---

## 1) Definition
- Dog re-orients and returns to a known task after a minor surprise.

## 2) Goals
- **Handler:** Mark reorientation; cue easy behavior.
- **Dog:** Recovers without escalating.

## 3) Prerequisites
- Engagement/name response

## 4) Equipment + setup
- Controlled mild surprises at distance; treats.

## 5) Teaching steps (progression)
1. Mild noise at distance → mark reorient.
2. Cue easy behavior → treat.
3. Repeat varied surprises.
4. Increase realism gradually.

## 6) Pass criteria (minimum)
- Recovers and takes treat within 3 seconds for 5 trials.

## 7) Proofing plan
- Generalize environments and surfaces.

## 8) Common pitfalls + fixes
- Surprise too intense → reduce.
- Comforting during panic → focus on distance and easy task.
