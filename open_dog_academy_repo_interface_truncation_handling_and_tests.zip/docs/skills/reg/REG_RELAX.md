# REG_RELAX — Settle/relax on mat (downshift)

**Type:** skill reference  
**Status:** draft  
**Last updated:** 2026-01-10

---

## 1) Definition
- Dog lies down and maintains a relaxed state on a mat in distracting environments.

## 2) Goals
- **Handler:** Reinforce relaxation signals; keep sessions short.
- **Dog:** Downshifts and stays settled.

## 3) Prerequisites
- Mat/place basics or capturing calm

## 4) Equipment + setup
- Mat/bed; treats; optional chew.

## 5) Teaching steps (progression)
1. Capture calm signals (head down, hip shift).
2. Shape duration.
3. Add mild distractions.
4. Generalize to new environments at distance.

## 6) Pass criteria (minimum)
- 3 minutes settle with ≥3 relaxation markers in tier 2.

## 7) Proofing plan
- Increase time and distractions gradually.

## 8) Common pitfalls + fixes
- Paying only the down → tension; pay relaxation.
- Too close to triggers → increase distance.
