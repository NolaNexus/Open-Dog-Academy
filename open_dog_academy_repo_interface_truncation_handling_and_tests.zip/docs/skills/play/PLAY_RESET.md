# PLAY_RESET
Path: docs/skills/play/PLAY_RESET.md
Status: stub
Updated: 2026-01-10

## Definition
One sentence definition (draft).

## Goal
- Clear, observable success.

## Handler mechanics
--8<-- "_atoms/concepts/handler-mechanics-001.md"

## Session structure
--8<-- "_atoms/protocols/session-structure-001.md"

## Pass criteria
--8<-- "_atoms/rubrics/pass-criteria-template-001.md"

## Logging
--8<-- "_atoms/templates/logging-template-001.md"
