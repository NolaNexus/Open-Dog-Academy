# IND_SETTLE_SOLO — Settle while handler is busy

**Type:** skill reference  
**Status:** draft  
**Last updated:** 2026-01-10

---

## 1) Definition
- Dog relaxes while handler does tasks without constant input.

## 2) Goals
- **Handler:** Reinforce calm; provide structured enrichment.
- **Dog:** Chooses rest.

## 3) Prerequisites
- Mat/place or crate comfort

## 4) Equipment + setup
- Mat, chew/lick item, timer.

## 5) Teaching steps (progression)
1. Capture calm on mat.
2. Add duration.
3. Add tasks.
4. Fade treats; keep occasional bonuses.

## 6) Pass criteria (minimum)
- 10 minutes settle during normal task with ≤2 interruptions.

## 7) Proofing plan
- Generalize rooms and contexts.

## 8) Common pitfalls + fixes
- Paying pestering → reinforces; pay calm.
- Not enough outlets → add enrichment.
