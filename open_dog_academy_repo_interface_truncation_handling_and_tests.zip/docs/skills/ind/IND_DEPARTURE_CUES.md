# IND_DEPARTURE_CUES — Departure cue neutralization (keys/shoes/door)

**Type:** skill reference  
**Status:** draft  
**Last updated:** 2026-01-10

---

## 1) Definition
- Dog stays neutral when common departure cues occur.

## 2) Goals
- **Handler:** Desensitize cues separately; pair with calm reinforcement.
- **Dog:** Remains neutral.

## 3) Prerequisites
- IND_ALONE foundations

## 4) Equipment + setup
- Keys/shoes/coat; treats.

## 5) Teaching steps (progression)
1. Pick up keys → treat → put down.
2. Shoes → treat.
3. Door open/close → treat.
4. Combine slowly.

## 6) Pass criteria (minimum)
- Calm during 2-minute cue sequence (no pacing/vocalizing).

## 7) Proofing plan
- Generalize to different family members.

## 8) Common pitfalls + fixes
- Cues immediately followed by leaving too early → back up.
- Long sessions → keep short.
