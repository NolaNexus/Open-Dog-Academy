# IND_RECOVERY_ROUTINE — Post-stress recovery routine

**Type:** skill reference  
**Status:** draft  
**Last updated:** 2026-01-10

---

## 1) Definition
- Dog transitions from stimulation into a calm decompression routine.

## 2) Goals
- **Handler:** Predictable sequence (sniff, water, settle).
- **Dog:** Settles faster.

## 3) Prerequisites
- Leash skills + settle skills

## 4) Equipment + setup
- Quiet space, water, sniff area, mat.

## 5) Teaching steps (progression)
1. Sniff walk 2 minutes.
2. Water.
3. Scatter feed/lick.
4. Settle with calm pay.

## 6) Pass criteria (minimum)
- Recovery within 5–10 minutes (pacing drops, settles).

## 7) Proofing plan
- Use after visitors, training class, play.

## 8) Common pitfalls + fixes
- Forcing stillness → increases stress; decompress first.
