# IND_CONFINEMENT — Safe room / pen confinement

**Type:** skill reference  
**Status:** draft  
**Last updated:** 2026-01-10

---

## 1) Definition
- Dog stays calmly in pen/safe room as needed.

## 2) Goals
- **Handler:** Make confinement predictable and reinforced.
- **Dog:** Comfortable resting.

## 3) Prerequisites
- Basic settle

## 4) Equipment + setup
- Gates/pen, safe enrichment, water.

## 5) Teaching steps (progression)
1. Enter area → treat.
2. Close gate 1–3 sec → treat.
3. Add chew.
4. Increase duration with activity outside.

## 6) Pass criteria (minimum)
- 15 minutes calm confinement with enrichment; no repeated escape attempts.

## 7) Proofing plan
- Practice with doorbell/visitors later.

## 8) Common pitfalls + fixes
- Only used during chaos → negative; practice when calm.
