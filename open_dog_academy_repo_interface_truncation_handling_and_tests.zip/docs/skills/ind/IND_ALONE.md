# IND_ALONE — Alone-time resilience (graduated absences)

**Type:** skill reference  
**Status:** draft  
**Last updated:** 2026-01-10

---

## 1) Definition
- Dog remains calm when left alone for increasing durations.

## 2) Goals
- **Handler:** Gradual departures; return before distress.
- **Dog:** Settles during absences.

## 3) Prerequisites
- IND_CRATE or safe room
- Basic settle

## 4) Equipment + setup
- Camera helpful; settle item; routine cues.

## 5) Teaching steps (progression)
1. Micro-absences 5–15 sec.
2. Increase to 30–60 sec.
3. Add real exits.
4. Build to minutes; then longer.

## 6) Pass criteria (minimum)
- 10-minute absence with no sustained distress (no continuous barking >30 sec).

## 7) Proofing plan
- Vary time of day and family members.

## 8) Common pitfalls + fixes
- Jumping durations → regression; go smaller.
- Huge greetings on return → keep boring.
