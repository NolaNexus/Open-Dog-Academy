# IND_CRATE — Crate comfort (positive confinement)

**Type:** skill reference  
**Status:** draft  
**Last updated:** 2026-01-10

---

## 1) Definition
- Dog enters crate willingly, settles, and remains relaxed with door closed.

## 2) Goals
- **Handler:** Build crate value; never punish with crate.
- **Dog:** Comfortable resting in crate.

## 3) Prerequisites
- Marker skill helpful
- Dog can eat treats near crate

## 4) Equipment + setup
- Crate, mat, treats, optional lick/chew item.

## 5) Teaching steps (progression)
1. Treat toss in crate.
2. Feed meals in crate.
3. Close door 1–3 sec → treat → open.
4. Increase duration; add movement; then brief out-of-sight.

## 6) Pass criteria (minimum)
- Dog rests 10 minutes calmly; no vocalization >10 sec; relaxed body.

## 7) Proofing plan
- Generalize time of day and mild household noise.

## 8) Common pitfalls + fixes
- Door closed too soon → panic; shorten.
- Only crating before leaving → negative predictor.
