# LS_ENGAGE — Engagement check-ins (on leash)

**Type:** skill reference  
**Status:** draft  
**Last updated:** 2026-01-10

---

## 1) Definition
- Dog voluntarily orients to handler and can re-orient after sniffing/distractions.

## 2) Goals
- **Handler:** Reinforce check-ins, keep leash slack, use one cue max.
- **Dog:** Offer check-ins and re-engage quickly.

## 3) Prerequisites
- Marker skill (OB_MARKER or equivalent)
- Comfortable leash/harness wear

## 4) Equipment + setup
- 6–10 ft leash (or long line for early stages), high-value treats.
- Start in low distraction.

## 5) Teaching steps (progression)
1. Stand still; wait for glance → mark → treat at handler seam.
2. Add one step between check-ins.
3. Add sniffing permission: “go sniff” → name/attention → mark.
4. Add mild distractions (distance).

## 6) Pass criteria (minimum)
- In 2 environments, dog offers **≥10 check-ins in 5 minutes** with **≤1 leash tension event/min**.

## 7) Proofing plan
- Increase distraction tier; practice near (but not in) triggers.
- Add motion: zig-zag, U-turns, pace changes.

## 8) Common pitfalls + fixes
- Handler talks constantly → switch to silence + reinforce offered behavior.
- Leash tightens → stop, reset, reward position at seam.
- Dog rehearses pulling → increase distance, shorten criteria.
