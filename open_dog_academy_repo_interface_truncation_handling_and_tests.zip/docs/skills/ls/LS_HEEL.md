# LS_HEEL — Heel (precision walking) — optional

**Type:** skill reference  
**Status:** draft  
**Last updated:** 2026-01-10

---

## 1) Definition
- Dog maintains a defined position at handler side for short focused distances.

## 2) Goals
- **Handler:** Clear criteria; short reps.
- **Dog:** Hold position through turns and halts.

## 3) Prerequisites
- LLW basics
- Food/play reinforcement

## 4) Equipment + setup
- Clear start and release cue; start in low distraction.

## 5) Teaching steps (progression)
1. Stationary position → mark.
2. 1–3 steps → mark.
3. Add turns/halts.
4. Increase duration slowly; keep reps short.

## 6) Pass criteria (minimum)
- 30-sec heel: **≤2 position errors** for 3 reps at tier 1–2.

## 7) Proofing plan
- Add distractions after fluency; keep heel short/functional.

## 8) Common pitfalls + fixes
- Overdrilling → frustration; short sessions.
- Treat ahead → forging; treat at seam.
