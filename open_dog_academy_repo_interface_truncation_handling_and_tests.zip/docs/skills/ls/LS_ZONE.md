# LS_ZONE — Reinforcement zone (side position)

**Type:** skill reference  
**Status:** draft  
**Last updated:** 2026-01-10

---

## 1) Definition
- Dog learns where “pay happens” (handler’s seam) and drifts there during walking.

## 2) Goals
- **Handler:** Deliver reinforcement at seam; avoid luring.
- **Dog:** Choose the zone to earn.

## 3) Prerequisites
- Basic engagement or name response

## 4) Equipment + setup
- Treat pouch at hip; start indoors or driveway.

## 5) Teaching steps (progression)
1. Stationary: dog at seam → mark → treat.
2. One step: mark dog staying in zone.
3. Two–five steps: mark intermittently.
4. Add turns; pay in the new zone after turns.

## 6) Pass criteria (minimum)
- Dog returns to zone within **2 seconds** after drift for **10 reps**.

## 7) Proofing plan
- Add surfaces, narrow paths, and mild distractions.
- Pair with U-turn skill (LS_TURNS).

## 8) Common pitfalls + fixes
- Treat delivered forward → forging; treat at seam.
- Handler bends/leans → dog crowds; stay upright.
