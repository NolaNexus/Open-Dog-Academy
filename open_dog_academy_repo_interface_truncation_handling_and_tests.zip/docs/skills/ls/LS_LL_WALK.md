# LS_LL_WALK — Loose leash walking (LLW)

**Type:** skill reference  
**Status:** draft  
**Last updated:** 2026-01-10

---

## 1) Definition
- Dog walks with slack leash for functional distances, with breaks for sniffing.

## 2) Goals
- **Handler:** Reinforce slack, use planned sniff breaks.
- **Dog:** Maintain slack and re-orient after breaks.

## 3) Prerequisites
- LS_ZONE
- Engagement foundations

## 4) Equipment + setup
- Harness (front-clip optional), leash, treats.
- Choose a low-distraction route.

## 5) Teaching steps (progression)
1. Start line: stand, wait for slack → mark.
2. Walk 3–5 steps; mark slack; treat in zone.
3. If leash tightens: stop → wait for slack → mark.
4. Add structured sniff breaks: cue “go sniff” then back to zone.

## 6) Pass criteria (minimum)
- 10-minute walk: **≥80%** slack leash at tier 1–2; **≤3 pulls** total.

## 7) Proofing plan
- Increase route complexity; add pass-bys at distance.
- Add variable reinforcement once stable.

## 8) Common pitfalls + fixes
- Letting pulling work → dog learns pulling; stop consistently.
- Too-fast criteria → reduce distance, increase pay rate.
