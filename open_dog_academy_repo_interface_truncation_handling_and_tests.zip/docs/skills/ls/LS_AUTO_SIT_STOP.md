# LS_AUTO_SIT_STOP — Auto-sit at stops/curbs

**Type:** skill reference  
**Status:** draft  
**Last updated:** 2026-01-10

---

## 1) Definition
- When handler stops, dog sits (or stands calmly) without repeated cues.

## 2) Goals
- **Handler:** Stop cleanly; mark offered sit.
- **Dog:** Offer sit as default at stops.

## 3) Prerequisites
- Sit behavior (OB_SIT) OR default calm stand
- Leash foundations

## 4) Equipment + setup
- Practice at doorways/curbs; use high-value treats initially.

## 5) Teaching steps (progression)
1. Stop → wait 1–2 sec for sit → mark → treat.
2. If no sit: cue once → mark → treat.
3. Add duration: treat after 2–5 sec.
4. Generalize to curbs/crosswalks.

## 6) Pass criteria (minimum)
- Dog offers sit at **≥8/10 stops** across 2 locations (one cue max).

## 7) Proofing plan
- Add triggers at distance while maintaining calm stop behavior.

## 8) Common pitfalls + fixes
- Repeating cues → wait, then cue once.
- Dog creeps forward → feed in position; reset if leash loads.
