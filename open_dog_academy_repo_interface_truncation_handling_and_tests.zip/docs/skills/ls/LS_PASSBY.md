# LS_PASSBY — Pass-bys (people/dogs) with neutrality

**Type:** skill reference  
**Status:** draft  
**Last updated:** 2026-01-10

---

## 1) Definition
- Dog can pass a trigger at planned distance without lunging/barking.

## 2) Goals
- **Handler:** Manage distance; reinforce calm.
- **Dog:** Stay under threshold and keep moving.

## 3) Prerequisites
- LLW basics
- Engagement check-ins

## 4) Equipment + setup
- Wide space and escape routes; optional visual barriers.

## 5) Teaching steps (progression)
1. Start far: trigger appears → mark calm glance away → treat.
2. Parallel walk at distance.
3. Reduce distance only if calm.
4. Add planned pass-by with Safety Lead support.

## 6) Pass criteria (minimum)
- 5 pass-bys at tier 2: **no lunges**, **≤1 vocalization** total.

## 7) Proofing plan
- Vary triggers; add stationary and moving pass-bys.

## 8) Common pitfalls + fixes
- Closing distance too fast → increase distance.
- Treating only after explosion → treat pre-threshold.
