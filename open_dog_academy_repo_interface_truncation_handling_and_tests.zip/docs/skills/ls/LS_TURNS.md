# LS_TURNS — Turns and U-turns (escape hatch)

**Type:** skill reference  
**Status:** draft  
**Last updated:** 2026-01-10

---

## 1) Definition
- Dog follows handler through turns/U-turns without tangling or pulling.

## 2) Goals
- **Handler:** Turn early; mark dog staying connected.
- **Dog:** Pivot with handler and re-find zone.

## 3) Prerequisites
- LS_ZONE
- Engagement

## 4) Equipment + setup
- Practice in hallway/driveway; prioritize leash handling.

## 5) Teaching steps (progression)
1. 90° turn: step, turn, mark dog in zone.
2. 180° U-turn: say cue once, turn, mark reorientation.
3. Add speed changes.
4. Use near distractions BEFORE dog loads.

## 6) Pass criteria (minimum)
- Dog completes **10/10** U-turns with slack leash at tier 1–2.

## 7) Proofing plan
- Practice around mild triggers at safe distance.
- Add narrow paths/obstacles.

## 8) Common pitfalls + fixes
- Turning too late → turn earlier.
- Dog spins/zoomies → slow down, increase pay rate.
