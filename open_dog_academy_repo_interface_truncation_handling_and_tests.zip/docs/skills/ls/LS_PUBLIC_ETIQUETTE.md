# LS_PUBLIC_ETIQUETTE — Public etiquette bundle (stores, parks, patios)

**Type:** skill reference  
**Status:** draft  
**Last updated:** 2026-01-10

---

## 1) Definition
- Dog navigates public spaces calmly with minimal disruption.

## 2) Goals
- **Handler:** Advocate space; manage greetings; reinforce calm.
- **Dog:** Default to calm behaviors (zone, settle, pass-by).

## 3) Prerequisites
- LS_PASSBY
- LLW
- Mat settle (REG_RELAX or OB_PLACE)

## 4) Equipment + setup
- Mat, water, high-value treats; dog-friendly environment.

## 5) Teaching steps (progression)
1. Enter/exit practice with decompression.
2. Station on mat 1–3 minutes.
3. Pass-by practice in aisles/paths.
4. Short visits; end on success.

## 6) Pass criteria (minimum)
- 15-min outing: **≥3 settle bouts**, **no lunges/jumps**.

## 7) Proofing plan
- Increase time/complexity gradually; add new environments.

## 8) Common pitfalls + fixes
- Too long too soon → shorten.
- Unplanned greetings → advocate distance.
