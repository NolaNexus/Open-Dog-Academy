# CC_MOUTH — Mouth handling (teeth checks)

**Type:** skill reference  
**Status:** draft  
**Last updated:** 2026-01-10

---

## 1) Definition
- Dog allows brief lip lift and tooth look while consenting.

## 2) Goals
- **Handler:** Minimal restraint.
- **Dog:** Calm acceptance.

## 3) Prerequisites
- Chin rest/start button

## 4) Equipment + setup
- Treats; good lighting.

## 5) Teaching steps (progression)
1. Touch muzzle → treat.
2. Lift lip 0.5 sec → treat.
3. Increase to 1–2 sec; one side.
4. Repeat other side.

## 6) Pass criteria (minimum)
- Inspect both sides 1 sec each, 3 reps, relaxed.

## 7) Proofing plan
- Add toothbrush intro later.

## 8) Common pitfalls + fixes
- Holding too long → shorten.
- Chasing mouth → reset with start button.
