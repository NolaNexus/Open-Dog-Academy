# CC_BRUSH — Brushing / coat care

**Type:** skill reference  
**Status:** draft  
**Last updated:** 2026-01-10

---

## 1) Definition
- Dog accepts brushing strokes while relaxed and consenting.

## 2) Goals
- **Handler:** Tool predicts good things.
- **Dog:** Allows short bursts.

## 3) Prerequisites
- Start button behavior

## 4) Equipment + setup
- Brush/comb; treats.

## 5) Teaching steps (progression)
1. Show brush → treat.
2. Touch brush 1 sec → treat.
3. One stroke → treat.
4. Build to 5–10 strokes; breaks.

## 6) Pass criteria (minimum)
- 30 sec brushing total with breaks and calm body language.

## 7) Proofing plan
- Generalize to sensitive areas slowly.

## 8) Common pitfalls + fixes
- Brushing mats early → pain risk; adjust.
- Mouthing brush → increase distance.
