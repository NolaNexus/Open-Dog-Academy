# CC_MUZZLE — Muzzle conditioning

**Type:** skill reference  
**Status:** draft  
**Last updated:** 2026-01-10

---

## 1) Definition
- Dog happily puts nose into muzzle and can wear it comfortably.

## 2) Goals
- **Handler:** Make muzzle predict great things.
- **Dog:** Voluntary nose-in and relaxed wear.

## 3) Prerequisites
- Marker skill

## 4) Equipment + setup
- Basket muzzle, correct fit; treats.

## 5) Teaching steps (progression)
1. Muzzle appears → treat.
2. Nose in 0.5–2 sec → treat.
3. Add straps briefly → treat.
4. Build duration; add movement.

## 6) Pass criteria (minimum)
- 5 minutes calm wear, taking treats, no pawing.

## 7) Proofing plan
- Generalize to walks and new locations.

## 8) Common pitfalls + fixes
- Forcing straps → aversion; always voluntary.
- Poor fit → adjust.
