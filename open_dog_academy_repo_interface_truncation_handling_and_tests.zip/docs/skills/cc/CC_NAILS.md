# CC_NAILS — Nail trim foundations

**Type:** skill reference  
**Status:** draft  
**Last updated:** 2026-01-10

---

## 1) Definition
- Dog accepts nail tool presence and mock trim sequence (progressing to actual).

## 2) Goals
- **Handler:** Go slow; stop on opt-out.
- **Dog:** Remains relaxed.

## 3) Prerequisites
- CC_PAWS
- Start button

## 4) Equipment + setup
- Clippers/Dremel; treats; non-slip surface.

## 5) Teaching steps (progression)
1. Tool present → treat.
2. Tool near paw → treat.
3. Touch tool to nail (no cut) → treat.
4. Add pressure; then single nail trim when ready.

## 6) Pass criteria (minimum)
- Mock trim sequence on 2 nails/paw with relaxed body language.

## 7) Proofing plan
- One real trim per session when ready; high reinforcement.

## 8) Common pitfalls + fixes
- Going too fast → fear; slow.
- Tool noise fear → condition sound separately.
