# CC_INJECTIONS_SIM — Mock injections / restraint simulation

**Type:** skill reference  
**Status:** draft  
**Last updated:** 2026-01-10

---

## 1) Definition
- Dog tolerates gentle restraint and touch at injection sites using consent behaviors.

## 2) Goals
- **Handler:** Predictable sequences; stop on opt-out.
- **Dog:** Calm acceptance.

## 3) Prerequisites
- Start button
- Touch tolerance

## 4) Equipment + setup
- Blunt pen/cotton swab; treats.

## 5) Teaching steps (progression)
1. Touch shoulder → treat.
2. Touch with swab → treat.
3. Pinch sim 0.5 sec → treat.
4. Add gentle collar/shoulder hold.

## 6) Pass criteria (minimum)
- 5 reps pinch sim with relaxed body language and start button present.

## 7) Proofing plan
- Generalize to hips/legs; add table after fluent.

## 8) Common pitfalls + fixes
- Surprise intensity too high → slow.
- Restraint without agency → avoid.
