# CC_START_BUTTON — Start button behavior (consent)

**Type:** skill reference  
**Status:** draft  
**Last updated:** 2026-01-10

---

## 1) Definition
- Dog offers a clear “ready” behavior that starts handling and can opt out.

## 2) Goals
- **Handler:** Stop handling when start button is removed.
- **Dog:** Learns agency: participate to earn reinforcement.

## 3) Prerequisites
- Marker skill
- Calm stationing/mat helps

## 4) Equipment + setup
- Quiet space; high-value treats; 1–3 minute sessions.

## 5) Teaching steps (progression)
1. Teach start pose → mark.
2. Add micro-handling (touch 1 sec) → treat.
3. If dog breaks pose, pause and reset.
4. Increase duration/intensity gradually.

## 6) Pass criteria (minimum)
- Dog offers start button **≥8/10 reps** and holds 3 sec while touched.

## 7) Proofing plan
- Generalize rooms, helpers, tools.

## 8) Common pitfalls + fixes
- Continuing during opt-out → breaks trust; stop immediately.
- Sessions too long → shorten.
