# CC_CHIN_REST — Chin rest (primary consent behavior)

**Type:** skill reference  
**Status:** draft  
**Last updated:** 2026-01-10

---

## 1) Definition
- Dog rests chin on hand/towel target and holds while handled.

## 2) Goals
- **Handler:** Present target; mark hold; stop if chin lifts.
- **Dog:** Holds calmly.

## 3) Prerequisites
- CC_START_BUTTON recommended
- Marker skill

## 4) Equipment + setup
- Sit or stand; towel/hand target; treats.

## 5) Teaching steps (progression)
1. Mark contact.
2. Require 0.5–2 sec hold.
3. Add gentle touch elsewhere.
4. Increase duration slowly; add tools later.

## 6) Pass criteria (minimum)
- 5-sec chin rest holds for **5 reps** with calm body language.

## 7) Proofing plan
- Add ear touch, collar grab, brief muzzle touch during hold.

## 8) Common pitfalls + fixes
- Pushing duration → stress; reduce.
- Luring too long → fade lure quickly.
