# CC_PAWS — Paw handling (front + rear)

**Type:** skill reference  
**Status:** draft  
**Last updated:** 2026-01-10

---

## 1) Definition
- Dog allows paw touch/lift/hold with consent behavior present.

## 2) Goals
- **Handler:** Approach slowly; mark calm acceptance.
- **Dog:** Remains relaxed.

## 3) Prerequisites
- Chin rest/start button
- Touch tolerance

## 4) Equipment + setup
- Non-slip surface; treats; nail tool nearby only after comfort.

## 5) Teaching steps (progression)
1. Touch shoulder/leg → treat.
2. Touch paw → treat.
3. Brief lift 1 sec → treat.
4. Hold 2–5 sec; release; treat.

## 6) Pass criteria (minimum)
- Lift each paw 3 sec for 3 reps without pulling away.

## 7) Proofing plan
- Generalize positions and handlers.

## 8) Common pitfalls + fixes
- Grabbing suddenly → startle; slow.
- Avoidance → lower criteria.
