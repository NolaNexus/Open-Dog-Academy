# CC_EARS — Ear handling + ear checks

**Type:** skill reference  
**Status:** draft  
**Last updated:** 2026-01-10

---

## 1) Definition
- Dog accepts ear touch/lift and brief look without stress.

## 2) Goals
- **Handler:** Pair touches with treats.
- **Dog:** Calm acceptance.

## 3) Prerequisites
- Chin rest/start button

## 4) Equipment + setup
- Good lighting; treats.

## 5) Teaching steps (progression)
1. Touch cheek → treat.
2. Touch ear base → treat.
3. Lift flap 1 sec → treat.
4. Brief look + wipe simulation → treat.

## 6) Pass criteria (minimum)
- Ear look 2 sec each side, 5 reps, relaxed.

## 7) Proofing plan
- Generalize to standing/sitting.

## 8) Common pitfalls + fixes
- Head toss → back up.
- Restraint too tight → increase agency.
