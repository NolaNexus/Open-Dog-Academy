# OB_LEAVE_IT — Leave it (impulse control)

**Type:** skill reference  
**Status:** detailed draft (modular refactor)  
**Last updated:** 2026-01-10

---

## 1) Definition

- Dog disengages from a stimulus (food/object) on cue and re-orients to handler.

## 2) Goals

- **Handler goal:** Cue leave it, wait for disengage, mark, reinforce away from item.
- **Dog goal:** Turn away and look to you.

## 3) Setup

- **Environment:** D0. Begin with hand closed, then open, then floor.
- **Gear:** Treats, low-value item to start.
- **Progression:** D0 → D3 (see shared standards)
- **Standards:** `../standards/academy-standards.md`

## 4) Teaching steps (default)

### Step A — Create the behavior (D0)
- Keep reps short and easy; reinforce generously.
- Mark the instant the correct behavior happens; pay fast.

### Step B — Add one variable (duration OR distance)
- Increase one dimension at a time.
- If latency slows, you raised difficulty too fast—make the next rep easier.

### Step C — Generalize (new rooms → new yards → real life)
- Change context before changing difficulty.
- Use “easy-hard-easy” rep patterns to keep confidence high.

## 5) Pass criteria

- D0–D1: ≥ 80% with latency ≤ 3.0s; no lung demonstrates.

## 6) Drills

- Hand leave-it
- Floor leave-it with leash safety
- Leave-it → heel past

## 7) Common pitfalls + fixes

- Making it too tempting early → start easy
- Letting dog self-reward → block access with leash/body
- Punishing interest → reinforce disengagement instead

## 8) Notes

- Use management (leash/barriers) to prevent rehearsal of failures.
- Stop a session early if frustration rises; switch to an easy win and end.

