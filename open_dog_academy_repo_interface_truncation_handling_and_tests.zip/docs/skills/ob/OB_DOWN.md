# OB_DOWN — Down

**Type:** skill reference  
**Status:** detailed draft (modular refactor)  
**Last updated:** 2026-01-10

---

## 1) Definition

- Dog lies with elbows on ground and holds until release.

## 2) Goals

- **Handler goal:** Cue once, mark elbows down, feed low between paws, release.
- **Dog goal:** Down promptly and settle.

## 3) Setup

- **Environment:** D0. Use lure/hand signal; avoid pushing shoulders.
- **Gear:** Treats; mat optional.
- **Progression:** D0 → D3 (see shared standards)
- **Standards:** `../standards/academy-standards.md`

## 4) Teaching steps (default)

### Step A — Create the behavior (D0)
- Keep reps short and easy; reinforce generously.
- Mark the instant the correct behavior happens; pay fast.

### Step B — Add one variable (duration OR distance)
- Increase one dimension at a time.
- If latency slows, you raised difficulty too fast—make the next rep easier.

### Step C — Generalize (new rooms → new yards → real life)
- Change context before changing difficulty.
- Use “easy-hard-easy” rep patterns to keep confidence high.

## 5) Pass criteria

- ≥ 80% at D1, latency ≤ 3.0s; hold 5 seconds at D0.

## 6) Drills

- Down from stand/sit
- Down on mat
- Down while you step away (micro distance)

## 7) Common pitfalls + fixes

- Dog folds into sphinx then pops up → feed between paws, add duration slowly
- Dog resists slippery floor → use rug/mat
- Handler leans over dog → cue from upright posture

## 8) Notes

- Use management (leash/barriers) to prevent rehearsal of failures.
- Stop a session early if frustration rises; switch to an easy win and end.

