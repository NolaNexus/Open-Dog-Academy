# OB_PLACE — Place / mat (settle)

**Type:** skill reference  
**Status:** detailed draft (modular refactor)  
**Last updated:** 2026-01-10

---

## 1) Definition

- Dog goes to a mat/bed and stays until release.

## 2) Goals

- **Handler goal:** Cue place, mark four paws on mat, feed on mat, build duration, add distance.
- **Dog goal:** Seek mat and relax.

## 3) Setup

- **Environment:** D0. Start 1–2 steps away. Use stationing style.
- **Gear:** Mat/bed; treats.
- **Progression:** D0 → D3 (see shared standards)
- **Standards:** `../standards/academy-standards.md`

## 4) Teaching steps (default)

### Step A — Create the behavior (D0)
- Keep reps short and easy; reinforce generously.
- Mark the instant the correct behavior happens; pay fast.

### Step B — Add one variable (duration OR distance)
- Increase one dimension at a time.
- If latency slows, you raised difficulty too fast—make the next rep easier.

### Step C — Generalize (new rooms → new yards → real life)
- Change context before changing difficulty.
- Use “easy-hard-easy” rep patterns to keep confidence high.

## 5) Pass criteria

- D0: 20s hold; D1: 10s; ≥ 80% success with 1 cue.

## 6) Drills

- Place while you sit/stand
- Place with door knock (low)
- Place to settle during household activity

## 7) Common pitfalls + fixes

- Dog leaves mat after treat → feed multiple on mat before release
- Mat becomes ‘trap’ → add frequent releases and life rewards
- Too much distance too soon → reduce distance, increase rate of pay

## 8) Notes

- Use management (leash/barriers) to prevent rehearsal of failures.
- Stop a session early if frustration rises; switch to an easy win and end.

