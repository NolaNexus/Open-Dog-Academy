# OB_RELEASE — Release cue understanding

**Type:** skill reference  
**Status:** detailed draft (modular refactor)  
**Last updated:** 2026-01-10

---

## 1) Definition

- Dog understands a release cue ends the behavior and allows movement.

## 2) Goals

- **Handler goal:** Say release, then immediately move/throw treat/go to reward.
- **Dog goal:** Leave position only after release cue.

## 3) Setup

- **Environment:** Train alongside stays/place. Clear contrast: stay vs release.
- **Gear:** Treats/toy.
- **Progression:** D0 → D3 (see shared standards)
- **Standards:** `../standards/academy-standards.md`

## 4) Teaching steps (default)

### Step A — Create the behavior (D0)
- Keep reps short and easy; reinforce generously.
- Mark the instant the correct behavior happens; pay fast.

### Step B — Add one variable (duration OR distance)
- Increase one dimension at a time.
- If latency slows, you raised difficulty too fast—make the next rep easier.

### Step C — Generalize (new rooms → new yards → real life)
- Change context before changing difficulty.
- Use “easy-hard-easy” rep patterns to keep confidence high.

## 5) Pass criteria

- Dog holds until release on ≥ 80% reps; does not anticipate.

## 6) Drills

- Sit → release → scatter
- Place → release → go sniff
- Stay → release → chase toy

## 7) Common pitfalls + fixes

- Accidental releases (body language) → stay still, use clear cue
- Long holds causing guessing → shorten duration, pay in position
- Inconsistent word → pick one release word and stick to it

## 8) Notes

- Use management (leash/barriers) to prevent rehearsal of failures.
- Stop a session early if frustration rises; switch to an easy win and end.

