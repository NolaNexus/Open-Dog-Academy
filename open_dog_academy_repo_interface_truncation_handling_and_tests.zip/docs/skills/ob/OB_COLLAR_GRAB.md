# OB_COLLAR_GRAB — Collar grab comfort

**Type:** skill reference  
**Status:** detailed draft (modular refactor)  
**Last updated:** 2026-01-10

---

## 1) Definition

- Dog is comfortable with handler reaching for collar/harness.

## 2) Goals

- **Handler goal:** Reach → treat; then hold collar gently → treat; then brief tug → treat.
- **Dog goal:** Stay still and optimistic when grabbed.

## 3) Setup

- **Environment:** D0. Many tiny reps; pair with calm voice.
- **Gear:** Flat collar/harness; treats.
- **Progression:** D0 → D3 (see shared standards)
- **Standards:** `../standards/academy-standards.md`

## 4) Teaching steps (default)

### Step A — Create the behavior (D0)
- Keep reps short and easy; reinforce generously.
- Mark the instant the correct behavior happens; pay fast.

### Step B — Add one variable (duration OR distance)
- Increase one dimension at a time.
- If latency slows, you raised difficulty too fast—make the next rep easier.

### Step C — Generalize (new rooms → new yards → real life)
- Change context before changing difficulty.
- Use “easy-hard-easy” rep patterns to keep confidence high.

## 5) Pass criteria

- Allows grab from multiple angles with no avoidance; ≥ 80% success.

## 6) Drills

- Grab → treat → release
- Grab → recall → treat
- Grab while on mat

## 7) Common pitfalls + fixes

- Grabbing only for bad news → make it predict good stuff
- Squeezing/tugging early → start gentle
- Dog moves away → shorten reach, reinforce staying

## 8) Notes

- Use management (leash/barriers) to prevent rehearsal of failures.
- Stop a session early if frustration rises; switch to an easy win and end.

