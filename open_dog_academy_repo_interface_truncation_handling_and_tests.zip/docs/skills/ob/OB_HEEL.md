# OB_HEEL — Heel foundations / life heel

**Type:** skill reference  
**Status:** detailed draft (modular refactor)  
**Last updated:** 2026-01-10

---

## 1) Definition

- Dog walks close at handler’s side with attention as needed (sport heel or ‘life heel’).

## 2) Goals

- **Handler goal:** Define position, reinforce frequently, keep reps short, release to sniff.
- **Dog goal:** Stay in position with loose leash.

## 3) Setup

- **Environment:** D0. Start stationary heel position then 1–3 steps.
- **Gear:** Treats; leash; optional platform for position.
- **Progression:** D0 → D3 (see shared standards)
- **Standards:** `../standards/academy-standards.md`

## 4) Teaching steps (default)

### Step A — Create the behavior (D0)
- Keep reps short and easy; reinforce generously.
- Mark the instant the correct behavior happens; pay fast.

### Step B — Add one variable (duration OR distance)
- Increase one dimension at a time.
- If latency slows, you raised difficulty too fast—make the next rep easier.

### Step C — Generalize (new rooms → new yards → real life)
- Change context before changing difficulty.
- Use “easy-hard-easy” rep patterns to keep confidence high.

## 5) Pass criteria

- 10 steps with attention bursts at D0–D1, ≥ 80% position accuracy.

## 6) Drills

- Find heel position (stationary)
- 1–2–3 heel steps
- Turns/halts reinforcement

## 7) Common pitfalls + fixes

- Too long heeling → add frequent releases
- Dog forges → feed at seam, turn away
- Handler lures forever → fade lure, reward after movement

## 8) Notes

- Use management (leash/barriers) to prevent rehearsal of failures.
- Stop a session early if frustration rises; switch to an easy win and end.

