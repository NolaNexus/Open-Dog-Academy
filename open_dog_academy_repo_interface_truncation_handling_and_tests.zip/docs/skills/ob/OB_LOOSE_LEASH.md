# OB_LOOSE_LEASH — Loose leash foundations (reinforcement zone)

**Type:** skill reference  
**Status:** detailed draft (modular refactor)  
**Last updated:** 2026-01-10

---

## 1) Definition

- Dog walks with slack leash in the reinforcement zone (near handler’s leg).

## 2) Goals

- **Handler goal:** Reinforce in-position steps, stop before leash tightens, reward check-ins.
- **Dog goal:** Choose the zone that keeps leash loose.

## 3) Setup

- **Environment:** Start D0 hallway/backyard. 5–20 step reps. Use “go sniff” releases.
- **Gear:** Flat collar/harness + 6 ft leash; treats.
- **Progression:** D0 → D3 (see shared standards)
- **Standards:** `../standards/academy-standards.md`

## 4) Teaching steps (default)

### Step A — Create the behavior (D0)
- Keep reps short and easy; reinforce generously.
- Mark the instant the correct behavior happens; pay fast.

### Step B — Add one variable (duration OR distance)
- Increase one dimension at a time.
- If latency slows, you raised difficulty too fast—make the next rep easier.

### Step C — Generalize (new rooms → new yards → real life)
- Change context before changing difficulty.
- Use “easy-hard-easy” rep patterns to keep confidence high.

## 5) Pass criteria

- 20 steps at D0–D1 with slack ≥ 80% of steps; minimal pulling resets.

## 6) Drills

- 1-2-3 walking game
- Red light/green light (stop before tight)
- Reinforcement zone figure-8s

## 7) Common pitfalls + fixes

- Waiting until pulling to respond → prevent, don’t correct late
- Feeding in front → feed at seam to avoid forging
- Sessions too long → do micro-walks, end before fatigue

## 8) Notes

- Use management (leash/barriers) to prevent rehearsal of failures.
- Stop a session early if frustration rises; switch to an easy win and end.

