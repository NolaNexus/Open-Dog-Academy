# OB_RECALL_TO_POS — Recall to position (front/heel)

**Type:** skill reference  
**Status:** detailed draft (modular refactor)  
**Last updated:** 2026-01-10

---

## 1) Definition

- Dog recalls and finishes in a specific position (front or heel).

## 2) Goals

- **Handler goal:** Call, guide to position, mark correct alignment, pay in place.
- **Dog goal:** Return fast and land in position without bumping.

## 3) Setup

- **Environment:** D0. Start close; use lures or platforms for precision.
- **Gear:** Treats; leash/long line.
- **Progression:** D0 → D3 (see shared standards)
- **Standards:** `../standards/academy-standards.md`

## 4) Teaching steps (default)

### Step A — Create the behavior (D0)
- Keep reps short and easy; reinforce generously.
- Mark the instant the correct behavior happens; pay fast.

### Step B — Add one variable (duration OR distance)
- Increase one dimension at a time.
- If latency slows, you raised difficulty too fast—make the next rep easier.

### Step C — Generalize (new rooms → new yards → real life)
- Change context before changing difficulty.
- Use “easy-hard-easy” rep patterns to keep confidence high.

## 5) Pass criteria

- D0: 5/6 correct entries; D1: ≥ 80% with mild distraction.

## 6) Drills

- Short recall-to-front
- Recall-to-heel with pivot step
- Front → heel transitions

## 7) Common pitfalls + fixes

- Dog swings wide → use wall/barrier early
- Crooked fronts → reinforce straight, use platform
- Slow finish → pay for speed, shrink distance

## 8) Notes

- Use management (leash/barriers) to prevent rehearsal of failures.
- Stop a session early if frustration rises; switch to an easy win and end.

