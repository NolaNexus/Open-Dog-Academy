# OB_STAND — Stand

**Type:** skill reference  
**Status:** detailed draft (modular refactor)  
**Last updated:** 2026-01-10

---

## 1) Definition

- Dog stands square-ish (or comfortable) and holds for brief exam/handling.

## 2) Goals

- **Handler goal:** Cue stand, mark stillness, pay at nose level, add gentle touches.
- **Dog goal:** Stand and remain steady through light handling.

## 3) Setup

- **Environment:** D0. Start from sit/down with lure forward; or capture stands.
- **Gear:** Treats; leash/hand support optional.
- **Progression:** D0 → D3 (see shared standards)
- **Standards:** `../standards/academy-standards.md`

## 4) Teaching steps (default)

### Step A — Create the behavior (D0)
- Keep reps short and easy; reinforce generously.
- Mark the instant the correct behavior happens; pay fast.

### Step B — Add one variable (duration OR distance)
- Increase one dimension at a time.
- If latency slows, you raised difficulty too fast—make the next rep easier.

### Step C — Generalize (new rooms → new yards → real life)
- Change context before changing difficulty.
- Use “easy-hard-easy” rep patterns to keep confidence high.

## 5) Pass criteria

- Hold 3–5 seconds at D0 with light touch; ≥ 80% at D1.

## 6) Drills

- Stand → treat at nose (still)
- Stand for collar touch
- Stand from heel position

## 7) Common pitfalls + fixes

- Dog steps forward → feed in place, reset feet gently with lure
- Dog sits → reward stands more heavily, shorten reps
- Over-handling early → pair handling with high rate of reinforcement

## 8) Notes

- Use management (leash/barriers) to prevent rehearsal of failures.
- Stop a session early if frustration rises; switch to an easy win and end.

