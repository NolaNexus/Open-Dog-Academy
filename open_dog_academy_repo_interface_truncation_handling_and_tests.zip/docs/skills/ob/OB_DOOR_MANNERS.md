# OB_DOOR_MANNERS — Door manners / threshold control

**Type:** skill reference  
**Status:** detailed draft (modular refactor)  
**Last updated:** 2026-01-10

---

## 1) Definition

- Dog waits at thresholds until released and can pass through calmly.

## 2) Goals

- **Handler goal:** Approach door, reinforce pauses, open/close as consequence, release on cue.
- **Dog goal:** Stop at threshold and wait.

## 3) Setup

- **Environment:** D0 inside; no guests; low arousal.
- **Gear:** Leash; treats.
- **Progression:** D0 → D3 (see shared standards)
- **Standards:** `../standards/academy-standards.md`

## 4) Teaching steps (default)

### Step A — Create the behavior (D0)
- Keep reps short and easy; reinforce generously.
- Mark the instant the correct behavior happens; pay fast.

### Step B — Add one variable (duration OR distance)
- Increase one dimension at a time.
- If latency slows, you raised difficulty too fast—make the next rep easier.

### Step C — Generalize (new rooms → new yards → real life)
- Change context before changing difficulty.
- Use “easy-hard-easy” rep patterns to keep confidence high.

## 5) Pass criteria

- Waits 3 seconds with door open crack; then full open; ≥ 80%.

## 6) Drills

- Door crack game
- Wait → release → sniff reward
- Door manners with family movement

## 7) Common pitfalls + fixes

- Rushing into difficulty (guests) → build in quiet first
- Yanking leash → instead close door/reset
- No clear release → train release cue separately

## 8) Notes

- Use management (leash/barriers) to prevent rehearsal of failures.
- Stop a session early if frustration rises; switch to an easy win and end.

