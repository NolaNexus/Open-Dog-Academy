# OB_TOUCH — Hand target (touch)

**Type:** skill reference  
**Status:** detailed draft (modular refactor)  
**Last updated:** 2026-01-10

---

## 1) Definition

- Dog boops handler’s presented hand target with nose.

## 2) Goals

- **Handler goal:** Present target hand, cue once, mark contact, pay at your leg.
- **Dog goal:** Move to hand and touch with nose quickly.

## 3) Setup

- **Environment:** D0. Start close (2–6 inches) then increase distance.
- **Gear:** Treats; optional target sticker for early reps.
- **Progression:** D0 → D3 (see shared standards)
- **Standards:** `../standards/academy-standards.md`

## 4) Teaching steps (default)

### Step A — Create the behavior (D0)
- Keep reps short and easy; reinforce generously.
- Mark the instant the correct behavior happens; pay fast.

### Step B — Add one variable (duration OR distance)
- Increase one dimension at a time.
- If latency slows, you raised difficulty too fast—make the next rep easier.

### Step C — Generalize (new rooms → new yards → real life)
- Change context before changing difficulty.
- Use “easy-hard-easy” rep patterns to keep confidence high.

## 5) Pass criteria

- ≥ 80% success, latency ≤ 2.0s at D1; can do 3–5 feet at D0.

## 6) Drills

- Touch ping-pong (left/right hand)
- Touch to move past distraction
- Touch as recall assist

## 7) Common pitfalls + fixes

- Hand too far too soon → shrink distance
- Dog mouths hand → present flat palm, reinforce gentle nose touches
- Dog anticipates and jumps → lower arousal, reinforce calm approach

## 8) Notes

- Use management (leash/barriers) to prevent rehearsal of failures.
- Stop a session early if frustration rises; switch to an easy win and end.

