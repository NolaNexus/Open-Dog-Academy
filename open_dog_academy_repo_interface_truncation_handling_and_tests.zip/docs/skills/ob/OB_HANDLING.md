# OB_HANDLING — Handling tolerance starter

**Type:** skill reference  
**Status:** detailed draft (modular refactor)  
**Last updated:** 2026-01-10

---

## 1) Definition

- Dog accepts brief touch on body parts without avoidance or mouthing.

## 2) Goals

- **Handler goal:** Touch → treat sequence; stop before discomfort; build gradually.
- **Dog goal:** Stay neutral/relaxed during touch.

## 3) Setup

- **Environment:** D0. Start with shoulder/chest; 1–2 sec touches.
- **Gear:** Treats; optional grooming tools later.
- **Progression:** D0 → D3 (see shared standards)
- **Standards:** `../standards/academy-standards.md`

## 4) Teaching steps (default)

### Step A — Create the behavior (D0)
- Keep reps short and easy; reinforce generously.
- Mark the instant the correct behavior happens; pay fast.

### Step B — Add one variable (duration OR distance)
- Increase one dimension at a time.
- If latency slows, you raised difficulty too fast—make the next rep easier.

### Step C — Generalize (new rooms → new yards → real life)
- Change context before changing difficulty.
- Use “easy-hard-easy” rep patterns to keep confidence high.

## 5) Pass criteria

- Dog stays in position; no flinch/withdraw; ≥ 80% neutral reps.

## 6) Drills

- Consent test (start/stop)
- Touch + feed (chin)
- Mock exam (ear/lip/feet)

## 7) Common pitfalls + fixes

- Going too long → micro touches
- Ignoring stress signals → pause, reduce intensity
- Restraint too early → build opt-in behaviors first

## 8) Notes

- Use management (leash/barriers) to prevent rehearsal of failures.
- Stop a session early if frustration rises; switch to an easy win and end.

