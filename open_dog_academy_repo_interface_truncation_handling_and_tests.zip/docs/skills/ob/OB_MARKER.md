# OB_MARKER — Marker understanding (click/yes)

**Type:** skill reference  
**Status:** detailed draft (modular refactor)  
**Last updated:** 2026-01-10

---

## 1) Definition

- Dog understands that a click/“yes” predicts reinforcement and ends the rep.

## 2) Goals

- **Handler goal:** Deliver marker at the exact moment the behavior happens; pay within 1 second.
- **Dog goal:** Upon marker, snap to you for reward.

## 3) Setup

- **Environment:** D0 only. Quiet room. 20–40 pairings over 1–2 sessions.
- **Gear:** Clicker optional; treats.
- **Progression:** D0 → D3 (see shared standards)
- **Standards:** `../standards/academy-standards.md`

## 4) Teaching steps (default)

### Step A — Create the behavior (D0)
- Keep reps short and easy; reinforce generously.
- Mark the instant the correct behavior happens; pay fast.

### Step B — Add one variable (duration OR distance)
- Increase one dimension at a time.
- If latency slows, you raised difficulty too fast—make the next rep easier.

### Step C — Generalize (new rooms → new yards → real life)
- Change context before changing difficulty.
- Use “easy-hard-easy” rep patterns to keep confidence high.

## 5) Pass criteria

- On marker, dog re-orients and approaches within 1–2s on ≥ 90% of pairings.

## 6) Drills

- Charge marker (marker→treat)
- Marker while dog looks away (easy)
- Marker + reset routine

## 7) Common pitfalls + fixes

- Delay between marker and pay → preload treats, pay faster
- Talking after marker → keep marker “clean” (marker means pay)
- Using marker as cue → marker is feedback, not a cue

## 8) Notes

- Use management (leash/barriers) to prevent rehearsal of failures.
- Stop a session early if frustration rises; switch to an easy win and end.

