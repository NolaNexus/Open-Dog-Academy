# OB_SIT — Sit

**Type:** skill reference  
**Status:** detailed draft (modular refactor)  
**Last updated:** 2026-01-10

---

## 1) Definition

- Dog places rear on ground and holds until release.

## 2) Goals

- **Handler goal:** Cue once, mark when elbows/hips settle, reinforce in position, then release.
- **Dog goal:** Sit promptly and stay until released.

## 3) Setup

- **Environment:** D0. Lure if needed; fade lure to hand signal then verbal.
- **Gear:** Treats; leash optional.
- **Progression:** D0 → D3 (see shared standards)
- **Standards:** `../standards/academy-standards.md`

## 4) Teaching steps (default)

### Step A — Create the behavior (D0)
- Keep reps short and easy; reinforce generously.
- Mark the instant the correct behavior happens; pay fast.

### Step B — Add one variable (duration OR distance)
- Increase one dimension at a time.
- If latency slows, you raised difficulty too fast—make the next rep easier.

### Step C — Generalize (new rooms → new yards → real life)
- Change context before changing difficulty.
- Use “easy-hard-easy” rep patterns to keep confidence high.

## 5) Pass criteria

- ≥ 80% at D1, latency ≤ 3.0s; hold 3 seconds at D0.

## 6) Drills

- Sit for greetings (with management)
- Sit in motion (walk→sit)
- Sit-stay micro duration

## 7) Common pitfalls + fixes

- Creeping sit → pay for stillness, reinforce at chest height
- Slow sits → reinforce speed, reduce distractions
- Dog pops up after treat → feed multiple in position before release

## 8) Notes

- Use management (leash/barriers) to prevent rehearsal of failures.
- Stop a session early if frustration rises; switch to an easy win and end.

