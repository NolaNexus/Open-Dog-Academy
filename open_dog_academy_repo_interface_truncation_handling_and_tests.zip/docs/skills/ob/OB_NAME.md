# OB_NAME — Name response / orient to handler

**Type:** skill reference  
**Status:** detailed draft (modular refactor)  
**Last updated:** 2026-01-10

---

## 1) Definition

- Dog orients to handler (eye contact or head turn) within 1–2 seconds after hearing their name.

## 2) Goals

- **Handler goal:** Say name once, mark the instant the dog orients, deliver reinforcement at your body (not thrown).
- **Dog goal:** Whip head toward you and stay connected long enough to earn pay.

## 3) Setup

- **Environment:** Start D0 indoors. Use high-value reinforcers. Dog should not be over-aroused.
- **Gear:** None; optionally leash indoors for management.
- **Progression:** D0 → D3 (see shared standards)
- **Standards:** `../standards/academy-standards.md`

## 4) Teaching steps (default)

### Step A — Create the behavior (D0)
- Keep reps short and easy; reinforce generously.
- Mark the instant the correct behavior happens; pay fast.

### Step B — Add one variable (duration OR distance)
- Increase one dimension at a time.
- If latency slows, you raised difficulty too fast—make the next rep easier.

### Step C — Generalize (new rooms → new yards → real life)
- Change context before changing difficulty.
- Use “easy-hard-easy” rep patterns to keep confidence high.

## 5) Pass criteria

- ≥ 80% at D0–D1 with latency ≤ 2.0s across 2 sessions; no repeated cue.

## 6) Drills

- Name game (stationary)
- Name while dog sniffs (easy)
- Name → hand target chain

## 7) Common pitfalls + fixes

- Saying name repeatedly → wait, reset, lower distraction
- Marking late → practice without dog first (dry runs)
- Dog disengages after pay → deliver treat at your seam, then release

## 8) Notes

- Use management (leash/barriers) to prevent rehearsal of failures.
- Stop a session early if frustration rises; switch to an easy win and end.

