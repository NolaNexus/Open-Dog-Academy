# OB_RECALL — Recall (foundations)

**Type:** skill reference  
**Status:** detailed draft (atoms-first)  
**Last updated:** 2026-01-10

---

## Definition

Dog returns to handler promptly when called.

## OB_RECALL essentials (non-negotiables)

- **One cue** when possible. If you need repeats, your setup is too hard.
- **Mark the commit:** the instant your dog turns toward you.
- **Pay big for hard reps**, then release back to fun when safe (Premack).
- Use **management** (long line, distance, barriers) to prevent rehearsing failures.

---

## Session start ritual

--8<-- "_atoms/protocols/session-start-ritual-001.md"

## Session structure

--8<-- "_atoms/protocols/session-structure-001.md"

## Marker timing

--8<-- "_atoms/concepts/marker-timing-001.md"

## Errorless learning

--8<-- "_atoms/protocols/errorless-learning-001.md"

## Reward tiering

--8<-- "_atoms/protocols/reward-tiering-001.md"

## Reinforcement schedule

--8<-- "_atoms/protocols/reinforcement-schedule-001.md"

---

## Proofing ladder

--8<-- "_atoms/rubrics/proofing-ladder-001.md"

## Distance rubric

--8<-- "_atoms/rubrics/distance-rubric-001.md"

## Distraction rubric

--8<-- "_atoms/rubrics/distraction-rubric-001.md"

## Latency rubric

--8<-- "_atoms/rubrics/latency-rubric-001.md"

## Generalization checklist

--8<-- "_atoms/checklists/generalization-checklist-001.md"

---

## Safety gating

--8<-- "_atoms/safety/safety-gating-001.md"

## Troubleshooting loop

--8<-- "_atoms/troubleshooting/troubleshooting-loop-001.md"

## Decompression menu

--8<-- "_atoms/checklists/decompression-menu-001.md"

---

## Pass criteria (OB_RECALL)

--8<-- "_atoms/rubrics/pass-criteria-template-001.md"

### OB_RECALL fill-in (suggested)
- **Environment:** quiet yard or large indoor space (X0–X1)
- **Equipment:** long line available; rewards ready (Tier 2–3)
- **Handler rules:** one cue; no luring; you may back up to invite chase

**Pass**
- **Accuracy:** ≥ 8/10 reps
- **Latency:** average L0–L1 (≤ 2s) with no rep above L2
- **Distance:** D1–D2 (3–30 ft) depending on space
- **Distraction:** X1 (mild movement/noises)
- **Recovery:** after an error, dog re-orients and can succeed within 2 easy reps

**Fail**
- Cue repetition becomes necessary
- Dog disengages into sustained sniffing/play without recovery
- Safety gating triggers (end session; switch to management)

---

## Logging

--8<-- "_atoms/templates/logging-template-001.md"
