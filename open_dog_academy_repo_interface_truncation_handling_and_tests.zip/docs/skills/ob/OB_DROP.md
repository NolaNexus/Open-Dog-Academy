# OB_DROP — Drop / Out (trade-based)

**Type:** skill reference  
**Status:** detailed draft (modular refactor)  
**Last updated:** 2026-01-10

---

## 1) Definition

- Dog releases item to handler on cue; trade-based.

## 2) Goals

- **Handler goal:** Cue drop, present trade, mark release, give trade, return item (sometimes).
- **Dog goal:** Spit item out quickly and stay engaged.

## 3) Setup

- **Environment:** D0. Use low arousal tug or chew; avoid prying mouth.
- **Gear:** Two toys or toy + treats.
- **Progression:** D0 → D3 (see shared standards)
- **Standards:** `../standards/academy-standards.md`

## 4) Teaching steps (default)

### Step A — Create the behavior (D0)
- Keep reps short and easy; reinforce generously.
- Mark the instant the correct behavior happens; pay fast.

### Step B — Add one variable (duration OR distance)
- Increase one dimension at a time.
- If latency slows, you raised difficulty too fast—make the next rep easier.

### Step C — Generalize (new rooms → new yards → real life)
- Change context before changing difficulty.
- Use “easy-hard-easy” rep patterns to keep confidence high.

## 5) Pass criteria

- Release within 2 seconds on ≥ 80% reps at D0–D1.

## 6) Drills

- Two-toy swap
- Tug → drop → resume tug (Premack)
- Drop with mild household items

## 7) Common pitfalls + fixes

- Always taking item away → sometimes give it back
- Chasing dog → trade, don’t pursue
- Cue repeated → pause, lower difficulty

## 8) Notes

- Use management (leash/barriers) to prevent rehearsal of failures.
- Stop a session early if frustration rises; switch to an easy win and end.

