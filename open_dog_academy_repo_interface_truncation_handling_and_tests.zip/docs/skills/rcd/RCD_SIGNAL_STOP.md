# RCD_SIGNAL_STOP — Signal → stop/down (emergency brake)

**Type:** skill reference  
**Status:** draft  
**Last updated:** 2026-01-10

---

## 1) Definition
- Dog stops movement after signal (stand or down).

## 2) Goals
- **Handler:** Train in low arousal first.
- **Dog:** Stops reliably.

## 3) Prerequisites
- Strong stop/down on normal cue
- RCD_SIGNAL_ORIENT

## 4) Equipment + setup
- Long line; safe space.

## 5) Teaching steps (progression)
1. Signal → verbal down → treat.
2. Fade verbal.
3. Add distance.
4. Proof with mild motion.

## 6) Pass criteria (minimum)
- ≥9/10 success within 2 seconds at tier 2.

## 7) Proofing plan
- Generalize slowly; never near hazards early.

## 8) Common pitfalls + fixes
- Training near hazards too soon → unsafe; use safe spaces.
