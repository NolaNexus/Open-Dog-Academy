# RCD_WEAR_COMFORT — Wear comfort (device is neutral/positive)

**Type:** skill reference  
**Status:** draft  
**Last updated:** 2026-01-10

---

## 1) Definition
- Dog shows relaxed body language when device is worn and does not scratch/panic.

## 2) Goals
- **Handler:** Pair device with good things; ensure fit.
- **Dog:** Comfortable wearing it.

## 3) Prerequisites
- None

## 4) Equipment + setup
- Fit per manufacturer; check skin; use treats/play.

## 5) Teaching steps (progression)
1. Show device → treat.
2. Put on → treat → remove.
3. Wear during fun activity.
4. Increase duration gradually.

## 6) Pass criteria (minimum)
- Wears 20 minutes relaxed; no avoidance or persistent scratching.

## 7) Proofing plan
- Practice across contexts.

## 8) Common pitfalls + fixes
- Using only before scary events → negative predictor; use during fun.
- Poor fit → discomfort; adjust.
