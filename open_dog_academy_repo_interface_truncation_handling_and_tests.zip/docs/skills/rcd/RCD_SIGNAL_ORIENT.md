# RCD_SIGNAL_ORIENT — Signal → orient (vibrate/beep/flash)

**Type:** skill reference  
**Status:** draft  
**Last updated:** 2026-01-10

---

## 1) Definition
- Dog orients to handler within 1–2 seconds after the signal.

## 2) Goals
- **Handler:** Signal once; mark orientation; reinforce.
- **Dog:** Signal means ‘check in.’

## 3) Prerequisites
- RCD_WEAR_COMFORT
- Marker skill

## 4) Equipment + setup
- Start in quiet space; use lowest salience signal first.

## 5) Teaching steps (progression)
1. Signal → treat (pairing).
2. Signal → wait for look → mark → treat.
3. Add movement.
4. Generalize carefully.

## 6) Pass criteria (minimum)
- Orients within 2 seconds for 10 reps at tier 1–2.

## 7) Proofing plan
- Add mild distractions at distance.

## 8) Common pitfalls + fixes
- Signal startles dog → reduce intensity and pair more.
- Repeating signal → signal once, reset.
