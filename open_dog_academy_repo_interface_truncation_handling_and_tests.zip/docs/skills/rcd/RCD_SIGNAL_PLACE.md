# RCD_SIGNAL_PLACE — Signal → go to place/mat

**Type:** skill reference  
**Status:** draft  
**Last updated:** 2026-01-10

---

## 1) Definition
- Dog goes to mat/spot after signal.

## 2) Goals
- **Handler:** Strong place first.
- **Dog:** Signal means ‘go settle.’

## 3) Prerequisites
- Strong place/mat
- RCD_SIGNAL_ORIENT

## 4) Equipment + setup
- Visible mat; treats.

## 5) Teaching steps (progression)
1. Signal → cue place → treat.
2. Fade verbal.
3. Add distance.
4. Generalize mats/spots.

## 6) Pass criteria (minimum)
- 8/10 success within 3 seconds at tier 2.

## 7) Proofing plan
- Add visitors/doorbell simulations later.

## 8) Common pitfalls + fixes
- Using during scolding moments → poisons cue; keep positive.
