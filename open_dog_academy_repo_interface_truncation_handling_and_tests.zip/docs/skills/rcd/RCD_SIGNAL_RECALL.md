# RCD_SIGNAL_RECALL — Signal → recall

**Type:** skill reference  
**Status:** draft  
**Last updated:** 2026-01-10

---

## 1) Definition
- Dog returns to handler after signal, same as a recall cue.

## 2) Goals
- **Handler:** Signal once; jackpot; never punish.
- **Dog:** Signal means ‘come get paid.’

## 3) Prerequisites
- Reliable recall on normal cue
- RCD_SIGNAL_ORIENT

## 4) Equipment + setup
- Long line; high-value rewards.

## 5) Teaching steps (progression)
1. Signal → run backwards → jackpot.
2. Add distance.
3. Add distractions slowly.
4. Fade handler motion.

## 6) Pass criteria (minimum)
- ≥9/10 success at tier 2 on long line.

## 7) Proofing plan
- Increase complexity; keep safety line until validated.

## 8) Common pitfalls + fixes
- Only use when dog is in trouble → poisons cue; use often for fun.
