# RET_HOLD — (add title)

**Type:** skill reference  
**Status:** draft  
**Last updated:** 2026-01-10

---

## 1) What this skill is
- **Definition:** 
- **Handler goal:** 
- **Dog goal:** 

## 2) Setup
- **Environment:** 
- **Gear:** 
- **Reinforcers:** 

## 3) Teaching plan
### Step A — Create the behavior (D0)
### Step B — Add duration/distance
### Step C — Add distraction + generalize

## 4) Pass criteria
- **Accuracy:** 
- **Latency:** 
- **Context:** 

## 5) Drills
1.
2.
3.

## 6) Pitfalls + fixes
- 
