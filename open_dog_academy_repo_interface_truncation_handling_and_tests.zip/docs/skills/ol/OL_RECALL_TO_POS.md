# OL_RECALL_TO_POS — Recall-to-position for control

**Type:** skill reference  
**Status:** detailed draft (modular refactor)  
**Last updated:** 2026-01-10

---

## 1) Definition

- Dog recalls to a specified position (front/heel) during off-leash work.

## 2) Goals

- **Handler goal:** Call + position cue, mark correct finish, pay, release.
- **Dog goal:** Return fast and finish precisely.

## 3) Setup

- **Environment:** Build in D0 then add distance/distraction slowly.
- **Gear:** Long line early; treats.
- **Progression:** D0 → D3 (see shared standards)
- **Standards:** `../standards/academy-standards.md`

## 4) Teaching steps (default)

### Step A — Create the behavior (D0)
- Keep reps short and easy; reinforce generously.
- Mark the instant the correct behavior happens; pay fast.

### Step B — Add one variable (duration OR distance)
- Increase one dimension at a time.
- If latency slows, you raised difficulty too fast—make the next rep easier.

### Step C — Generalize (new rooms → new yards → real life)
- Change context before changing difficulty.
- Use “easy-hard-easy” rep patterns to keep confidence high.

## 5) Pass criteria

- ≥ 80% correct finishes at D1; latency ≤ 3s.

## 6) Drills

- Recall-to-heel with pivot
- Recall-to-front → heel
- Recall-to-pos from sniffing

## 7) Common pitfalls + fixes

- Crooked entries → use barriers/platforms
- Dog slow → reward speed heavily
- Too much precision too early → alternate ‘fast’ reps with ‘pretty’ reps

## 8) Notes

- Use management (leash/barriers) to prevent rehearsal of failures.
- Stop a session early if frustration rises; switch to an easy win and end.

