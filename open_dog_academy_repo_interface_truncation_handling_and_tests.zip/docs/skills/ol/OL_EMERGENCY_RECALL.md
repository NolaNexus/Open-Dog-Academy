# OL_EMERGENCY_RECALL — Emergency recall (few reps, high value)

**Type:** skill reference  
**Status:** detailed draft (modular refactor)  
**Last updated:** 2026-01-10

---

## 1) Definition

- Special recall cue used rarely, paired with massive reinforcement, for true emergencies.

## 2) Goals

- **Handler goal:** Use only when you can pay huge; never poison with consequences.
- **Dog goal:** Immediate sprint to you when cue is heard.

## 3) Setup

- **Environment:** Condition separately from normal recall. Only 1–3 reps per week/month.
- **Gear:** Best reinforcer (meat/cheese/toy); long line early.
- **Progression:** D0 → D3 (see shared standards)
- **Standards:** `../standards/academy-standards.md`

## 4) Teaching steps (default)

### Step A — Create the behavior (D0)
- Keep reps short and easy; reinforce generously.
- Mark the instant the correct behavior happens; pay fast.

### Step B — Add one variable (duration OR distance)
- Increase one dimension at a time.
- If latency slows, you raised difficulty too fast—make the next rep easier.

### Step C — Generalize (new rooms → new yards → real life)
- Change context before changing difficulty.
- Use “easy-hard-easy” rep patterns to keep confidence high.

## 5) Pass criteria

- Latency ≤ 2.0s at D0–D1; immediate turn at first cue; no repeats.

## 6) Drills

- Surprise cue → jackpot
- Cue from mild distraction → jackpot
- Cue → grab collar → jackpot

## 7) Common pitfalls + fixes

- Overusing cue → it becomes normal recall
- Using cue then clipping leash to go home → pay, then release or do neutral follow-up
- Practicing in hard contexts too soon → keep it pristine

## 8) Notes

- Use management (leash/barriers) to prevent rehearsal of failures.
- Stop a session early if frustration rises; switch to an easy win and end.

