# OL_PERMISSION — Off-leash permission rules (when, where, how)

**Type:** skill reference  
**Status:** detailed draft (modular refactor)  
**Last updated:** 2026-01-10

---

## 1) Definition

- Dog only goes off leash when given explicit permission and location rules are met.

## 2) Goals

- **Handler goal:** Use a consistent permission cue; deny politely (redirect) when not safe.
- **Dog goal:** Wait for permission and stay engaged without bolting.

## 3) Setup

- **Environment:** Train in fenced area first: leash on → permission cue → clip off.
- **Gear:** Leash/line; treats.
- **Progression:** D0 → D3 (see shared standards)
- **Standards:** `../standards/academy-standards.md`

## 4) Teaching steps (default)

### Step A — Create the behavior (D0)
- Keep reps short and easy; reinforce generously.
- Mark the instant the correct behavior happens; pay fast.

### Step B — Add one variable (duration OR distance)
- Increase one dimension at a time.
- If latency slows, you raised difficulty too fast—make the next rep easier.

### Step C — Generalize (new rooms → new yards → real life)
- Change context before changing difficulty.
- Use “easy-hard-easy” rep patterns to keep confidence high.

## 5) Pass criteria

- Dog does not launch without permission across 10 reps; ≥ 80%.

## 6) Drills

- Permission ritual (clip on/off)
- False door (no permission)
- Permission → recall within 10 seconds

## 7) Common pitfalls + fixes

- Unclear routine → standardize cue sequence
- Giving permission in risky areas → keep policy strict
- Dog anticipates and bolts → practice ‘no’ reps with reward for waiting

## 8) Notes

- Use management (leash/barriers) to prevent rehearsal of failures.
- Stop a session early if frustration rises; switch to an easy win and end.

