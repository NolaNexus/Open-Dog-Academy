# OL_MOVING_LEAVE_IT — Moving leave-it / disengage while in motion

**Type:** skill reference  
**Status:** detailed draft (modular refactor)  
**Last updated:** 2026-01-10

---

## 1) Definition

- Dog disengages from moving/nearby stimuli while continuing to walk with handler.

## 2) Goals

- **Handler goal:** Cue leave-it while moving, reinforce disengage + continued movement.
- **Dog goal:** Turn away and rejoin path without lunging.

## 3) Setup

- **Environment:** Start D0 with low-value moving target (person walking far).
- **Gear:** Leash/long line; treats.
- **Progression:** D0 → D3 (see shared standards)
- **Standards:** `../standards/academy-standards.md`

## 4) Teaching steps (default)

### Step A — Create the behavior (D0)
- Keep reps short and easy; reinforce generously.
- Mark the instant the correct behavior happens; pay fast.

### Step B — Add one variable (duration OR distance)
- Increase one dimension at a time.
- If latency slows, you raised difficulty too fast—make the next rep easier.

### Step C — Generalize (new rooms → new yards → real life)
- Change context before changing difficulty.
- Use “easy-hard-easy” rep patterns to keep confidence high.

## 5) Pass criteria

- Passes stimulus at safe distance with no lunge, ≥ 80% reps.

## 6) Drills

- Parallel walking past distraction
- Leave-it → treat scatter on path
- Leave-it → heel for 3 steps

## 7) Common pitfalls + fixes

- Too close → widen distance
- Stopping to cue → practice while moving
- Letting dog stare → cue earlier, reinforce quick disengage

## 8) Notes

- Use management (leash/barriers) to prevent rehearsal of failures.
- Stop a session early if frustration rises; switch to an easy win and end.

