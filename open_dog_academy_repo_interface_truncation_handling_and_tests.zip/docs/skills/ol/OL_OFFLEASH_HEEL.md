# OL_OFFLEASH_HEEL — Off-leash heel in enclosed areas

**Type:** skill reference  
**Status:** detailed draft (modular refactor)  
**Last updated:** 2026-01-10

---

## 1) Definition

- Dog can heel briefly off leash in enclosed/low-risk environments.

## 2) Goals

- **Handler goal:** Keep reps tiny, pay frequently, release to explore.
- **Dog goal:** Stay in heel zone without leash guidance.

## 3) Setup

- **Environment:** Start after strong on-leash heel. Fence first.
- **Gear:** Treats; enclosed space.
- **Progression:** D0 → D3 (see shared standards)
- **Standards:** `../standards/academy-standards.md`

## 4) Teaching steps (default)

### Step A — Create the behavior (D0)
- Keep reps short and easy; reinforce generously.
- Mark the instant the correct behavior happens; pay fast.

### Step B — Add one variable (duration OR distance)
- Increase one dimension at a time.
- If latency slows, you raised difficulty too fast—make the next rep easier.

### Step C — Generalize (new rooms → new yards → real life)
- Change context before changing difficulty.
- Use “easy-hard-easy” rep patterns to keep confidence high.

## 5) Pass criteria

- 10–15 steps, ≥ 80% position accuracy, no bolting.

## 6) Drills

- Off-leash 3-step heel
- Off-leash turns
- Heel → release → recall loop

## 7) Common pitfalls + fixes

- Trying in open areas early → fence first
- Over-length reps → short sets, frequent releases
- Handler gaze at dog → look ahead, keep mechanics consistent

## 8) Notes

- Use management (leash/barriers) to prevent rehearsal of failures.
- Stop a session early if frustration rises; switch to an easy win and end.

