# OL_STOP_WAIT — Stop-and-wait (halt)

**Type:** skill reference  
**Status:** detailed draft (modular refactor)  
**Last updated:** 2026-01-10

---

## 1) Definition

- Dog halts and holds position when handler stops or cues stop.

## 2) Goals

- **Handler goal:** Stop, cue, reinforce halt, release or call to position.
- **Dog goal:** Stop forward motion and wait for next instruction.

## 3) Setup

- **Environment:** D0. Start in low-speed walking, then jogging.
- **Gear:** Long line initially; treats.
- **Progression:** D0 → D3 (see shared standards)
- **Standards:** `../standards/academy-standards.md`

## 4) Teaching steps (default)

### Step A — Create the behavior (D0)
- Keep reps short and easy; reinforce generously.
- Mark the instant the correct behavior happens; pay fast.

### Step B — Add one variable (duration OR distance)
- Increase one dimension at a time.
- If latency slows, you raised difficulty too fast—make the next rep easier.

### Step C — Generalize (new rooms → new yards → real life)
- Change context before changing difficulty.
- Use “easy-hard-easy” rep patterns to keep confidence high.

## 5) Pass criteria

- Stops within 2 steps in ≥ 80% reps at D1.

## 6) Drills

- Stop-and-feed
- Stop → recall-to-heel
- Stop near boundary line

## 7) Common pitfalls + fixes

- Dog slams into line → practice at slower speed, shorten line
- Handler inconsistent → pair with a clear cue
- No reinforcement for stopping → pay heavily early

## 8) Notes

- Use management (leash/barriers) to prevent rehearsal of failures.
- Stop a session early if frustration rises; switch to an easy win and end.

