# OL_CHECK_IN — Check-ins / voluntary orientation on walks

**Type:** skill reference  
**Status:** detailed draft (modular refactor)  
**Last updated:** 2026-01-10

---

## 1) Definition

- Dog frequently offers orientation/check-ins during movement without being cued.

## 2) Goals

- **Handler goal:** Mark/payout spontaneous check-ins, especially near distractions.
- **Dog goal:** Look back to you and stay within range.

## 3) Setup

- **Environment:** Start on leash D0. Reinforce every check-in initially.
- **Gear:** Leash/long line; treats.
- **Progression:** D0 → D3 (see shared standards)
- **Standards:** `../standards/academy-standards.md`

## 4) Teaching steps (default)

### Step A — Create the behavior (D0)
- Keep reps short and easy; reinforce generously.
- Mark the instant the correct behavior happens; pay fast.

### Step B — Add one variable (duration OR distance)
- Increase one dimension at a time.
- If latency slows, you raised difficulty too fast—make the next rep easier.

### Step C — Generalize (new rooms → new yards → real life)
- Change context before changing difficulty.
- Use “easy-hard-easy” rep patterns to keep confidence high.

## 5) Pass criteria

- At least 6 voluntary check-ins per 5 minutes in D0–D1 contexts.

## 6) Drills

- Check-in jackpot near novel thing
- Patterned walking + random pay
- Check-in before release to sniff

## 7) Common pitfalls + fixes

- Dog only checks in when you stop → reinforce while moving
- Too sparse reinforcement early → increase rate
- Distractors too hard → increase distance

## 8) Notes

- Use management (leash/barriers) to prevent rehearsal of failures.
- Stop a session early if frustration rises; switch to an easy win and end.

