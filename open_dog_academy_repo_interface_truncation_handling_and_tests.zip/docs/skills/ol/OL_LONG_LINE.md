# OL_LONG_LINE — Long-line handling & safety

**Type:** skill reference  
**Status:** detailed draft (modular refactor)  
**Last updated:** 2026-01-10

---

## 1) Definition

- Handler and dog can safely work recalls and movement on a long line without tangles or injury.

## 2) Goals

- **Handler goal:** Manage slack, avoid wraps, wear gloves if needed, step on line safely.
- **Dog goal:** Move freely without hitting end of line; respond to cues.

## 3) Setup

- **Environment:** Open area. Practice handling before adding high distractions.
- **Gear:** 15–30 ft long line, harness/flat collar, gloves optional.
- **Progression:** D0 → D3 (see shared standards)
- **Standards:** `../standards/academy-standards.md`

## 4) Teaching steps (default)

### Step A — Create the behavior (D0)
- Keep reps short and easy; reinforce generously.
- Mark the instant the correct behavior happens; pay fast.

### Step B — Add one variable (duration OR distance)
- Increase one dimension at a time.
- If latency slows, you raised difficulty too fast—make the next rep easier.

### Step C — Generalize (new rooms → new yards → real life)
- Change context before changing difficulty.
- Use “easy-hard-easy” rep patterns to keep confidence high.

## 5) Pass criteria

- No hard line hits; handler keeps line organized in ≥ 90% reps.

## 6) Drills

- Figure-8 long-line handling
- Recall with line assist (gentle)
- Drag-line simulation in safe area

## 7) Common pitfalls + fixes

- Wrapping hand → use loops/folds
- Letting line trail near hazards → scan environment
- Yanking on line → use gentle guide + reward

## 8) Notes

- Use management (leash/barriers) to prevent rehearsal of failures.
- Stop a session early if frustration rises; switch to an easy win and end.

