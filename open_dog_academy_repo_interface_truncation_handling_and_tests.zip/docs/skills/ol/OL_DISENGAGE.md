# OL_DISENGAGE — Disengage / pattern interrupt from distractions

**Type:** skill reference  
**Status:** detailed draft (modular refactor)  
**Last updated:** 2026-01-10

---

## 1) Definition

- Dog can break fixation on a distraction and re-orient to handler quickly.

## 2) Goals

- **Handler goal:** Mark micro-disengages (blink/head turn), pay for full orient.
- **Dog goal:** Look away from stimulus and back to you.

## 3) Setup

- **Environment:** D0–D1 with controllable distractions at distance.
- **Gear:** Treats; leash/line.
- **Progression:** D0 → D3 (see shared standards)
- **Standards:** `../standards/academy-standards.md`

## 4) Teaching steps (default)

### Step A — Create the behavior (D0)
- Keep reps short and easy; reinforce generously.
- Mark the instant the correct behavior happens; pay fast.

### Step B — Add one variable (duration OR distance)
- Increase one dimension at a time.
- If latency slows, you raised difficulty too fast—make the next rep easier.

### Step C — Generalize (new rooms → new yards → real life)
- Change context before changing difficulty.
- Use “easy-hard-easy” rep patterns to keep confidence high.

## 5) Pass criteria

- Disengage within 2 seconds on ≥ 80% reps at D1.

## 6) Drills

- Engage/disengage game
- Auto-check-in after looking
- Disengage → release to sniff

## 7) Common pitfalls + fixes

- Waiting for dog to explode → work at greater distance
- Handler tension → loosen posture, breathe
- Over-cuing → capture offered disengages

## 8) Notes

- Use management (leash/barriers) to prevent rehearsal of failures.
- Stop a session early if frustration rises; switch to an easy win and end.

