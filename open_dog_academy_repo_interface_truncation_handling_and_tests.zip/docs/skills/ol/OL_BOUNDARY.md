# OL_BOUNDARY — Boundary / proximity rules (stay near)

**Type:** skill reference  
**Status:** detailed draft (modular refactor)  
**Last updated:** 2026-01-10

---

## 1) Definition

- Dog respects boundaries (property line, trail edge, invisible line) until released.

## 2) Goals

- **Handler goal:** Teach boundary with line + reinforcement; reward staying inside.
- **Dog goal:** Stop/turn at boundary rather than crossing.

## 3) Setup

- **Environment:** Start D0 with visual markers. Reinforce near boundary.
- **Gear:** Long line; cones/markers optional.
- **Progression:** D0 → D3 (see shared standards)
- **Standards:** `../standards/academy-standards.md`

## 4) Teaching steps (default)

### Step A — Create the behavior (D0)
- Keep reps short and easy; reinforce generously.
- Mark the instant the correct behavior happens; pay fast.

### Step B — Add one variable (duration OR distance)
- Increase one dimension at a time.
- If latency slows, you raised difficulty too fast—make the next rep easier.

### Step C — Generalize (new rooms → new yards → real life)
- Change context before changing difficulty.
- Use “easy-hard-easy” rep patterns to keep confidence high.

## 5) Pass criteria

- Stops at boundary with 1 cue (or offered) in ≥ 80% reps D0–D1.

## 6) Drills

- Boundary walk (edge)
- Boundary + recall-to-heel
- Boundary + go sniff release

## 7) Common pitfalls + fixes

- Boundary unclear → add cones/flags
- Correcting after crossing → prevent with line, reinforce before crossing
- Too many repetitions → short sessions

## 8) Notes

- Use management (leash/barriers) to prevent rehearsal of failures.
- Stop a session early if frustration rises; switch to an easy win and end.

