# OL_EMERGENCY_STOP — Emergency stop (down/sit/stand at distance)

**Type:** skill reference  
**Status:** detailed draft (modular refactor)  
**Last updated:** 2026-01-10

---

## 1) Definition

- Dog drops into a reliable stop behavior at distance (down/sit/stand) regardless of motion.

## 2) Goals

- **Handler goal:** Build in layers: stationary → moving → distance → distraction; keep reps few.
- **Dog goal:** Freeze in place quickly until released.

## 3) Setup

- **Environment:** Start D0. Choose one stop position (often down).
- **Gear:** Long line; high-value treats.
- **Progression:** D0 → D3 (see shared standards)
- **Standards:** `../standards/academy-standards.md`

## 4) Teaching steps (default)

### Step A — Create the behavior (D0)
- Keep reps short and easy; reinforce generously.
- Mark the instant the correct behavior happens; pay fast.

### Step B — Add one variable (duration OR distance)
- Increase one dimension at a time.
- If latency slows, you raised difficulty too fast—make the next rep easier.

### Step C — Generalize (new rooms → new yards → real life)
- Change context before changing difficulty.
- Use “easy-hard-easy” rep patterns to keep confidence high.

## 5) Pass criteria

- D1: response ≤ 3.0s at 10–15 ft; ≥ 80% across 2 sessions.

## 6) Drills

- Stop from walk
- Stop from mild trot
- Stop with toy/food distraction at distance

## 7) Common pitfalls + fixes

- Too fast too soon → reduce speed/distance
- Punishing slow responses → pay for effort, rebuild
- Repeating cue → reset, make next rep easier

## 8) Notes

- Use management (leash/barriers) to prevent rehearsal of failures.
- Stop a session early if frustration rises; switch to an easy win and end.

