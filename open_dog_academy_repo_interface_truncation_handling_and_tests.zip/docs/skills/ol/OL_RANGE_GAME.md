# OL_RANGE_GAME — Range/arc management game

**Type:** skill reference  
**Status:** detailed draft (modular refactor)  
**Last updated:** 2026-01-10

---

## 1) Definition

- Dog learns an acceptable working range/arc and returns to you frequently.

## 2) Goals

- **Handler goal:** Reinforce returns, use direction changes, reward staying within range.
- **Dog goal:** Range out a bit then swing back without being called.

## 3) Setup

- **Environment:** Open area. Define range (e.g., 10–20 ft) and pay for returns.
- **Gear:** Long line early; treats.
- **Progression:** D0 → D3 (see shared standards)
- **Standards:** `../standards/academy-standards.md`

## 4) Teaching steps (default)

### Step A — Create the behavior (D0)
- Keep reps short and easy; reinforce generously.
- Mark the instant the correct behavior happens; pay fast.

### Step B — Add one variable (duration OR distance)
- Increase one dimension at a time.
- If latency slows, you raised difficulty too fast—make the next rep easier.

### Step C — Generalize (new rooms → new yards → real life)
- Change context before changing difficulty.
- Use “easy-hard-easy” rep patterns to keep confidence high.

## 5) Pass criteria

- Dog stays within set range ≥ 80% of time in D1; returns 1x/minute.

## 6) Drills

- Random direction changes
- Reward returns to center
- Release to explore then call back briefly

## 7) Common pitfalls + fixes

- Chasing dog to regain range → instead change direction and reward catch-up
- Too much freedom too early → use line and smaller area
- No criteria → pick a numeric range and stick to it

## 8) Notes

- Use management (leash/barriers) to prevent rehearsal of failures.
- Stop a session early if frustration rises; switch to an easy win and end.

