# OL_PREMACK_RECALL — Premack recall (recall earns return to fun)

**Type:** skill reference  
**Status:** detailed draft (modular refactor)  
**Last updated:** 2026-01-10

---

## 1) Definition

- Recall functions as “come back, get paid, then return to the fun.”

## 2) Goals

- **Handler goal:** Recall → reward → release back to sniff/play as primary reinforcer.
- **Dog goal:** Come happily because it predicts access.

## 3) Setup

- **Environment:** Choose low-risk fun (sniff patch) and practice controlled recalls.
- **Gear:** Long line early; treats; access to sniffing.
- **Progression:** D0 → D3 (see shared standards)
- **Standards:** `../standards/academy-standards.md`

## 4) Teaching steps (default)

### Step A — Create the behavior (D0)
- Keep reps short and easy; reinforce generously.
- Mark the instant the correct behavior happens; pay fast.

### Step B — Add one variable (duration OR distance)
- Increase one dimension at a time.
- If latency slows, you raised difficulty too fast—make the next rep easier.

### Step C — Generalize (new rooms → new yards → real life)
- Change context before changing difficulty.
- Use “easy-hard-easy” rep patterns to keep confidence high.

## 5) Pass criteria

- Dog returns promptly and re-engages with fun after release on ≥ 80%.

## 6) Drills

- Recall → treat → “go sniff”
- Recall away from mild play → release back
- Premack with fence line (distance)

## 7) Common pitfalls + fixes

- Always ending fun after recall → balance with many ‘return to fun’ reps
- Too hard distractions → make fun controllable
- Late release cue → keep release crisp

## 8) Notes

- Use management (leash/barriers) to prevent rehearsal of failures.
- Stop a session early if frustration rises; switch to an easy win and end.

