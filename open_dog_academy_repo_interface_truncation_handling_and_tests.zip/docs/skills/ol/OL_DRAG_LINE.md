# OL_DRAG_LINE — Drag-line transition

**Type:** skill reference  
**Status:** detailed draft (modular refactor)  
**Last updated:** 2026-01-10

---

## 1) Definition

- Dog works with a dragging line as a safety backup while appearing “off leash.”

## 2) Goals

- **Handler goal:** Choose safe surface, prevent snags, pick up line proactively.
- **Dog goal:** Ignore line and respond reliably.

## 3) Setup

- **Environment:** Fenced/enclosed first. Check snag hazards.
- **Gear:** Shorter drag line (10–15 ft) or long line with handle removed.
- **Progression:** D0 → D3 (see shared standards)
- **Standards:** `../standards/academy-standards.md`

## 4) Teaching steps (default)

### Step A — Create the behavior (D0)
- Keep reps short and easy; reinforce generously.
- Mark the instant the correct behavior happens; pay fast.

### Step B — Add one variable (duration OR distance)
- Increase one dimension at a time.
- If latency slows, you raised difficulty too fast—make the next rep easier.

### Step C — Generalize (new rooms → new yards → real life)
- Change context before changing difficulty.
- Use “easy-hard-easy” rep patterns to keep confidence high.

## 5) Pass criteria

- Dog maintains reliability similar to long line; no snag incidents.

## 6) Drills

- Drag line recalls
- Drag line stop/wait
- Drag line boundary game

## 7) Common pitfalls + fixes

- Using in unsafe terrain → only low-snag environments
- Line becomes chew toy → supervise, reinforce calm
- Overconfidence → keep criteria strict

## 8) Notes

- Use management (leash/barriers) to prevent rehearsal of failures.
- Stop a session early if frustration rises; switch to an easy win and end.

