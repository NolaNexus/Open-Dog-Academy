# Start Here

## What to read first (in order)
1) **Standards**
   - [Academy Standards](standards/academy-standards.md)
   - [Safety + Welfare](standards/academy-safety-and-welfare.md)
   - [Group Class Safety](standards/group-class-safety.md)
   - [Remote Cue Devices](standards/remote-cue-devices.md)

2) **Core curricula**
   - [Obedience](classes/class-guide-obedience.md)
   - [Leash Skills](classes/class-guide-leash-skills.md)
   - [Cooperative Care](classes/class-guide-cooperative-care.md)
   - [Independence](classes/class-guide-independence.md)
   - [Regulation](classes/class-guide-regulation.md)

3) **Group teaching**
   - [Instructor Guides Index](indexes/instructor-guides-index.md)

4) **Find any skill**
   - [Skills Index](indexes/skills-index.md)

## How to use ODA (simple workflow)
- Pick a **class guide** → follow the default sequence.
- When you need detail: click into the **skill file** for that `SKILL_ID`.
- Log work using the measurement standard from **Academy Standards**.

## Contributing rules (non-negotiables)
- Do not duplicate standards inside class guides.
- Every `SKILL_ID` used anywhere must have a skill file.
- Keep docs web-friendly: see [Format Policy](format-policy.md).


## Optional deep dives
- Experimental projects (kept quarantined): [LAB](lab/index.md)
- Dog/household-specific implementations live outside this repo: [Profiles + Household Specs](ops/profile-storage.md)
