# Template: Homework Card (Weekly)
Version: 1.0  
Updated: 2026-01-10

---

## This week’s focus
- Skill 1:
- Skill 2:
- Skill 3:

## Daily plan (5–10 minutes)
- [ ] 10 reps: __________________
- [ ] 5 reps: ___________________
- [ ] 1 minute: ________________

## Success looks like
- measurable criteria:

## If it goes wrong, do this
- simplify:
- add distance:
- change reinforcer:

## Notes
- wins:
- challenges:
- questions for next meetup:

