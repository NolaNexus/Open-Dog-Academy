# Contributing to Open Dog Academy
Updated: **2026-01-10**

This repo is maintained like a software project: **small modules, strong guardrails, no duplication drift**.

## Core idea
**Mantra:** *Atoms are truth. Assemblies are playlists.*

- **Atoms** live in `docs/_atoms/` and are small, reusable, mostly-static building blocks.
- **Assemblies** (skills, manuals, class guides, instructor guides) include atoms instead of copying them.

## Where to put things
- `docs/standards/` — academy-wide policies (safety, welfare, device policy).
- `docs/_atoms/` — reusable blocks (definitions, protocols, rubrics, checklists, templates).
- `docs/skills/` — skill pages keyed by `SKILL_ID` (assemblies).
- `docs/classes/` — class guides (assemblies).
- `docs/instructor-guides/` — teaching scripts (assemblies).
- `docs/manuals/` — deep dives that stitch many skills together (assemblies).
- `docs/lab/` — experiments and prototypes (must have graduation criteria).
- `docs/reference/` — sources, extracts, exports.

## Writing rules (the “modularity default”)
- If a block of content will be reused **2+ times**, extract it into an atom.
- Keep each file focused: *one purpose per file*.
- Prefer `##` sections that can become split points later.

### Including atoms
This repo uses `pymdownx.snippets`:

```md
--8<-- "_atoms/templates/logging-template-001.md"
```

## Limits (anti-truncation)
To prevent “turncation” (truncation) issues, docs have enforced length limits:

- Config: `doc-limits.yml`
- Validator: `scripts/validate_doc_limits.py`
- Split planner: `scripts/suggest_doc_split.py`

See: [Doc length limits](ops/doc-length-limits.md).

## Skill IDs
Skills are referenced by `SKILL_ID` (example: `OB_RECALL`).

If you reference a new ID:
1) Add the file under the right folder (or create a stub).
2) Update the skills index if needed.

## Local checks (recommended before PR)
From repo root:

```bash
python3 scripts/check_sizes.py
python3 scripts/validate_yaml.py
python3 scripts/validate_doc_limits.py
python3 scripts/validate_atoms.py
python3 scripts/validate_includes.py
python3 scripts/validate_skill_links.py
mkdocs build --strict
```

## Style
- Be clear and operational: steps, criteria, failure modes, and “what success looks like.”
- Use humane, force-free defaults.
- Avoid long walls of text; prefer small modules and links.


## Interface truncation (AI tools)

If you’re using AI tools to generate content, assume long responses may truncate.

- Follow: `docs/ops/ai-output-protocol.md`
- Use: `scripts/chunk_for_chat.py` to export any doc into chat-safe parts.
