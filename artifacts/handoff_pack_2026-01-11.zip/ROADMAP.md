# ODA Roadmap

Canonical copy lives here:

- `docs/roadmap.md`

This stub exists to keep the roadmap easy to find from the repo root without maintaining two diverging versions.
