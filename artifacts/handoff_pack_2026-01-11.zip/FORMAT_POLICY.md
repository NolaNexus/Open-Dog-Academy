# ODA Format Policy

Canonical copy lives here:

- `docs/format-policy.md`

This stub exists to keep the policy easy to find from the repo root without maintaining two diverging versions.
