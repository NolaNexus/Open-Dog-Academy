# ROADMAP — Part 1/1

- Source: `ROADMAP.md`
- Characters (body): 177
- Words (body): 28
- Lines (body): 8
- SHA-256 (body): `d56bd9dcbe79b452919e0fb68ef15dd4969f9f0b3639b0f60208fc1943370632`

## Head (first ~5 lines)

```
# ODA Roadmap

Canonical copy lives here:

- `docs/roadmap.md`
```

## Tail (last ~5 lines)

```
Canonical copy lives here:

- `docs/roadmap.md`

This stub exists to keep the roadmap easy to find from the repo root without maintaining two diverging versions.
```

<!-- ODA_CHUNK_BEGIN_BODY -->
# ODA Roadmap

Canonical copy lives here:

- `docs/roadmap.md`

This stub exists to keep the roadmap easy to find from the repo root without maintaining two diverging versions.
<!-- ODA_CHUNK_END_BODY -->
<!-- END_OF_PART 1/1 -->
