# Chat chunks: `ROADMAP.md`

Generated to avoid interface truncation. Each part ends with `<!-- END_OF_PART n/N -->`.

Integrity: each part includes a SHA-256 digest of its body.

## Parts

- [Part 01](part-01.md)
